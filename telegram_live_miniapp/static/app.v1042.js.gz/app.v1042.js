"use strict";

// ============================================================
//  Telegram WebApp init
// ============================================================
const tg = window.Telegram?.WebApp;
if (tg) {
  try {
    tg.ready();
    tg.expand();
    tg.setHeaderColor("#0a1410");
    tg.setBackgroundColor("#050a07");
  } catch (_) {}
}

function telegramChatId() {
  try {
    const direct = String(tg?.initDataUnsafe?.user?.id || "").trim();
    if (direct) return direct;
    const params = new URLSearchParams(String(tg?.initData || ""));
    const raw = params.get("user") || "";
    if (raw) return String(JSON.parse(raw)?.id || "").trim();
  } catch (_) {}
  return "";
}



function startupMatchId() {
  let raw = "";
  try {
    const params = new URLSearchParams(location.search || "");
    raw = params.get("match_id") || params.get("match") || params.get("id") || "";
  } catch (_) {}
  try {
    raw = raw || String(tg?.initDataUnsafe?.start_param || "").trim();
  } catch (_) {}
  raw = String(raw || "").trim();
  if (!raw) return "";
  if (raw.startsWith("match_")) raw = raw.slice(6);
  if (raw.startsWith("match-")) raw = raw.slice(6);
  try { raw = decodeURIComponent(raw); } catch (_) {}
  return normalizeMatchId(raw);
}

let _startupMatchOpened = false;
function openStartupMatchIfAny() {
  if (_startupMatchOpened) return;
  const id = startupMatchId();
  if (!id) return;
  _startupMatchOpened = true;
  try { loadDetail(id, { keepNav: true }); } catch (err) { console.warn("startup match open failed", err); }
}

// ============================================================
//  Local storage helpers (favorites + notify config)
// ============================================================
const FAV_KEY = "miniapp-v5-favorites";
const FAV_CACHE_KEY = "miniapp-v6-favorites-cache";  // v6: full match snapshots
const NOTIFY_FILTER_KEY = "miniapp-v5-notify-filter";
const NOTIFY_ENABLED_KEY = "miniapp-v5-notify-enabled";
const NOTIFY_PROFILE_ACTIVE_KEY = "miniapp-v9-notify-profile-active";
const NOTIFY_PROFILE_STORE_KEY = "miniapp-v9-notify-profiles";
const NOTIFY_PROFILE_IDS = ["1", "2", "3"];
const NOTIFY_SEEN_KEY = "miniapp-v5-notify-seen";
const NOTIFY_CACHE_KEY = "miniapp-v10-notify-cache";
const GOAL_NOTIFY_KEY = "miniapp-v5-goal-notify";
const AUTO_GOAL_NOTIFY_KEY = "miniapp-v9-auto-goal-notify";
const GOAL_NOTIFY_SCORE_KEY = "miniapp-v5-goal-notify-score";
const GOAL_WAIT_NOTIFY_ENABLED_KEY = "miniapp-v9-goal-wait-notify-enabled";
const GOAL_WAIT_AUTO_GOAL_ENABLED_KEY = "miniapp-v9-goal-wait-auto-goal-enabled";
const GOAL_WAIT_SEEN_KEY = "miniapp-v9-goal-wait-seen";
const ALERT_SOUND_KEY = "miniapp-v9-alert-sound-enabled";
const PRESSURE_HISTORY_KEY = "miniapp-v9-pressure-history";
const LAST_DETAIL_KEY = "miniapp-v1034-last-detail";
const LAST_DETAIL_TTL_MS = 60 * 60 * 1000; // restore only for the last 60 minutes
// v9.78: frontend polling is intentionally slower to reduce bandwidth/load.
// Change these constants if you need faster/slower live updates.
const LIVE_POLL_INTERVAL_MS = Math.max(30000, Number(window.MINIAPP_LIVE_POLL_INTERVAL_MS || 60000));
const DETAIL_POLL_INTERVAL_MS = Math.max(30000, Number(window.MINIAPP_DETAIL_POLL_INTERVAL_MS || 60000));
const ONLINE_HEARTBEAT_INTERVAL_MS = Math.max(30000, Number(window.MINIAPP_ONLINE_HEARTBEAT_INTERVAL_MS || 60000));

// v6: continent / region → emoji flag, used when country_code is empty
// (matches grouped by continent: AMERICAS / ASIA / OCEANIA …).
const CONTINENT_FLAG_EMOJI = {
  "europe":         "🇪🇺",
  "africa":         "🌍",
  "americas":       "🌎", "america": "🌎",
  "north america":  "🌎", "south america": "🌎", "central america": "🌎",
  "asia":           "🌏",
  "oceania":        "🌏",
  "international":  "🏳️", "world": "🌐",
  "без страны":     "🌐", "без лиги": "🌐",
};

function getFavs() {
  try { return new Set(JSON.parse(localStorage.getItem(FAV_KEY) || "[]")); }
  catch { return new Set(); }
}
function saveFavs(s) { localStorage.setItem(FAV_KEY, JSON.stringify([...s])); }
function isFav(id) { return getFavs().has(String(id)); }
function toggleFav(id) {
  const f = getFavs();
  const k = String(id);
  if (f.has(k)) {
    f.delete(k);
    removeFavCache(k);
  } else {
    f.add(k);
    // Cache the full match snapshot so we can still show it after the match ends.
    const m = findCurrentMatchById ? findCurrentMatchById(k) : null;
    if (m) saveFavCache(k, m);
  }
  saveFavs(f);
  return f.has(k);
}

// v6: full match-data cache for favorites — survives after a match ends &
// is removed from the live cache by the server.
function getFavCache() {
  try { return JSON.parse(localStorage.getItem(FAV_CACHE_KEY) || "{}") || {}; }
  catch { return {}; }
}
function saveFavCacheStore(store) {
  // Keep at most 200 cached matches, drop the oldest by cached_at.
  const entries = Object.entries(store);
  if (entries.length > 200) {
    entries.sort((a, b) => (b[1]?.cached_at || 0) - (a[1]?.cached_at || 0));
    const trimmed = {};
    for (const [k, v] of entries.slice(0, 200)) trimmed[k] = v;
    store = trimmed;
  }
  try { localStorage.setItem(FAV_CACHE_KEY, JSON.stringify(store)); }
  catch (_) {}
}
function saveFavCache(id, match) {
  if (!id || !match) return;
  const store = getFavCache();
  store[String(id)] = { ...match, cached_at: Date.now(), id: String(id) };
  saveFavCacheStore(store);
}
function removeFavCache(id) {
  if (!id) return;
  const store = getFavCache();
  if (store[String(id)]) {
    delete store[String(id)];
    saveFavCacheStore(store);
  }
}
function getFavCachedMatch(id) {
  const store = getFavCache();
  return store[String(id)] || null;
}

// Full match snapshots for the notifications tab. These records are intentionally
// kept until the user clears/removes them, so a notified match does not disappear
// just because it left the live feed or was cleaned from the 24h live cache.
function getNotifyCache() {
  try { return JSON.parse(localStorage.getItem(NOTIFY_CACHE_KEY) || "{}") || {}; }
  catch { return {}; }
}
function saveNotifyCacheStore(store) {
  const entries = Object.entries(store || {});
  if (entries.length > 500) {
    entries.sort((a, b) => (b[1]?.cached_at || b[1]?.found_at || 0) - (a[1]?.cached_at || a[1]?.found_at || 0));
    const trimmed = {};
    for (const [k, v] of entries.slice(0, 500)) trimmed[k] = v;
    store = trimmed;
  }
  try { localStorage.setItem(NOTIFY_CACHE_KEY, JSON.stringify(store || {})); }
  catch (_) {}
}
function saveNotifyCache(id, match) {
  if (!id || !match) return;
  const store = getNotifyCache();
  store[String(id)] = { ...match, cached_at: Date.now(), id: String(id) };
  saveNotifyCacheStore(store);
}
function removeNotifyCache(id) {
  const store = getNotifyCache();
  if (store[String(id)]) {
    delete store[String(id)];
    saveNotifyCacheStore(store);
  }
}
function clearNotifyCache() {
  try { localStorage.removeItem(NOTIFY_CACHE_KEY); } catch (_) {}
}
function getNotifyCachedMatch(id) {
  const k = String(id || "");
  if (!k) return null;
  const store = getNotifyCache();
  if (store[k]) return store[k];
  const lists = [state.notifyMatches || [], state.inAppAlerts || []];
  for (const list of lists) {
    for (const a of list || []) {
      if (String(a?.id || a?.match_id || "") === k) return renderAlert(a);
    }
  }
  return null;
}
function notifySnapshotFromMatch(m, extra = {}) {
  const id = String(m?.id || extra.id || "");
  return {
    id,
    home: m?.home || extra.home || "",
    away: m?.away || extra.away || "",
    home_logo: m?.home_logo || "",
    away_logo: m?.away_logo || "",
    score_home: safeInt(m?.score_home, 0),
    score_away: safeInt(m?.score_away, 0),
    score: m?.score || `${safeInt(m?.score_home, 0)}-${safeInt(m?.score_away, 0)}`,
    minute: normalizeMatchMinuteValue(m?.minute),
    minute_text: normalizeMatchMinuteText(m?.minute_text, m?.minute),
    country: m?.country || "",
    country_code: m?.country_code || "",
    league: m?.league || "",
    league_logo: m?.league_logo || "",
    stats: m?.stats || {},
    prematch_odds: m?.prematch_odds || {},
    live_odds: m?.live_odds || m?.odds || {},
    odds_movement: m?.odds_movement || {},
    odds_filter_market: extra.odds_filter_market || m?.odds_filter_market || "",
    odds_filter_snapshot: extra.odds_filter_snapshot || m?.odds_filter_snapshot || {},
    alert_kind: extra.alert_kind || m?.alert_kind || "",
    alert_title: extra.alert_title || m?.alert_title || "",
    alert_subtitle: extra.alert_subtitle || m?.alert_subtitle || "",
    alert_score: safeInt(extra.alert_score ?? m?.alert_score, 0),
    alert_reasons: normalizeAlertReasons(extra.alert_reasons ?? m?.alert_reasons ?? m?.alert_reason),
    alert_reason: String(extra.alert_reason ?? m?.alert_reason ?? ""),
    found_at: safeInt(extra.found_at, Math.floor(Date.now() / 1000)),
    ...extra,
  };
}
function saveNotifyCacheFromAlerts(items) {
  if (!Array.isArray(items) || !items.length) return;
  const store = getNotifyCache();
  let changed = false;
  for (const item of items) {
    const card = renderAlert(item);
    const id = String(card?.id || "");
    if (!id) continue;
    store[id] = { ...card, found_at: safeInt(item?.found_at || card?.found_at, Math.floor(Date.now() / 1000)), cached_at: Date.now() };
    changed = true;
  }
  if (changed) saveNotifyCacheStore(store);
}

// Refresh the cache snapshot whenever we see a live update for a favorite —
// so the cache always has the latest score / time when the match eventually
// ends.
function refreshFavCacheFromLive(matches) {
  const fav = getFavs();
  if (!fav.size) return;
  const store = getFavCache();
  let changed = false;
  for (const m of matches || []) {
    const k = String(m?.id || "");
    if (k && fav.has(k)) {
      store[k] = { ...m, cached_at: Date.now(), id: k };
      changed = true;
    }
  }
  if (changed) saveFavCacheStore(store);
}

function favoriteScoreChanged(oldMatch, freshMatch) {
  if (!freshMatch) return false;
  if (!oldMatch) return true;
  return (
    safeInt(oldMatch.score_home, 0) !== safeInt(freshMatch.score_home, 0) ||
    safeInt(oldMatch.score_away, 0) !== safeInt(freshMatch.score_away, 0) ||
    String(oldMatch.minute_text || "") !== String(freshMatch.minute_text || "") ||
    Boolean(oldMatch.finished) !== Boolean(freshMatch.finished)
  );
}

async function refreshFavoriteSnapshotsFromBackend(items) {
  if (state.favoriteRefreshRunning) return;
  const fav = getFavs();
  if (!fav.size) return;

  const now = Date.now();
  const targets = [];
  for (const m of items || []) {
    const id = String(m?.id || "");
    if (!id || !fav.has(id)) continue;
    // Live cards are already refreshed by /api/live. Backend refresh is for
    // cached/finished favorites, where the final score can otherwise stay stale.
    if (m?.is_live && !m?.finished) continue;
    if (now - Number(state.favoriteRefreshAt[id] || 0) < 30000) continue;
    state.favoriteRefreshAt[id] = now;
    targets.push(id);
    if (targets.length >= 12) break;
  }
  if (!targets.length) return;

  state.favoriteRefreshRunning = true;
  let changed = false;
  try {
    for (const id of targets) {
      try {
        const res = await fetch(`/api/match?id=${encodeURIComponent(id)}`, { cache: "no-store" });
        const payload = await res.json();
        if (!payload || !payload.ok || !payload.match) continue;
        const oldCached = getFavCachedMatch(id) || {};
        const fresh = {
          ...oldCached,
          ...payload.match,
          id,
          finished: Boolean(payload.finished || payload.match.finished || oldCached.finished),
          cached_at: Date.now(),
        };
        if (favoriteScoreChanged(oldCached, fresh)) changed = true;
        saveFavCache(id, fresh);
      } catch (_) {}
    }
  } finally {
    state.favoriteRefreshRunning = false;
  }
  if (changed && (state.view === "favorites" || state.view === "notify")) render();
}

function getGoalNotifies() {
  try { return new Set(JSON.parse(localStorage.getItem(GOAL_NOTIFY_KEY) || "[]")); }
  catch { return new Set(); }
}
function saveGoalNotifies(s) { localStorage.setItem(GOAL_NOTIFY_KEY, JSON.stringify([...s])); }
function getAutoGoalNotifies() {
  try { return new Set(JSON.parse(localStorage.getItem(AUTO_GOAL_NOTIFY_KEY) || "[]")); }
  catch { return new Set(); }
}
function saveAutoGoalNotifies(s) {
  const arr = [...s];
  if (arr.length > 500) arr.splice(0, arr.length - 500);
  localStorage.setItem(AUTO_GOAL_NOTIFY_KEY, JSON.stringify(arr));
}
function isGoalNotify(id) { return getGoalNotifies().has(String(id)) || getAutoGoalNotifies().has(String(id)); }
function getGoalNotifyScores() {
  try { return JSON.parse(localStorage.getItem(GOAL_NOTIFY_SCORE_KEY) || "{}") || {}; }
  catch { return {}; }
}
function saveGoalNotifyScores(v) { localStorage.setItem(GOAL_NOTIFY_SCORE_KEY, JSON.stringify(v || {})); }
function getGoalWaitNotifyEnabled() { return localStorage.getItem(GOAL_WAIT_NOTIFY_ENABLED_KEY) === "1"; }
function setGoalWaitNotifyEnabled(v) { localStorage.setItem(GOAL_WAIT_NOTIFY_ENABLED_KEY, v ? "1" : "0"); }
function getGoalWaitAutoGoalEnabled() { return localStorage.getItem(GOAL_WAIT_AUTO_GOAL_ENABLED_KEY) === "1"; }
function setGoalWaitAutoGoalEnabled(v) { localStorage.setItem(GOAL_WAIT_AUTO_GOAL_ENABLED_KEY, v ? "1" : "0"); }
function getGoalWaitSeen() {
  try { return new Set(JSON.parse(localStorage.getItem(GOAL_WAIT_SEEN_KEY) || "[]")); }
  catch { return new Set(); }
}
function saveGoalWaitSeen(s) {
  const arr = [...s];
  if (arr.length > 200) arr.splice(0, arr.length - 200);
  localStorage.setItem(GOAL_WAIT_SEEN_KEY, JSON.stringify(arr));
}

function getAlertSoundEnabled() {
  // Enabled by default. Telegram/browser may require one tap before sound can play.
  return localStorage.getItem(ALERT_SOUND_KEY) !== "0";
}
function setAlertSoundEnabled(v) {
  localStorage.setItem(ALERT_SOUND_KEY, v ? "1" : "0");
  if (v) unlockAlertSound();
}
function toggleAlertSound() {
  setAlertSoundEnabled(!getAlertSoundEnabled());
  if (state.view === "notify") render();
}

let _alertAudioCtx = null;
function getAlertAudioContext() {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return null;
    if (!_alertAudioCtx) _alertAudioCtx = new Ctx();
    return _alertAudioCtx;
  } catch (_) {
    return null;
  }
}
function unlockAlertSound() {
  const ctx = getAlertAudioContext();
  if (!ctx) return;
  try { if (ctx.state === "suspended") ctx.resume().catch(() => {}); } catch (_) {}
}
function playTone(ctx, freq, start, duration, gainLevel = 0.035) {
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(freq, start);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(gainLevel, start + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(start);
    osc.stop(start + duration + 0.02);
  } catch (_) {}
}
function playAlertSound(kind = "found") {
  if (!getAlertSoundEnabled()) return;
  const ctx = getAlertAudioContext();
  if (!ctx) return;
  const run = () => {
    const now = ctx.currentTime + 0.02;
    if (kind === "goal") {
      playTone(ctx, 660, now, 0.11, 0.045);
      playTone(ctx, 880, now + 0.12, 0.13, 0.045);
      playTone(ctx, 660, now + 0.28, 0.10, 0.035);
    } else {
      playTone(ctx, 520, now, 0.10, 0.035);
      playTone(ctx, 720, now + 0.12, 0.12, 0.04);
    }
  };
  try {
    if (ctx.state === "suspended") ctx.resume().then(run).catch(() => {});
    else run();
  } catch (_) {}
}

document.addEventListener("pointerdown", () => {
  if (getAlertSoundEnabled()) unlockAlertSound();
}, { passive: true });

function defaultNotifyFilter() {
  return {
    enabled: false,
    minute_min: 45, minute_max: 65,
    shots_min: 14, on_target_min: 6, off_target_min: 0,
    dangerous_min: 51, attacks_min: 101,
    corners_min: 0,
    yellow_cards_min: 0, red_cards_min: 0,
    possession_min: 0,
    odds_market: "",
    odds_direction: "any",
    odds_was_min: 0, odds_was_max: 0,
    odds_now_min: 0, odds_now_max: 0,
    odds_change_pct_min: 0,
    scores: ["0-0", "1-0", "0-1"],
    countries: [],
  };
}

function fixedGoalWaitFilter(enabled = true) {
  return {
    enabled: !!enabled,
    signal_type: "goal_wait",
    goal_signal_enabled: true,
    minute_min: 55,
    minute_max: 65,
    goals_max: 0,
    score_diff_max: 0,
    shots_min: 14,
    on_target_min: 5,
    off_target_min: 0,
    dangerous_min: 45,
    attacks_min: 0,
    corners_min: 5,
    pressure_min: 60,
    yellow_cards_min: 0,
    red_cards_min: 0,
    possession_min: 0,
    scores: ["0-0"],
    countries: [],
  };
}

function normalizeNotifyFilter(f) {
  const base = defaultNotifyFilter();
  const src = (f && typeof f === "object") ? f : {};
  const out = { ...base, ...src };
  out.enabled = !!out.enabled;
  out.minute_min = clamp(safeInt(out.minute_min, base.minute_min), 0, 130);
  out.minute_max = clamp(safeInt(out.minute_max, base.minute_max), 0, 130);
  out.goals_max = safeInt(out.goals_max, 0);
  out.score_diff_max = safeInt(out.score_diff_max, -1);
  out.shots_min = safeInt(out.shots_min, 0);
  out.on_target_min = safeInt(out.on_target_min, 0);
  out.off_target_min = safeInt(out.off_target_min, 0);
  out.dangerous_min = safeInt(out.dangerous_min, 0);
  out.attacks_min = safeInt(out.attacks_min, 0);
  out.corners_min = safeInt(out.corners_min, 0);
  out.pressure_min = safeInt(out.pressure_min, 0);
  out.yellow_cards_min = safeInt(out.yellow_cards_min, 0);
  out.red_cards_min = safeInt(out.red_cards_min, 0);
  out.possession_min = clamp(safeInt(out.possession_min, 0), 0, 100);
  out.odds_market = ["1","x","2","over","under"].includes(String(out.odds_market || "").toLowerCase()) ? String(out.odds_market).toLowerCase() : "";
  out.odds_direction = ["any","up","down"].includes(String(out.odds_direction || "any").toLowerCase()) ? String(out.odds_direction).toLowerCase() : "any";
  out.odds_was_min = Math.max(0, Number(out.odds_was_min) || 0);
  out.odds_was_max = Math.max(0, Number(out.odds_was_max) || 0);
  out.odds_now_min = Math.max(0, Number(out.odds_now_min) || 0);
  out.odds_now_max = Math.max(0, Number(out.odds_now_max) || 0);
  out.odds_change_pct_min = Math.max(0, Number(out.odds_change_pct_min) || 0);
  if (typeof out.scores === "string") {
    out.scores = out.scores.split(",").map(x => x.trim()).filter(Boolean);
  } else if (Array.isArray(out.scores)) {
    out.scores = out.scores.map(x => String(x).trim()).filter(Boolean);
  } else {
    out.scores = [];
  }
  out.countries = Array.isArray(out.countries) ? out.countries : [];
  return out;
}

function getActiveNotifyProfile() {
  const raw = localStorage.getItem(NOTIFY_PROFILE_ACTIVE_KEY) || "1";
  return NOTIFY_PROFILE_IDS.includes(String(raw)) ? String(raw) : "1";
}

function setActiveNotifyProfile(id) {
  const k = NOTIFY_PROFILE_IDS.includes(String(id)) ? String(id) : "1";
  localStorage.setItem(NOTIFY_PROFILE_ACTIVE_KEY, k);
  return k;
}

function legacyNotifyFilter() {
  try { return JSON.parse(localStorage.getItem(NOTIFY_FILTER_KEY) || "null"); }
  catch { return null; }
}

function normalizeNotifyProfilesStore(store, preferredActive = null) {
  const normalized = {};
  const legacy = legacyNotifyFilter();
  for (const id of NOTIFY_PROFILE_IDS) {
    const src = store?.[id] || (id === "1" ? (legacy || defaultNotifyFilter()) : defaultNotifyFilter());
    normalized[id] = normalizeNotifyFilter(src);
  }

  // Одновременно может работать только один профиль уведомлений.
  // Если в старых настройках включено несколько, оставляем активный/первый, остальные OFF.
  const active = NOTIFY_PROFILE_IDS.includes(String(preferredActive || "")) ? String(preferredActive) : getActiveNotifyProfile();
  const enabledIds = NOTIFY_PROFILE_IDS.filter(id => !!normalized[id]?.enabled);
  if (enabledIds.length > 1) {
    const keep = enabledIds.includes(active) ? active : enabledIds[0];
    for (const id of NOTIFY_PROFILE_IDS) normalized[id].enabled = id === keep;
    setActiveNotifyProfile(keep);
  }
  return normalized;
}

function getNotifyProfiles() {
  let store = {};
  try { store = JSON.parse(localStorage.getItem(NOTIFY_PROFILE_STORE_KEY) || "{}") || {}; }
  catch { store = {}; }
  const normalized = normalizeNotifyProfilesStore(store);
  try { localStorage.setItem(NOTIFY_PROFILE_STORE_KEY, JSON.stringify(normalized)); } catch (_) {}
  return normalized;
}

function saveNotifyProfiles(store, preferredActive = null) {
  const normalized = normalizeNotifyProfilesStore(store, preferredActive);
  localStorage.setItem(NOTIFY_PROFILE_STORE_KEY, JSON.stringify(normalized));
  return normalized;
}

function setOnlyNotifyProfileEnabled(activeId, enabled) {
  const active = setActiveNotifyProfile(activeId || getActiveNotifyProfile());
  const profiles = getNotifyProfiles();
  for (const id of NOTIFY_PROFILE_IDS) profiles[id].enabled = id === active ? !!enabled : false;
  const normalized = saveNotifyProfiles(profiles, active);
  localStorage.setItem(NOTIFY_ENABLED_KEY, normalized[active].enabled ? "1" : "0");
  localStorage.setItem(NOTIFY_FILTER_KEY, JSON.stringify(normalized[active]));
  return normalized[active];
}

function getNotifyFilter() {
  const profiles = getNotifyProfiles();
  return profiles[getActiveNotifyProfile()] || normalizeNotifyFilter(defaultNotifyFilter());
}

function saveNotifyFilter(f) {
  const profiles = getNotifyProfiles();
  const active = getActiveNotifyProfile();
  profiles[active] = normalizeNotifyFilter(f);
  if (profiles[active].enabled) {
    for (const id of NOTIFY_PROFILE_IDS) if (id !== active) profiles[id].enabled = false;
  }
  const normalized = saveNotifyProfiles(profiles, active);
  // Keep the old key updated for backward compatibility with older builds.
  localStorage.setItem(NOTIFY_FILTER_KEY, JSON.stringify(normalized[active]));
  localStorage.setItem(NOTIFY_ENABLED_KEY, normalized[active].enabled ? "1" : "0");
}

function getNotifyEnabled() { return !!getNotifyFilter().enabled; }
function setNotifyEnabled(v) { setOnlyNotifyProfileEnabled(getActiveNotifyProfile(), !!v); }
function isGoalWaitPushEnabled() { return getGoalWaitNotifyEnabled() || getNotifyEnabled(); }

function syncNotifyFilterToServer(cfg, opts = {}) {
  if (!tg?.initData) {
    if (opts.warn) {
      try { tg?.showAlert?.("Telegram-уведомления работают только при открытии Mini App из Telegram."); } catch (_) {}
    }
    return Promise.resolve({ ok: false, error: "no_init_data" });
  }
  const body = JSON.stringify({
    init_data: tg.initData,
    filter: cfg,
    profile_id: getActiveNotifyProfile(),
  });

  const sendFetch = () => fetch("/api/subscribe", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body,
    keepalive: !!opts.keepalive,
  }).then(async (res) => {
    let data = {};
    try { data = await res.json(); } catch (_) {}
    if (!res.ok || data.ok === false) {
      throw new Error(data.error || `HTTP ${res.status}`);
    }
    if (data.warning && opts.warn) {
      try { tg?.showAlert?.("Сервер принял настройки, но Telegram-токен бота не настроен. Сообщения в Telegram не будут приходить, пока BOT_TOKEN не задан на сервере."); } catch (_) {}
    }
    return data;
  });

  if (opts.beacon && navigator.sendBeacon) {
    try {
      const blob = new Blob([body], { type: "application/json" });
      if (navigator.sendBeacon("/api/subscribe", blob)) return Promise.resolve({ ok: true, beacon: true });
    } catch (_) {}
  }

  return sendFetch().catch((err) => {
    // One retry helps when Telegram closes the WebView immediately after toggle.
    setTimeout(() => { sendFetch().catch(() => {}); }, 2500);
    if (opts.warn) {
      const msg = String(err && err.message || err || "");
      try { tg?.showAlert?.(`Не удалось включить Telegram-уведомления. Открой приложение заново через Telegram и попробуй ещё раз.\n\n${msg}`); } catch (_) {}
    }
    return { ok: false, error: String(err && err.message || err || "") };
  });
}

function syncCurrentNotifyStateToServer(opts = {}) {
  if (!tg?.initData) return;
  // Keep Telegram delivery server-side even after the Mini App is closed.
  // This sync registers the chat_id/filter/Ждём гол state on every fresh open
  // and again on pagehide using sendBeacon/keepalive.
  syncNotifyFilterToServer(getNotifyFilter(), opts);
}

function switchNotifyProfile(id) {
  // Keep the global notification state when switching profiles. Previously the
  // target profile's saved OFF flag was read after setActiveNotifyProfile(), so
  // switching from an enabled profile silently disabled all Telegram pushes.
  const before = getNotifyProfiles();
  const wasEnabled = NOTIFY_PROFILE_IDS.some(pid => !!before?.[pid]?.enabled);
  const active = setActiveNotifyProfile(id);
  const cfg = setOnlyNotifyProfileEnabled(active, wasEnabled);
  syncNotifyFilterToServer(cfg, { keepalive: true, warn: true });
  if (cfg.enabled) {
    checkNotifyMatches();
    checkGoalWaitNotifyMatches();
  }
  render();
}

function renderNotifyProfileSwitch(mode = "panel") {
  const active = getActiveNotifyProfile();
  const profiles = getNotifyProfiles();
  return `<div class="notify-profile-switch ${mode}">
    ${NOTIFY_PROFILE_IDS.map(id => {
      const p = profiles[id] || defaultNotifyFilter();
      const isActive = id === active;
      const status = p.enabled ? "ON" : "OFF";
      return `<button class="notify-profile-btn ${isActive ? "active" : ""}" onclick="switchNotifyProfile('${id}')">
        <strong>Профиль ${id}</strong><span>${status}</span>
      </button>`;
    }).join("")}
  </div>`;
}

function getSeenAlerts() {
  try { return new Set(JSON.parse(localStorage.getItem(NOTIFY_SEEN_KEY) || "[]")); }
  catch { return new Set(); }
}
function saveSeenAlerts(s) {
  const arr = [...s];
  if (arr.length > 200) arr.splice(0, arr.length - 200);
  localStorage.setItem(NOTIFY_SEEN_KEY, JSON.stringify(arr));
}

// ============================================================
//  State
// ============================================================
const state = {
  view: "matches",          // matches | favorites | notify | detail | team
  live: null,
  prematch: null,
  loading: true,
  prematchLoading: false,
  feedMode: "live",
  prematchDate: "all",
  prematchDetailTab: "overview",
  teamTab: "stats",
  teamData: null,
  teamLoading: false,
  teamError: "",
  teamSide: "home",
  teamRequest: null,
  teamReturnView: "detail",
  teamNavStack: [],
  competitionTab: "overview",
  competitionData: null,
  competitionLoading: false,
  competitionError: "",
  competitionPath: "",
  competitionSeason: "",
  competitionReturnView: "matches",
  competitionMatchFilter: "all",
  competitionRound: "all",
  selectedMatch: null,
  detailReturnView: "matches",
  detail: null,
  detailTab: "details",   // details | stats | matches | trends | table
  detailMatchesSide: "home", // home | away
  avgTotalOpen: false,
  avgTotalLoading: false,
  avgTotalData: null,
  avgTotalError: "",
  preset: "all",
  search: "",
  mainTab: "all",             // all | goal_wait
  filters: {                // main feed filters
    minute_min: 1, minute_max: 130,
    shots_min: 0, on_target_min: 0, off_target_min: 0,
    dangerous_min: 0, attacks_min: 0,
    corners_min: 0, yellow_cards_min: 0, red_cards_min: 0,
    possession_min: 0,
    scores: "",
  },
  sheet: null,              // "filters" | "notify-edit" | null
  notifyTab: "found",       // found | filter
  notifyMatches: [],
  notifyMatchesLoading: false,
  inAppAlerts: [],          // [{matchId, ts, title}]
  unreadAlerts: 0,
  favoriteRefreshAt: {},
  favoriteRefreshRunning: false,
  matchScrollY: 0,
  matchScrollAnchorId: "",
  matchScrollAnchorOffset: 0,
  detailNavIds: [],
  detailNavIndex: -1,
  detailBootRestoreTried: false,
  detailToast: "",
  onlineGate: { checked: false, allowed: false, online: 0, limit: 100, message: "" },
};

const app = document.getElementById("app");

const ONLINE_CLIENT_KEY = "miniapp-v9-online-client-id";
let _onlineHeartbeatTimer = null;

function getOnlineClientId() {
  try {
    const tgId = telegramChatId();
    if (tgId) return `tg-${tgId}`;
  } catch (_) {}
  try {
    let id = localStorage.getItem(ONLINE_CLIENT_KEY) || "";
    if (!id) {
      const rnd = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
      id = `web-${rnd}`;
      localStorage.setItem(ONLINE_CLIENT_KEY, id);
    }
    return id;
  } catch (_) {
    return `tmp-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }
}

function renderOnlineBlocked(payload = {}) {
  const online = safeInt(payload.online ?? state.onlineGate.online, 0);
  const limit = safeInt(payload.limit ?? state.onlineGate.limit, 100);
  const reason = String(payload.reason || payload.error || "");
  const accessProblem = ["subscription_required", "blocked", "telegram_required", "access_denied"].includes(reason);
  const title = reason === "blocked"
    ? "Доступ заблокирован"
    : (reason === "subscription_required" ? "Требуется подписка" : (reason === "telegram_required" ? "Откройте в Telegram" : "Лимит онлайн заполнен"));
  const message = String(payload.message || "").trim();
  const body = accessProblem
    ? esc(message || "Доступ к приложению сейчас недоступен.")
    : `Сейчас в приложении <b>${online}</b> из <b>${limit}</b> пользователей. Новых пользователей временно не пускаем.`;
  app.innerHTML = `
    <div class="online-limit-screen">
      <div class="online-limit-card">
        <div class="online-limit-icon">${accessProblem ? "🔒" : "👥"}</div>
        <div class="online-limit-title">${esc(title)}</div>
        <div class="online-limit-text">${body}</div>
        <button class="online-limit-btn" onclick="retryOnlineGate()">Проверить ещё раз</button>
      </div>
    </div>
  `;
}

async function checkOnlineGate(showBlock = true) {
  try {
    const res = await fetch("/api/online/checkin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      cache: "no-store",
      body: JSON.stringify({ init_data: tg?.initData || "", client_id: getOnlineClientId() }),
    });
    const payload = await res.json().catch(() => ({}));
    state.onlineGate = {
      checked: true,
      allowed: !!payload.allowed,
      online: safeInt(payload.online, 0),
      limit: safeInt(payload.limit, 100),
      message: String(payload.message || ""),
    };
    if (!payload.allowed) {
      if (showBlock) renderOnlineBlocked(payload);
      return false;
    }
    return true;
  } catch (_) {
    // Не блокируем пользователей при временной ошибке сети/сервера.
    state.onlineGate = { checked: true, allowed: true, online: 0, limit: 100, message: "" };
    return true;
  }
}

async function retryOnlineGate() {
  const ok = await checkOnlineGate(true);
  if (ok) {
    state.loading = true;
    await loadLive(true);
    setTimeout(() => openStartupMatchIfAny(), 250);
  }
}

function startOnlineHeartbeat() {
  if (_onlineHeartbeatTimer) return;
  _onlineHeartbeatTimer = setInterval(() => {
    if (!document.hidden) checkOnlineGate(false);
  }, ONLINE_HEARTBEAT_INTERVAL_MS);
}

// ============================================================
//  Utilities
// ============================================================
function currentScrollY() {
  return window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
}

function saveMatchListPosition(anchorId = "") {
  if (state.view !== "matches") return;
  state.matchScrollY = currentScrollY();

  const cssEscapeValue = (v) => (window.CSS && CSS.escape) ? CSS.escape(String(v)) : String(v).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  let anchorEl = anchorId ? document.querySelector(`.match-row[data-id="${cssEscapeValue(anchorId)}"]`) : null;
  if (!anchorEl) {
    const stickyOffset = 76; // topbar height area
    anchorEl = Array.from(document.querySelectorAll(".match-row"))
      .find(el => el.getBoundingClientRect().bottom > stickyOffset) || null;
  }

  if (anchorEl) {
    state.matchScrollAnchorId = String(anchorEl.dataset.id || anchorId || "");
    state.matchScrollAnchorOffset = Math.round(anchorEl.getBoundingClientRect().top);
  } else if (anchorId) {
    state.matchScrollAnchorId = String(anchorId);
    state.matchScrollAnchorOffset = 76;
  }
}

function restoreMatchListPosition() {
  if (state.view !== "matches") return;
  const y = safeInt(state.matchScrollY, 0);
  const anchorId = String(state.matchScrollAnchorId || "");
  const offset = safeInt(state.matchScrollAnchorOffset, 76);

  const apply = () => {
    if (anchorId) {
      const safeId = (window.CSS && CSS.escape) ? CSS.escape(anchorId) : anchorId.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
      const el = document.querySelector(`.match-row[data-id="${safeId}"]`);
      if (el) {
        const nextTop = currentScrollY() + el.getBoundingClientRect().top - offset;
        window.scrollTo({ top: Math.max(0, nextTop), left: 0, behavior: "auto" });
        return;
      }
    }
    if (y > 0) window.scrollTo({ top: y, left: 0, behavior: "auto" });
  };
  requestAnimationFrame(() => requestAnimationFrame(apply));
}

function esc(v) {
  return String(v ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

function clamp(n, lo, hi) { return Math.max(lo, Math.min(hi, n)); }

function safeInt(v, def = 0) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : def;
}

function normalizeMatchMinuteValue(v) {
  const n = safeInt(v, 0);
  if (n >= 130) return 0;
  return clamp(n, 0, 129);
}

function normalizeMatchMinuteText(value, minute = 0) {
  const raw = String(value || "").trim();
  const m = raw.match(/(\d{1,4})/);
  if ((m && safeInt(m[1], 0) >= 130) || safeInt(minute, 0) >= 130) return "";
  return raw || (minute > 0 ? `${normalizeMatchMinuteValue(minute)}’` : "LIVE");
}

// v9.13: fallback country-code inference for league headers when the backend
// receives only a continent such as AFRICA or gets an empty country_code.
const COUNTRY_FLAG_CODE_MAP = {
  "tanzania": "TZ", "tanzanian": "TZ", "tanzanian premier": "TZ",
  "uganda": "UG", "ugandan": "UG", "uganda premier": "UG",
  "dr congo": "CD", "drc": "CD", "congo dr": "CD",
  "democratic republic of the congo": "CD", "democratic republic congo": "CD",
  "congo kinshasa": "CD", "vodacom ligue": "CD",
  "congo": "CG",
  "ethiopia": "ET", "ethiopian": "ET", "kenya": "KE", "kenyan": "KE",
  "rwanda": "RW", "rwandan": "RW", "ghana": "GH", "ghanaian": "GH",
  "nigeria": "NG", "nigerian": "NG", "south africa": "ZA",
  "zambia": "ZM", "zambian": "ZM", "zimbabwe": "ZW", "zimbabwean": "ZW",
  "angola": "AO", "angolan": "AO", "mozambique": "MZ", "mozambican": "MZ",
  "senegal": "SN", "mali": "ML", "cameroon": "CM", "cameroonian": "CM",
  "liberia": "LR", "sierra leone": "SL", "gambia": "GM", "guinea": "GN",
  "burkina faso": "BF", "malawi": "MW", "lesotho": "LS", "eswatini": "SZ",
  "morocco": "MA", "moroccan": "MA", "tunisia": "TN", "algeria": "DZ", "egypt": "EG",
  "sudan": "SD", "libya": "LY", "somalia": "SO", "eritrea": "ER", "djibouti": "DJ",
  // v9.23: common AMERICAS leagues where the provider gives only a region.
  "arg": "AR", "argentina": "AR", "arg primera nacional": "AR", "primera nacional": "AR",
  "barbados": "BB", "barbadian": "BB", "barbados premier": "BB", "barbados premier league": "BB",
  "colombia": "CO", "colombian": "CO", "categoria primera a": "CO", "categor a primera a": "CO", "categoría primera a": "CO",
  "dominican": "DO", "dominicana": "DO", "dominican republic": "DO", "liga dominicana": "DO", "liga dominicana de futbol": "DO", "liga dominicana de fútbol": "DO",
  "usa": "US", "united states": "US", "usl": "US", "usl league two": "US",
  // v9.25: more single-country leagues seen in screenshots.
  // Sweden — "Sweden Division 1" league title.
  "sweden": "SE", "swedish": "SE", "sweden division": "SE", "swedish division": "SE",
  // Yemen — "Yemen League Division 1".
  "yemen": "YE", "yemeni": "YE", "yemen league": "YE", "yemen league division": "YE",
  // Japan — "J2/J3 100 Year Vision League" (after non-alnum is normalised the
  // haystack becomes "j2 j3 100 year vision league"). Match the league-stub
  // tokens and the distinctive phrase.
  "japan": "JP", "japanese": "JP",
  "j1": "JP", "j2": "JP", "j3": "JP", "j2 j3": "JP", "j league": "JP", "j-league": "JP",
  "100 year vision": "JP", "100 year vision league": "JP",
  // Brazil — the provider uses "BRA LP" / "BRA Serie X" prefixes for Brazilian
  // domestic leagues. Match the standalone "bra lp" phrase plus the regular
  // country name.
  "brazil": "BR", "brazilian": "BR", "bra lp": "BR", "bra serie": "BR", "brasileiro": "BR",
  // Zanzibar Premier League — Zanzibar is an autonomous region of Tanzania;
  // football there flies the Tanzanian flag at FIFA/CAF level.
  "zanzibar": "TZ", "zanzibar premier": "TZ", "zanzibar premier league": "TZ",
  // SAND2 — SAFA SAB ("Sand 2") is a South African lower-tier division.
  // "Maties FC" + "Grassy Park United" confirm Western Cape origin.
  "sand2": "ZA", "sand 2": "ZA", "safa sab": "ZA",
  // China youth/school league seen under ASIA in IGScore.
  "national youth school football league": "CN", "youth school football league": "CN",
  "ningbo university": "CN", "guizhou police academy": "CN", "chongqing normal university": "CN", "kashi university": "CN",
  // v9.53: extra league aliases from user screenshots.
  "honduras": "HN", "honduran": "HN", "hor l": "HN",
  "paraguay": "PY", "paraguayan": "PY", "par d3": "PY", "par d": "PY",
  "peru": "PE", "peruvian": "PE", "per liga femenina": "PE", "liga femenina": "PE",
  "russia": "RU", "russian": "RU", "rus m league": "RU", "m league": "RU",
  "north macedonia": "MK", "macedonia": "MK", "macedonian": "MK", "first football league": "MK",
  "kuwait": "KW", "kuwaiti": "KW", "kuwaiti premier league": "KW",
  // v9.57: more leagues from new screenshots.
  "australia": "AU", "australian": "AU",
  "national premier leagues victoria": "AU", "national premier leagues victoria 2": "AU", "national premier leagues victoria 3": "AU",
  "qld d2": "AU", "queensland": "AU", "western australia state league 1": "AU", "nswsl": "AU", "aus u20 nswsl": "AU",
  "indonesia": "ID", "indonesian": "ID", "indonesian super league": "ID",
  "philippines": "PH", "philippine": "PH", "philippines united football league": "PH",
  "china": "CN", "chinese": "CN", "yunnan city football league": "CN", "hubei city football league": "CN", "shandong qilu football super league": "CN", "sichuan city football league": "CN",
  // v9.62: extra country/league aliases from new user screenshots.
  "czech republic": "CZ", "czechia": "CZ", "czech": "CZ", "chance narodni liga": "CZ", "chance narodna liga": "CZ", "chance narodni": "CZ",
  "bosnia": "BA", "bosnia and herzegovina": "BA", "bih": "BA", "bih pl fbih": "BA", "bih pl rs": "BA", "pl fbih": "BA", "pl rs": "BA",
  "estonia": "EE", "estonia": "EE", "esiliiga b": "EE",
  "faroe islands": "FO", "faeroe islands": "FO", "faroe islands division 1": "FO",
  "poland": "PL", "polish": "PL", "ekstraklasa": "PL", "pko bank polski ekstraklasa": "PL",
  "san marino": "SM", "campionato di calcio": "SM", "san marino campionato di calcio": "SM",
  "switzerland": "CH", "swiss": "CH", "sui d4": "CH",
  "kyrgyzstan": "KG", "kyrgyz": "KG", "kyrgyz premier league": "KG",
  "portugal": "PT", "portuguese": "PT", "por u19 b": "PT",
  "germany": "DE", "german": "DE", "ger jbh": "DE",
  "netherlands": "NL", "dutch": "NL", "netherlands u21": "NL",
  "finland": "FI", "finnish": "FI", "fin u21 league": "FI",
  "mexico": "MX", "mexican": "MX", "mex u21": "MX",
  "bra cp u20": "BR",
  "jiangsu city football league": "CN", "wuyue cup": "CN",
  "rus d3a": "RU", "rus d3b": "RU",
  // v9.63: even more league aliases from the latest screenshots.
  "spa trfef po": "ES", "trfef po": "ES",
  "guangdong city football league": "CN",
  "rural football super league": "CN",
  "aus npl u23": "AU",
  "new zealand": "NZ", "new zealand northern premier league": "NZ",
  // v9.66: extra flag aliases from latest user screenshots.
  "eredivisie": "NL", "netherlands eredivisie": "NL",
  "andorra": "AD", "andorran": "AD", "andorran primera divisio": "AD", "primera divisio": "AD",
  "south australia reserve league": "AU", "south australia": "AU",
  "fiji": "FJ", "fijian": "FJ", "fijian national league": "FJ",
  "chi liga de ascenso": "CL", "chi liga de primera": "CL",
  "lux l1 w": "LU",
  "ireland women s league": "IE", "ireland women's league": "IE",
  "curacao": "CW", "cura ao": "CW", "curacao liga mcb 1st division": "CW", "liga mcb 1st division": "CW",
  "ecuador": "EC", "ecuadorian": "EC", "ligapro serie a": "EC",
  // v9.82: extra flag aliases from Railway screenshots.
  // The provider sometimes groups these under EUROPE / AMERICAS / OTHERS and leaves country_code empty.
  "france": "FR", "french": "FR", "fra": "FR", "fra wd2": "FR", "france wd2": "FR",
  "france women division 2": "FR", "division 2 feminine": "FR", "d2 feminine": "FR",
  "italy": "IT", "italian": "IT", "ita": "IT", "italy amateur": "IT",
  "italy amateur eccellenza": "IT", "italy amateur eccellenza puglia": "IT", "eccellenza puglia": "IT",
  "arfc": "AR", "argentine regional federal amateur": "AR", "regional federal amateur": "AR",
  "bcu20": "BR", "bcu20 women": "BR", "bc u20 women": "BR", "brazil u20 women": "BR",
  "brazil campeonato u20 women": "BR"
};

function inferCountryCodeFromText(...parts) {
  const text = parts.map(x => String(x || "").toLowerCase()).join(" ");
  const ascii = text.normalize ? text.normalize("NFD").replace(/[\u0300-\u036f]/g, "") : text;
  const clean = ascii.replace(/[^a-z0-9\s-]+/g, " ").replace(/\s+/g, " ").trim();
  if (!clean) return "";
  const ordered = Object.keys(COUNTRY_FLAG_CODE_MAP).sort((a, b) => b.length - a.length);
  for (const key of ordered) {
    const k = key.toLowerCase().normalize ? key.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "") : key.toLowerCase();
    const re = new RegExp(`(^|[^a-z0-9])${k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^a-z0-9]|$)`);
    if (re.test(clean)) return COUNTRY_FLAG_CODE_MAP[key];
  }
  return "";
}

function flagSvg(code, countryName) {
  const cc = String(code || "").trim().toLowerCase();
  if (cc && cc.length === 2) {
    // v7: higher-res flag (w80) for crisp circular cropping at 24px.
    const url = `https://flagcdn.com/w80/${esc(cc)}.png`;
    const fallback = continentEmoji(countryName);
    return `<img src="${url}" alt="${esc(cc.toUpperCase())}" loading="lazy" referrerpolicy="no-referrer" onerror="this.replaceWith(Object.assign(document.createElement('span'), {className:'flag-fallback', textContent:${JSON.stringify(fallback)}}))" />`;
  }
  // v6: no country code — show a continent emoji instead of plain globe.
  return `<span class="flag-fallback">${esc(continentEmoji(countryName))}</span>`;
}

function countryFlagImg(code, label = "") {
  const cc = String(code || "").trim().toLowerCase();
  if (!cc || cc.length !== 2) return "";
  const url = `https://flagcdn.com/w40/${esc(cc)}.png`;
  return `<img class="mini-flag" src="${url}" alt="${esc(label || cc.toUpperCase())}" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()" />`;
}

function multiLeagueFlag(g) {
  const country = String(g?.country || "").toLowerCase();
  const league = String(g?.league || "").toLowerCase();
  const text = `${country} ${league}`;

  // Continental South America competitions: show a small stack of country flags
  // instead of a generic globe so the league cards do not look like "world".
  if (/conmebol|libertadores|sudamericana|south america/.test(text)) {
    const flags = [
      countryFlagImg("ar", "Argentina"),
      countryFlagImg("br", "Brazil"),
      countryFlagImg("co", "Colombia"),
      countryFlagImg("ec", "Ecuador"),
    ].filter(Boolean).join("");
    if (flags) return `<span class="flag-multi flag-multi-4" title="South America">${flags}</span>`;
    return `<span class="flag-emoji-stack" title="South America">🇦🇷🇧🇷🇨🇴🇪🇨</span>`;
  }

  // OFC/Oceania competitions.
  if (/ofc|oceania/.test(text)) {
    const flags = [
      countryFlagImg("nz", "New Zealand"),
      countryFlagImg("au", "Australia"),
      countryFlagImg("fj", "Fiji"),
      countryFlagImg("pg", "Papua New Guinea"),
    ].filter(Boolean).join("");
    if (flags) return `<span class="flag-multi flag-multi-4" title="Oceania">${flags}</span>`;
    return `<span class="flag-emoji-stack" title="Oceania">🇳🇿🇦🇺🇫🇯🇵🇬</span>`;
  }

  return "";
}

function continentEmoji(countryName) {
  const k = String(countryName || "").trim().toLowerCase();
  if (CONTINENT_FLAG_EMOJI[k]) return CONTINENT_FLAG_EMOJI[k];
  return "🌐";
}

function initials(name) {
  const s = String(name || "").trim();
  if (!s) return "FC";
  const parts = s.replace(/[^\p{L}\p{N} ]/gu, " ").split(/\s+/).filter(Boolean);
  if (parts.length === 1) return parts[0].slice(0, 3).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}


function teamLogoSmall(m, side) {
  const name = side === "home" ? m.home : m.away;
  const url = String(m?.[`${side}_logo`] || "").trim();
  return `
    <span class="team-logo-small ${url ? "" : "logo-error"}" aria-hidden="true">
      ${url ? `<img src="${esc(url)}" alt="" loading="lazy" onerror="this.parentElement.classList.add('logo-error')" />` : ""}
      <span class="logo-fallback">${esc(initials(name))}</span>
    </span>
  `;
}

function teamBadge(m, side) {
  const name = side === "home" ? m.home : m.away;
  const url = String(m?.[`${side}_logo`] || "").trim();
  return `
    <div class="team-badge ${url ? "" : "logo-error"}">
      ${url ? `<img src="${esc(url)}" alt="${esc(name)}" loading="lazy" onerror="this.parentElement.classList.add('logo-error')" />` : ""}
      <span class="logo-fallback">${esc(initials(name))}</span>
    </div>
  `;
}

function openPrematchTeamStats(side, event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  const matchId = String(state.detail?.match?.id || state.selectedMatch || "").trim();
  if (!matchId) return false;
  loadTeamStats(matchId, side === "away" ? "away" : "home");
  return false;
}

function renderPrematchTeamCard(m, side) {
  const name = side === "home" ? m.home : m.away;
  const content = `${teamBadge(m, side)}<div class="team-name-big">${esc(name)}</div>`;
  return `<button type="button" class="scoreboard-team prematch-team-link" onclick="return openPrematchTeamStats('${side}',event)" title="Статистика команды ${esc(name)}">${content}<span class="prematch-team-link-hint">Статистика ›</span></button>`;
}


let _loadTeamSeq = 0;
let _loadCompetitionSeq = 0;

function snapshotTeamView() {
  return {
    teamData: state.teamData,
    teamTab: state.teamTab,
    teamSide: state.teamSide,
    teamRequest: state.teamRequest,
    teamError: state.teamError,
    teamLoading: false,
    teamReturnView: state.teamReturnView,
  };
}

async function loadTeamRequest(request, opts = {}) {
  const seq = ++_loadTeamSeq;
  const pushHistory = !!opts.pushHistory && state.view === "team" && state.teamData;
  if (pushHistory) state.teamNavStack.push(snapshotTeamView());
  if (!pushHistory) {
    state.teamNavStack = [];
    state.teamReturnView = opts.returnView || (state.view === "competition" ? "competition" : state.view === "detail" ? "detail" : "matches");
  }
  state.teamRequest = request;
  state.teamSide = request.side === "away" ? "away" : "home";
  state.teamTab = "stats";
  state.teamData = null;
  state.teamError = "";
  state.teamLoading = true;
  state.view = "team";
  render();
  try {
    const params = new URLSearchParams();
    if (request.matchId) {
      params.set("match_id", request.matchId);
      params.set("side", state.teamSide);
    } else {
      params.set("team_id", request.teamId || "");
      if (request.teamName) params.set("team_name", request.teamName);
      if (request.competitionPath) params.set("competition_path", request.competitionPath);
    }
    params.set("sport", request.sport || state.detail?.match?.sport || state.teamData?.team?.sport || state.sport || "football");
    const res = await fetch(`/api/team?${params.toString()}`, { cache: "no-store" });
    const payload = await res.json();
    if (seq !== _loadTeamSeq) return;
    if (!res.ok || !payload?.ok) throw new Error(payload?.error || `HTTP ${res.status}`);
    state.teamData = payload;
  } catch (err) {
    if (seq !== _loadTeamSeq) return;
    state.teamError = String(err?.message || err || "Не удалось загрузить статистику команды");
  } finally {
    if (seq !== _loadTeamSeq) return;
    state.teamLoading = false;
    render();
  }
}

function loadTeamStats(matchId, side = "home", returnView = "detail", sport = "") {
  const mid = String(matchId || "").trim();
  if (!mid) return;
  return loadTeamRequest({ matchId: mid, side: side === "away" ? "away" : "home", sport: sport || state.detail?.match?.sport || state.sport }, { returnView });
}

function loadTeamById(teamId, teamName = "", competitionPath = "", returnView = null, pushHistory = false, sport = "") {
  const tid = String(teamId || "").trim();
  if (!tid) return;
  return loadTeamRequest({ teamId: tid, teamName: String(teamName || ""), competitionPath: String(competitionPath || ""), sport: sport || state.teamData?.team?.sport || state.sport }, {
    returnView: returnView || (state.view === "competition" ? "competition" : state.view === "team" ? state.teamReturnView : "matches"),
    pushHistory,
  });
}

function openTeamFromInternal(teamId, teamName, competitionPath, event, sport = "") {
  if (event) { event.preventDefault(); event.stopPropagation(); }
  const fromTeam = state.view === "team";
  loadTeamById(teamId, teamName, competitionPath, fromTeam ? state.teamReturnView : state.view, fromTeam, sport || state.teamData?.team?.sport || state.sport);
  return false;
}

function retryTeamStats() {
  if (state.teamRequest) loadTeamRequest(state.teamRequest, { returnView: state.teamReturnView });
}

function setTeamTab(tab) {
  const next = tab === "matches" ? "matches" : "stats";
  if (state.teamTab === next) return;
  state.teamTab = next;
  render();
}

function closeTeamStats() {
  ++_loadTeamSeq;
  const previous = state.teamNavStack.pop();
  if (previous) {
    Object.assign(state, previous);
    state.view = "team";
    render();
    return;
  }
  state.view = state.teamReturnView || "matches";
  state.teamLoading = false;
  state.teamError = "";
  render();
}

async function loadCompetition(path, name = "", opts = {}) {
  const cleanPath = String(path || "").trim();
  if (!cleanPath) return;
  const seq = ++_loadCompetitionSeq;
  if (!opts.keepReturn) state.competitionReturnView = opts.returnView || (state.view === "team" ? "team" : state.view === "detail" ? "detail" : "matches");
  state.competitionPath = cleanPath;
  state.competitionSeason = String(opts.season || "");
  state.competitionTab = opts.tab || "overview";
  state.competitionMatchFilter = opts.keepFilter ? state.competitionMatchFilter : "all";
  state.competitionRound = String(opts.round || "all");
  state.competitionData = null;
  state.competitionError = "";
  state.competitionLoading = true;
  state.view = "competition";
  render();
  try {
    const params = new URLSearchParams({ path: cleanPath });
    if (state.competitionSeason) params.set("season", state.competitionSeason);
    if (state.competitionRound && state.competitionRound !== "all") params.set("round", state.competitionRound);
    if (opts.force) params.set("force", "1");
    const res = await fetch(`/api/competition?${params.toString()}`, { cache: "no-store" });
    const payload = await res.json();
    if (seq !== _loadCompetitionSeq) return;
    if (!res.ok || !payload?.ok) throw new Error(payload?.error || `HTTP ${res.status}`);
    state.competitionData = payload;
  } catch (err) {
    if (seq !== _loadCompetitionSeq) return;
    state.competitionError = String(err?.message || err || "Не удалось загрузить турнир");
  } finally {
    if (seq !== _loadCompetitionSeq) return;
    state.competitionLoading = false;
    render();
  }
}

function openCompetition(path, name = "", event, returnView = null) {
  if (event) { event.preventDefault(); event.stopPropagation(); }
  const cleanPath = String(path || "").trim();
  if (!cleanPath) return false;
  loadCompetition(cleanPath, name, { returnView: returnView || state.view });
  return false;
}

function retryCompetition() {
  if (state.competitionPath) loadCompetition(state.competitionPath, "", { returnView: state.competitionReturnView, season: state.competitionSeason, round: state.competitionRound, keepReturn: true, keepFilter: true, force: true, tab: state.competitionTab });
}

function closeCompetition() {
  ++_loadCompetitionSeq;
  state.view = state.competitionReturnView || "matches";
  state.competitionLoading = false;
  state.competitionError = "";
  render();
}

function setCompetitionTab(tab) {
  const allowed = new Set(["overview", "matches", "table", "players", "stats", "teams", "bracket"]);
  state.competitionTab = allowed.has(tab) ? tab : "overview";
  render();
}

function setCompetitionMatchFilter(value) {
  state.competitionMatchFilter = ["all", "upcoming", "results", "live"].includes(value) ? value : "all";
  render();
}

function setCompetitionRound(value) {
  const round = String(value || "all");
  loadCompetition(state.competitionPath, "", { returnView: state.competitionReturnView, season: state.competitionSeason, round, keepReturn: true, keepFilter: true, tab: "matches" });
}

function changeCompetitionSeason(value) {
  const seasonOrPath = String(value || "");
  if (seasonOrPath.startsWith("/football/competition/")) {
    loadCompetition(seasonOrPath, "", { returnView: state.competitionReturnView, season: "", round: "all", keepReturn: true, tab: state.competitionTab });
  } else {
    loadCompetition(state.competitionPath, "", { returnView: state.competitionReturnView, season: seasonOrPath, round: "all", keepReturn: true, tab: state.competitionTab });
  }
}

function teamPercent(value) {
  const n = Number(value);
  return Number.isFinite(n) ? `${Math.max(0, Math.min(100, Math.round(n)))}%` : "—";
}

function teamAverage(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toFixed(2) : "—";
}

function renderTeamHeroLogo(team) {
  const logo = String(team?.logo || "").trim();
  const name = String(team?.name || "Команда");
  return `<div class="team-page-logo ${logo ? "" : "logo-error"}"><span class="team-logo-glow"></span>${logo ? `<img src="${esc(logo)}" alt="${esc(name)}" loading="lazy" onerror="this.parentElement.classList.add('logo-error')" />` : ""}<span class="logo-fallback">${esc(initials(name))}</span></div>`;
}

function renderTeamHeroChips(summary = {}, sport = "football") {
  const basketball = sport === "basketball";
  const items = basketball ? [
    ["Форма", `${safeInt(summary.count, 0)} матч.`],
    ["Победы", teamPercent(summary.win_percent)],
    ["Очки/матч", teamAverage(summary.scored_avg)],
  ] : [
    ["Форма", `${safeInt(summary.count, 0)} матч.`],
    ["ТБ 2.5", teamPercent(summary.over_2_5_percent)],
    ["ОЗ", teamPercent(summary.btts_percent)],
  ];
  return items.map(([label, value]) => `<div class="team-hero-chip"><span>${esc(label)}</span><b>${esc(value)}</b></div>`).join("");
}

function renderTeamHeroSummary(summary = {}, sport = "football") {
  if (sport === "basketball") return `<div class="team-hero-summary">
    <div class="team-hero-summary-card is-win"><span>Победы</span><b>${safeInt(summary.wins)}</b></div>
    <div class="team-hero-summary-card is-loss"><span>Поражения</span><b>${safeInt(summary.losses)}</b></div>
    <div class="team-hero-summary-card is-draw"><span>Матчи</span><b>${safeInt(summary.count)}</b></div>
  </div>`;
  return `<div class="team-hero-summary">
    <div class="team-hero-summary-card is-win"><span>Победы</span><b>${safeInt(summary.wins)}</b></div>
    <div class="team-hero-summary-card is-draw"><span>Ничьи</span><b>${safeInt(summary.draws)}</b></div>
    <div class="team-hero-summary-card is-loss"><span>Поражения</span><b>${safeInt(summary.losses)}</b></div>
  </div>`;
}

function renderTeamResultPills(form) {
  const arr = Array.isArray(form) ? form.slice(0, 10) : [];
  if (!arr.length) return `<span class="prematch-empty-text">Нет данных</span>`;
  return arr.map(r => `<span class="team-result-pill ${String(r || "").toLowerCase()}">${esc(r || "·")}</span>`).join("");
}

function renderTeamStatCard(label, value, sub = "", tone = "") {
  const toneClass = tone ? ` ${tone}` : "";
  return `<div class="team-stat-card${toneClass}"><span>${esc(label)}</span><b>${esc(value)}</b>${sub ? `<em>${esc(sub)}</em>` : ""}</div>`;
}

function renderTeamSplit(title, s, sport = "football") {
  const count = safeInt(s?.count, 0);
  const record = sport === "basketball" ? `<b>${safeInt(s?.wins)}В</b><b>${safeInt(s?.losses)}П</b><b>${teamPercent(s?.win_percent)}</b>` : `<b>${safeInt(s?.wins)}В</b><b>${safeInt(s?.draws)}Н</b><b>${safeInt(s?.losses)}П</b>`;
  const scoredLabel = sport === "basketball" ? "Очки" : "Забито";
  const concededLabel = sport === "basketball" ? "Пропущено очков" : "Пропущено";
  return `<div class="team-split-card"><div class="team-split-title"><div>${esc(title)}</div><span>${count} матч.</span></div><div class="team-split-line">${record}</div><div class="team-split-line muted"><span>${scoredLabel} ${teamAverage(s?.scored_avg)}</span><span>${concededLabel} ${teamAverage(s?.conceded_avg)}</span></div><div class="team-split-progress"><i style="width:${Math.max(0, Math.min(100, count ? Math.round((safeInt(s?.wins) / Math.max(1, count)) * 100) : 0))}%"></i></div></div>`;
}

function renderInternalTeamMatch(row, upcoming = false) {
  const result = String(row?.result || "").toLowerCase();
  const dateTime = [row?.date, row?.time].filter(Boolean).join(" · ");
  const score = upcoming ? "VS" : `${safeInt(row?.score_home)}:${safeInt(row?.score_away)}`;
  const compPath = String(row?.competition_path || state.teamData?.team?.competition_path || "");
  const homeId = String(row?.home_id || "");
  const awayId = String(row?.away_id || "");
  const teamButton = (side, id, name) => {
    const selected = row?.side === side ? " selected" : "";
    const encodedId = encodeURIComponent(id || "");
    const encodedName = encodeURIComponent(name || "");
    const encodedPath = encodeURIComponent(compPath);
    if (!id) return `<span class="team-match-name${selected}">${esc(name || "")}</span>`;
    return `<button type="button" class="team-match-name team-match-link${selected}" onclick="return openTeamFromInternal(decodeURIComponent('${encodedId}'),decodeURIComponent('${encodedName}'),decodeURIComponent('${encodedPath}'),event,decodeURIComponent('${encodeURIComponent(row?.sport || state.teamData?.team?.sport || state.sport || "football")}'))">${esc(name || "")}</button>`;
  };
  const league = `<em>${esc(row?.league || "")}</em>`;
  return `<div class="team-match-row"><div class="team-match-meta"><span>${esc(dateTime || "—")}</span>${league}</div><div class="team-match-main">${teamButton("home",homeId,row?.home)}<strong>${esc(score)}</strong>${teamButton("away",awayId,row?.away)}${!upcoming && result ? `<i class="team-result-pill ${result}">${esc(String(row.result).toUpperCase())}</i>` : ""}</div></div>`;
}

function teamRatioText(value, count) {
  return `${safeInt(value)}/${safeInt(count)}`;
}

function teamSigned(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return "—";
  return n > 0 ? `+${n}` : String(n);
}

function renderTeamMaxCard(label, value, sub = "", tone = "green") {
  return `<div class="team-max-card tone-${esc(tone)}"><span>${esc(label)}</span><b>${esc(value)}</b>${sub ? `<em>${esc(sub)}</em>` : ""}</div>`;
}

function renderTeamRateRow(label, value, count, tone = "green") {
  const pct = Math.max(0, Math.min(100, safeInt(value)));
  return `<div class="team-rate-row"><div><span>${esc(label)}</span><b>${pct}%</b></div><div class="team-rate-track"><i class="tone-${esc(tone)}" style="width:${pct}%"></i></div>${count ? `<em>${esc(count)}</em>` : ""}</div>`;
}

function renderTeamStreakCard(label, current, longest = 0, tone = "green") {
  return `<div class="team-streak-card tone-${esc(tone)}"><span>${esc(label)}</span><b>${safeInt(current)}</b><em>макс. ${safeInt(longest)}</em></div>`;
}

function renderTeamStatsContent(data) {
  const s = data?.summary || {};
  const count = safeInt(s.count);
  const current = s.current_streaks || {};
  const longest = s.longest_streaks || {};
  if (!count) return `<div class="team-max-empty">Недостаточно завершённых матчей для расчёта статистики.</div>`;

  return `<div class="team-max-shell">
    <section class="team-max-section team-form-section">
      <div class="team-max-heading"><div><span>ФОРМА</span><h3>Последние ${count} матчей</h3></div><strong>${safeInt(s.points)} оч.</strong></div>
      <div class="team-form-row team-max-form">${renderTeamResultPills(s.form)}</div>
      <div class="team-max-wdl">
        <div class="win"><span>Победы</span><b>${safeInt(s.wins)}</b><em>${teamPercent(s.win_percent)}</em></div>
        <div class="draw"><span>Ничьи</span><b>${safeInt(s.draws)}</b><em>${teamPercent(s.draw_percent)}</em></div>
        <div class="loss"><span>Поражения</span><b>${safeInt(s.losses)}</b><em>${teamPercent(s.loss_percent)}</em></div>
      </div>
    </section>


    <section class="team-max-section">
      <div class="team-max-heading"><div><span>ГОЛЫ</span><h3>Атака и защита</h3></div></div>
      <div class="team-max-grid">
        ${renderTeamMaxCard("Забито за матч", teamAverage(s.scored_avg), `${safeInt(s.goals_for)} всего`, "green")}
        ${renderTeamMaxCard("Пропущено за матч", teamAverage(s.conceded_avg), `${safeInt(s.goals_against)} всего`, "red")}
        ${renderTeamMaxCard("Средний тотал", teamAverage(s.total_avg), "голов за матч", "lime")}
        ${renderTeamMaxCard("Максимальный тотал", safeInt(s.max_total), `минимум ${safeInt(s.min_total)}`, "gold")}
        ${renderTeamMaxCard("Максимум забито", safeInt(s.max_scored), "за один матч", "green")}
        ${renderTeamMaxCard("Максимум пропущено", safeInt(s.max_conceded), "за один матч", "red")}
      </div>
      <div class="team-rate-list">
        ${renderTeamRateRow("Забивала", s.scored_matches_percent, teamRatioText(s.scored_matches, count), "green")}
        ${renderTeamRateRow("Пропускала", s.conceded_matches_percent, teamRatioText(s.conceded_matches, count), "red")}
        ${renderTeamRateRow("Сухие матчи", s.clean_sheets_percent, teamRatioText(s.clean_sheets, count), "green")}
        ${renderTeamRateRow("Не забивала", s.failed_to_score_percent, teamRatioText(s.failed_to_score, count), "red")}
      </div>
    </section>

    <section class="team-max-section">
      <div class="team-max-heading"><div><span>ТОТАЛЫ</span><h3>Частота рынков</h3></div></div>
      <div class="team-rate-list compact">
        ${renderTeamRateRow("ТБ 0.5", s.over_0_5_percent, teamRatioText(s.over_0_5, count), "green")}
        ${renderTeamRateRow("ТБ 1.5", s.over_1_5_percent, teamRatioText(s.over_1_5, count), "green")}
        ${renderTeamRateRow("ТБ 2.5", s.over_2_5_percent, teamRatioText(s.over_2_5, count), "lime")}
        ${renderTeamRateRow("ТБ 3.5", s.over_3_5_percent, teamRatioText(s.over_3_5, count), "gold")}
        ${renderTeamRateRow("ТБ 4.5", s.over_4_5_percent, teamRatioText(s.over_4_5, count), "red")}
        ${renderTeamRateRow("ТМ 1.5", s.under_1_5_percent, teamRatioText(s.under_1_5, count), "gray")}
        ${renderTeamRateRow("ТМ 2.5", s.under_2_5_percent, teamRatioText(s.under_2_5, count), "gray")}
        ${renderTeamRateRow("ТМ 3.5", s.under_3_5_percent, teamRatioText(s.under_3_5, count), "gray")}
        ${renderTeamRateRow("ТМ 4.5", s.under_4_5_percent, teamRatioText(s.under_4_5, count), "gray")}
      </div>
    </section>


    <section class="team-max-section">
      <div class="team-max-heading"><div><span>ОБЕ ЗАБЬЮТ</span><h3>Обмен голами</h3></div></div>
      <div class="team-max-grid two">
        ${renderTeamMaxCard("Обе забьют — Да", teamPercent(s.btts_percent), teamRatioText(s.btts, count), "green")}
        ${renderTeamMaxCard("Обе забьют — Нет", teamPercent(s.no_btts_percent), teamRatioText(s.no_btts, count), "gray")}
      </div>
    </section>

    <section class="team-max-section">
      <div class="team-max-heading"><div><span>СЕРИИ</span><h3>Текущие и максимальные</h3></div></div>
      <div class="team-streak-grid">
        ${renderTeamStreakCard("Победы", current.wins, longest.wins, "green")}
        ${renderTeamStreakCard("Без поражений", current.unbeaten, longest.unbeaten, "green")}
        ${renderTeamStreakCard("Без побед", current.winless, 0, "red")}
        ${renderTeamStreakCard("Забивает", current.scoring, longest.scoring, "green")}
        ${renderTeamStreakCard("Пропускает", current.conceding, 0, "red")}
        ${renderTeamStreakCard("Сухие матчи", current.clean_sheets, longest.clean_sheets, "green")}
        ${renderTeamStreakCard("Не забивает", current.failed_to_score, 0, "red")}
        ${renderTeamStreakCard("Обе забьют", current.btts, longest.btts, "lime")}
        ${renderTeamStreakCard("ТБ 2.5", current.over_2_5, longest.over_2_5, "gold")}
        ${renderTeamStreakCard("ТМ 2.5", current.under_2_5, 0, "gray")}
      </div>
    </section>

  </div>`;
}


function renderTeamMatchesContent(data) {
  const recent = Array.isArray(data?.recent) ? data.recent.slice(0, 10) : [];
  return `<div class="team-recent-card-shell"><div class="team-recent-card-head"><div><span>ПОСЛЕДНИЕ МАТЧИ</span><h3>Форма команды</h3></div><b>${recent.length || 0}/10</b></div><div class="recent-list-body team-profile-recent-list">${recent.length ? recent.map(renderRecentListRow).join("") : `<div class="detail-tab-empty recent-empty"><b>Последние матчи пока недоступны</b><span>SportScore ещё не передал список соперников и результатов.</span></div>`}</div></div>`;
}

function renderTeamView() {
  const data = state.teamData || {};
  const team = data.team || {};
  const match = state.detail?.match || {};
  const title = String(team.name || (state.teamSide === "away" ? match.away : match.home) || "Команда");
  const subtitleText = [team.country,team.league].filter(Boolean).join(" · ") || "Командная статистика";
  const tab = state.teamTab === "matches" ? "matches" : "stats";
  let content = "";
  if (state.teamLoading) content = `<div class="loading"><div class="spinner"></div>Загружаем данные команды…</div>`;
  else if (state.teamError) content = `<div class="empty"><div class="empty-icon">!</div><div>Не удалось загрузить данные команды</div><div class="empty-sub">${esc(state.teamError)}</div><button class="retry-btn" onclick="retryTeamStats()">Повторить</button></div>`;
  else content = tab === "matches" ? renderTeamMatchesContent(data) : renderTeamStatsContent(data);
  app.innerHTML = `<div class="detail-screen team-screen team-max-profile"><div class="detail-topbar"><button class="back-btn" onclick="closeTeamStats()">‹</button><div class="detail-breadcrumb">Карточка команды</div><span class="team-top-spacer"></span></div><div class="team-hero premium-shell compact-team-hero"><div class="team-hero-main">${renderTeamHeroLogo(team)}<div class="team-hero-copy"><div class="team-hero-badge">TEAM ANALYTICS</div><h2>${esc(title)}</h2><div class="team-hero-meta"><span class="team-hero-flag">${leagueHeaderIcon({country_code:team.country_code,country:team.country,league:team.league})}</span><span>${esc(subtitleText)}</span></div></div></div>${renderTeamHeroChips(data?.summary || {}, "football")}</div><div class="detail-tabs team-tabs"><button type="button" class="tab-btn ${tab === "stats" ? "active" : ""}" onclick="setTeamTab('stats')">Статистика</button><button type="button" class="tab-btn ${tab === "matches" ? "active" : ""}" onclick="setTeamTab('matches')">Матчи</button></div><div class="team-content">${content}${renderSportScoreAttribution()}</div></div>`;
}

function renderCompetitionLogo(c) {
  const logo = String(c?.logo || "").trim();
  const name = String(c?.name || "Турнир");
  return `<div class="competition-logo ${logo ? "" : "logo-error"}">${logo ? `<img src="${esc(logo)}" alt="${esc(name)}" loading="lazy" onerror="this.parentElement.classList.add('logo-error')" />` : ""}<span class="logo-fallback">${esc(initials(name))}</span></div>`;
}

function competitionTeamButton(teamId, name, logo = "", extraClass = "") {
  const tid = String(teamId || "");
  const encodedId = encodeURIComponent(tid);
  const encodedName = encodeURIComponent(name || "");
  const encodedPath = encodeURIComponent(state.competitionPath || state.competitionData?.competition?.path || "");
  const content = `${logo ? `<span class="competition-team-mini-logo"><img src="${esc(logo)}" alt="" loading="lazy" onerror="this.parentElement.classList.add('logo-error')" /></span>` : ""}<span>${esc(name || "Команда")}</span>`;
  if (!tid) return `<span class="competition-team-button ${extraClass}">${content}</span>`;
  return `<button type="button" class="competition-team-button ${extraClass}" onclick="return openTeamFromInternal(decodeURIComponent('${encodedId}'),decodeURIComponent('${encodedName}'),decodeURIComponent('${encodedPath}'),event)">${content}</button>`;
}

function competitionMatchStatus(m) {
  if (m?.is_live) return `<span class="competition-match-status live">LIVE</span>`;
  if (m?.finished) return `<span class="competition-match-status finished">FT</span>`;
  if (m?.postponed) return `<span class="competition-match-status postponed">ОТЛ</span>`;
  return `<span class="competition-match-status upcoming">${esc(m?.time_text || "PRE")}</span>`;
}

function renderCompetitionMatch(m) {
  const homeButton = competitionTeamButton(m?.home_id, m?.home, m?.home_logo, "home");
  const awayButton = competitionTeamButton(m?.away_id, m?.away, m?.away_logo, "away");
  const score = m?.finished || m?.is_live ? `${safeInt(m?.score_home)}:${safeInt(m?.score_away)}` : "VS";
  const mid = encodeURIComponent(String(m?.id || ""));
  return `<div class="competition-match-card">
    <div class="competition-match-top"><span>${esc(m?.date_text || "")}${m?.round ? ` · ${esc(m.round)}` : ""}</span>${competitionMatchStatus(m)}</div>
    <div class="competition-match-body">${homeButton}<button type="button" class="competition-match-score" onclick="loadDetail(decodeURIComponent('${mid}'),{returnView:'competition'})">${esc(score)}<em>Открыть матч</em></button>${awayButton}</div>
  </div>`;
}

function groupCompetitionMatches(rows) {
  const groups = new Map();
  for (const m of rows || []) {
    const key = String(m?.round || m?.date_text || "Матчи");
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(m);
  }
  return [...groups.entries()];
}

function renderCompetitionMatchesList(rows, emptyText = "Матчи не найдены") {
  if (!Array.isArray(rows) || !rows.length) return `<div class="competition-empty">${esc(emptyText)}</div>`;
  return groupCompetitionMatches(rows).map(([label, matches]) => `<div class="competition-round-block"><div class="competition-round-title">${esc(label)}</div>${matches.map(renderCompetitionMatch).join("")}</div>`).join("");
}

function renderCompetitionMiniTable(rows) {
  const list = Array.isArray(rows) ? rows.slice(0, 6) : [];
  if (!list.length) return `<div class="competition-empty">Таблица пока недоступна</div>`;
  return `<div class="competition-table compact">${list.map(r => `<div class="competition-table-row"><b>${safeInt(r.position)}</b>${competitionTeamButton(r.team_id,r.team,r.logo)}<span>${safeInt(r.played)}</span><strong>${safeInt(r.points)}</strong></div>`).join("")}</div>`;
}

function competitionPPG(row) {
  const played = Math.max(1, safeInt(row?.played));
  const pts = safeInt(row?.points);
  return (pts / played).toFixed(2);
}

function competitionGoalDiffText(row) {
  const gd = String(row?.goal_difference ?? "").trim();
  if (gd) return gd;
  const gf = row?.goals_for;
  const ga = row?.goals_against;
  if (Number.isFinite(Number(gf)) && Number.isFinite(Number(ga))) return `${safeInt(gf)}:${safeInt(ga)}`;
  return "—";
}

function competitionRowTone(position, total) {
  const pos = safeInt(position);
  const count = Math.max(1, safeInt(total));
  if (pos > 0 && pos <= Math.min(3, count)) return "is-top";
  if (count >= 8 && pos >= count - 1) return "is-bottom";
  if (count >= 6 && pos >= count - 3) return "is-warning";
  return "";
}

function renderCompetitionTableCard(row, totalRows) {
  const tone = competitionRowTone(row?.position, totalRows);
  const form = Array.isArray(row?.form) ? row.form.slice(0, 5) : [];
  return `<div class="competition-standing-card ${tone}">
    <div class="competition-standing-main">
      <div class="competition-standing-pos">${safeInt(row?.position)}</div>
      <div class="competition-standing-team">${competitionTeamButton(row?.team_id,row?.team,row?.logo)}</div>
      <div class="competition-standing-points"><span>Очки</span><b>${safeInt(row?.points)}</b></div>
    </div>
    <div class="competition-standing-stats">
      <div><span>И</span><b>${safeInt(row?.played)}</b></div>
      <div><span>В</span><b>${safeInt(row?.wins)}</b></div>
      <div><span>Н</span><b>${safeInt(row?.draws)}</b></div>
      <div><span>П</span><b>${safeInt(row?.losses)}</b></div>
      <div><span>РМ</span><b>${esc(competitionGoalDiffText(row))}</b></div>
      <div><span>PPG</span><b>${esc(competitionPPG(row))}</b></div>
    </div>
    <div class="competition-standing-bottom">
      <div class="competition-standing-form-wrap"><span>Форма</span>${form.length ? `<div class="competition-standing-form">${renderTeamResultPills(form)}</div>` : `<em>Нет данных</em>`}</div>
      <div class="competition-standing-record">${safeInt(row?.wins)}-${safeInt(row?.draws)}-${safeInt(row?.losses)}</div>
    </div>
  </div>`;
}

function renderCompetitionTableSummary(rows) {
  const total = Array.isArray(rows) ? rows.length : 0;
  if (!total) return "";
  const leader = rows[0] || {};
  const totalPoints = rows.reduce((acc, r) => acc + safeInt(r?.points), 0);
  const avgPoints = total ? (totalPoints / total).toFixed(1) : "0.0";
  return `<div class="competition-standings-summary"><div><span>Команд</span><b>${safeInt(total)}</b></div><div><span>Лидер</span><b>${safeInt(leader?.points)}</b></div><div><span>Средние очки</span><b>${esc(avgPoints)}</b></div></div>`;
}

function renderCompetitionPlayerRows(rows, valueLabel) {
  if (!Array.isArray(rows) || !rows.length) return `<div class="competition-empty small">Нет данных</div>`;
  return `<div class="competition-player-list">${rows.slice(0,10).map((p,i) => `<div class="competition-player-row"><b>${safeInt(p.position,i+1)}</b><span class="competition-player-avatar ${p.image ? "" : "logo-error"}">${p.image ? `<img src="${esc(p.image)}" alt="" loading="lazy" onerror="this.parentElement.classList.add('logo-error')" />` : ""}<i>${esc(initials(p.name))}</i></span><div><strong>${esc(p.name || "")}</strong>${p.team_id ? competitionTeamButton(p.team_id,p.team,"","inline") : `<em>${esc(p.team || "")}</em>`}</div><span class="competition-player-value">${esc(p.value ?? "—")}<small>${esc(valueLabel)}</small></span></div>`).join("")}</div>`;
}

function renderCompetitionOverview(data) {
  const c = data?.competition || {};
  const stats = data?.stats || {};
  const standings = data?.standings || [];
  const next = (data?.upcoming || []).slice(0,5);
  const recent = (data?.results || []).slice(0,5);
  const scorers = data?.players?.scorers || [];
  return `<div class="competition-dashboard-grid">
    <div class="competition-panel competition-overview-kpis"><div class="competition-panel-kicker">SEASON SNAPSHOT</div><div class="competition-kpi-grid"><div><span>Команд</span><b>${safeInt(stats.teams || c.teams_count)}</b></div><div><span>Матчей</span><b>${safeInt(stats.matches || c.matches_count)}</b></div><div><span>Голов</span><b>${safeInt(stats.goals)}</b></div><div><span>Голов/матч</span><b>${teamAverage(stats.goals_per_match)}</b></div></div></div>
    ${c.defending_champion ? `<div class="competition-panel champion-card"><div class="competition-panel-kicker">ДЕЙСТВУЮЩИЙ ЧЕМПИОН</div>${competitionTeamButton(c.defending_champion_id,c.defending_champion,"","champion")}<span>Последний победитель турнира</span></div>` : ""}
    <div class="competition-panel"><div class="competition-panel-head"><div><div class="competition-panel-kicker">NEXT FIXTURES</div><h3>Ближайшие матчи</h3></div><button onclick="setCompetitionTab('matches')">Все ›</button></div>${renderCompetitionMatchesList(next,"Ближайших матчей пока нет")}</div>
    <div class="competition-panel"><div class="competition-panel-head"><div><div class="competition-panel-kicker">LATEST RESULTS</div><h3>Последние результаты</h3></div><button onclick="setCompetitionTab('matches');setCompetitionMatchFilter('results')">Все ›</button></div>${renderCompetitionMatchesList(recent,"Результатов пока нет")}</div>
    <div class="competition-panel"><div class="competition-panel-head"><div><div class="competition-panel-kicker">STANDINGS</div><h3>Таблица</h3></div><button onclick="setCompetitionTab('table')">Полная ›</button></div>${renderCompetitionMiniTable(standings)}</div>
    <div class="competition-panel"><div class="competition-panel-head"><div><div class="competition-panel-kicker">TOP PLAYERS</div><h3>Лучшие бомбардиры</h3></div><button onclick="setCompetitionTab('players')">Все ›</button></div>${renderCompetitionPlayerRows(scorers.slice(0,5),"голов")}</div>
  </div>`;
}

function filteredCompetitionMatches(data) {
  let rows = Array.isArray(data?.matches) ? [...data.matches] : [];
  if (state.competitionMatchFilter === "upcoming") rows = Array.isArray(data?.upcoming) ? [...data.upcoming] : [];
  else if (state.competitionMatchFilter === "results") rows = Array.isArray(data?.results) ? [...data.results] : [];
  else if (state.competitionMatchFilter === "live") rows = Array.isArray(data?.live) ? [...data.live] : [];
  if (state.competitionRound !== "all" && !data?.round_filter) {
    const option = (data?.round_options || []).find(x => String(x?.value || "") === state.competitionRound);
    const label = String(option?.label || state.competitionRound);
    rows = rows.filter(x => String(x?.round || "") === label);
  }
  return rows;
}

function renderCompetitionMatchesTab(data) {
  const roundOptions = Array.isArray(data?.round_options) && data.round_options.length ? data.round_options : (data?.rounds || []).map(r => ({label:r,value:r}));
  const rows = filteredCompetitionMatches(data);
  return `<div class="competition-toolbar"><div class="competition-filter-pills">${[["all","Все"],["upcoming","Предстоящие"],["results","Результаты"],["live","Live"]].map(([k,l]) => `<button class="${state.competitionMatchFilter===k?"active":""}" onclick="setCompetitionMatchFilter('${k}')">${l}</button>`).join("")}</div>${roundOptions.length ? `<select onchange="setCompetitionRound(this.value)"><option value="all">Все туры</option>${roundOptions.map(r=>`<option value="${esc(r.value||r.label||"")}" ${state.competitionRound===String(r.value||r.label||"")?"selected":""}>${esc(r.label||r.value||"")}</option>`).join("")}</select>` : ""}</div><div class="competition-panel">${renderCompetitionMatchesList(rows)}</div>`;
}

function renderCompetitionTableTab(data) {
  const groups = Array.isArray(data?.standings_groups) && data.standings_groups.length ? data.standings_groups : [{name:"Таблица",rows:data?.standings||[]}];
  return groups.map(group => {
    const rows = Array.isArray(group?.rows) ? group.rows : [];
    return `<div class="competition-panel competition-standings-panel"><div class="competition-panel-kicker">STANDINGS</div><h3>${esc(group.name || "Таблица")}</h3>${renderCompetitionTableSummary(rows)}<div class="competition-standings-cards">${rows.length ? rows.map(r => renderCompetitionTableCard(r, rows.length)).join("") : `<div class="competition-empty">Таблица пока недоступна</div>`}</div></div>`;
  }).join("");
}

function renderCompetitionPlayersTab(data) {
  const p = data?.players || {};
  return `<div class="competition-player-columns"><div class="competition-panel"><div class="competition-panel-kicker">TOP SCORERS</div><h3>Лучшие бомбардиры</h3>${renderCompetitionPlayerRows(p.scorers,"голов")}</div><div class="competition-panel"><div class="competition-panel-kicker">TOP ASSISTS</div><h3>Лучшие ассистенты</h3>${renderCompetitionPlayerRows(p.assists,"ассистов")}</div><div class="competition-panel"><div class="competition-panel-kicker">TOP RATED</div><h3>Лучшие по рейтингу</h3>${renderCompetitionPlayerRows(p.ratings,"рейтинг")}</div></div>`;
}

function renderCompetitionStatsTab(data) {
  const s = data?.stats || {};
  const rows = data?.standings || [];
  const leader = rows[0] || {};
  const bestAttack = [...rows].sort((a,b)=>safeInt(b.goal_difference)-safeInt(a.goal_difference))[0] || {};
  const performance = [...rows].sort((a,b)=>((safeInt(b.points)/Math.max(1,safeInt(b.played)))-(safeInt(a.points)/Math.max(1,safeInt(a.played)))));
  return `<div class="competition-stat-grid">${renderTeamStatCard("Команд",safeInt(s.teams),"Участники","accent-blue")}${renderTeamStatCard("Матчей",safeInt(s.matches),"Календарь","accent-purple")}${renderTeamStatCard("Завершено",safeInt(s.finished),"Результаты","accent-green")}${renderTeamStatCard("Предстоит",safeInt(s.upcoming),"Будущие","accent-gold")}${renderTeamStatCard("Голов",safeInt(s.goals),"Всего","accent-red")}${renderTeamStatCard("Голов за матч",teamAverage(s.goals_per_match),"Среднее","accent-blue")}</div><div class="competition-panel"><div class="competition-panel-kicker">TEAM PERFORMANCE</div><h3>Лидеры команд</h3><div class="competition-leader-grid"><div><span>Лидер таблицы</span>${competitionTeamButton(leader.team_id,leader.team,leader.logo)}<b>${safeInt(leader.points)} очков</b></div><div><span>Лучшая разница мячей</span>${competitionTeamButton(bestAttack.team_id,bestAttack.team,bestAttack.logo)}<b>${esc(bestAttack.goal_difference||"—")}</b></div></div></div><div class="competition-panel"><div class="competition-panel-kicker">ALL TEAMS</div><h3>Статистика команд</h3><div class="competition-team-stats-list">${performance.map((r,i)=>`<div><b>${i+1}</b>${competitionTeamButton(r.team_id,r.team,r.logo)}<span><strong>${safeInt(r.points)}</strong> оч.</span><span>${teamAverage(safeInt(r.points)/Math.max(1,safeInt(r.played)))} PPG</span><div class="competition-team-stats-form">${renderTeamResultPills((r.form||[]).slice(0,5))}</div></div>`).join("")}</div></div>`;
}

function renderCompetitionTeamsTab(data) {
  const teams = Array.isArray(data?.teams) ? data.teams : [];
  if (!teams.length) return `<div class="competition-panel"><div class="competition-empty">Список команд пока недоступен</div></div>`;
  return `<div class="competition-teams-grid">${teams.map(t=>`<button type="button" class="competition-team-card" onclick="return openTeamFromInternal(decodeURIComponent('${encodeURIComponent(t.id||"")}'),decodeURIComponent('${encodeURIComponent(t.name||"")}'),decodeURIComponent('${encodeURIComponent(state.competitionPath||"")}'),event)"><span class="competition-team-card-logo ${t.logo?"":"logo-error"}">${t.logo?`<img src="${esc(t.logo)}" alt="" loading="lazy" onerror="this.parentElement.classList.add('logo-error')" />`:""}<i>${esc(initials(t.name))}</i></span><strong>${esc(t.name||"")}</strong><span>${t.position?`${safeInt(t.position)} место`:"Открыть профиль"}</span>${Array.isArray(t.form)&&t.form.length?`<div class="competition-team-form">${renderTeamResultPills(t.form.slice(0,5))}</div>`:""}</button>`).join("")}</div>`;
}

function renderCompetitionBracketTab(data) {
  const bracket = Array.isArray(data?.bracket) ? data.bracket : [];
  const champions = Array.isArray(data?.champions) ? data.champions : [];
  return `<div class="competition-panel"><div class="competition-panel-kicker">PLAYOFFS</div><h3>Сетка плей-офф</h3>${bracket.length ? renderCompetitionMatchesList(bracket) : `<div class="competition-empty">У этого турнира нет доступной сетки или используется круговая система.</div>`}</div><div class="competition-panel"><div class="competition-panel-kicker">HISTORY</div><h3>Чемпионы по сезонам</h3>${champions.length ? `<div class="competition-champions">${champions.map(x=>`<div><span>${esc(x.season||"—")}</span>${competitionTeamButton(x.team_id,x.team)}</div>`).join("")}</div>` : `<div class="competition-empty">История чемпионов пока недоступна.</div>`}</div>`;
}

function renderCompetitionContent(data) {
  const tab = state.competitionTab;
  if (tab === "matches") return renderCompetitionMatchesTab(data);
  if (tab === "table") return renderCompetitionTableTab(data);
  if (tab === "players") return renderCompetitionPlayersTab(data);
  if (tab === "stats") return renderCompetitionStatsTab(data);
  if (tab === "teams") return renderCompetitionTeamsTab(data);
  if (tab === "bracket") return renderCompetitionBracketTab(data);
  return renderCompetitionOverview(data);
}

function renderCompetitionView() {
  const data = state.competitionData || {};
  const c = data.competition || {};
  let content = "";
  if (state.competitionLoading) content = `<div class="loading"><div class="spinner"></div>Загружаем центр турнира…</div>`;
  else if (state.competitionError) content = `<div class="empty"><div class="empty-icon">!</div><div>Не удалось загрузить турнир</div><div class="empty-sub">${esc(state.competitionError)}</div><button class="retry-btn" onclick="retryCompetition()">Повторить</button></div>`;
  else content = renderCompetitionContent(data);
  const seasons = Array.isArray(data.seasons) ? data.seasons : [];
  const tabItems = [["overview","Обзор"],["matches","Матчи"],["table","Таблица"],["players","Игроки"],["stats","Статистика"],["teams","Команды"],["bracket","Плей-офф"]];
  app.innerHTML = `<div class="detail-screen competition-screen"><div class="detail-topbar"><button class="back-btn" onclick="closeCompetition()">‹</button><div class="detail-breadcrumb">Центр турнира</div><button class="competition-refresh" onclick="retryCompetition()">↻</button></div><div class="competition-hero"><div class="competition-hero-main">${renderCompetitionLogo(c)}<div><div class="competition-eyebrow">TOURNAMENT CENTRE</div><h2>${esc(c.name || "Турнир")}</h2><div class="competition-meta">${leagueHeaderIcon({country_code:c.country_code,country:c.country,league:c.name})}<span>${esc(c.country || "Международный турнир")}</span></div></div></div>${seasons.length ? `<select class="competition-season-select" onchange="changeCompetitionSeason(this.value)">${seasons.map(s=>{const optionValue=s.path&&s.path!==state.competitionPath?s.path:(s.value||"");return `<option value="${esc(optionValue)}" ${(s.selected==="1"||String(s.value||"")===state.competitionSeason)?"selected":""}>${esc(s.label||s.value||"Сезон")}</option>`;}).join("")}</select>` : ""}<div class="competition-hero-stats"><div><b>${safeInt(c.teams_count || data?.stats?.teams)}</b><span>команд</span></div><div><b>${safeInt(c.rounds_count || data?.rounds?.length)}</b><span>туров</span></div><div><b>${safeInt(data?.stats?.matches || c.matches_count)}</b><span>матчей</span></div></div></div><div class="competition-tabs">${tabItems.map(([k,l])=>`<button class="${state.competitionTab===k?"active":""}" onclick="setCompetitionTab('${k}')">${l}</button>`).join("")}</div><div class="competition-content">${content}${renderSportScoreAttribution()}</div></div>`;
}


function normalizeLiveMatch(m) {
  const minute = normalizeMatchMinuteValue(m?.minute);
  return {
    ...m,
    minute,
    minute_text: normalizeMatchMinuteText(m?.minute_text, minute),
  };
}

function flattenLive(live) {
  const out = [];
  for (const c of live?.countries || [])
    for (const l of c.leagues || [])
      for (const m of l.matches || []) out.push(normalizeLiveMatch(m));
  return out;
}

function findCurrentMatchById(id) {
  const k = String(id || "");
  const fromLive = flattenLive(state.live).find(m => String(m.id) === k);
  if (fromLive) return fromLive;
  const detailMatch = state.detail?.match;
  return detailMatch && String(detailMatch.id) === k ? detailMatch : null;
}

function currentLiveById() {
  const map = new Map();
  for (const m of flattenLive(state.live)) {
    const id = String(m?.id || "");
    if (id) map.set(id, m);
  }
  return map;
}

function alertMetaFromCard(candidate) {
  const c = candidate || {};
  const out = {};
  for (const key of [
    "alert_kind", "alert_title", "alert_subtitle",
    "alert_score", "alert_reasons", "alert_reason",
    "filter_score", "filter_label", "filter_reason", "filter_reasons", "filter_profile", "found_at",
  ]) {
    if (c[key] !== undefined && c[key] !== null && c[key] !== "") out[key] = c[key];
  }
  return out;
}

function resolveMatchCardData(candidate, liveById = null) {
  // One canonical source for every list card. Favorites and notifications must
  // render the same match snapshot when they contain the same match id.
  const id = String(candidate?.id || candidate?.match_id || "");
  if (!id) return candidate || {};
  const liveMap = liveById || currentLiveById();
  const liveMatch = liveMap.get(id);
  const meta = alertMetaFromCard(candidate);
  if (liveMatch) return { ...liveMatch, ...meta, is_live: true };
  const cached = getFavCachedMatch(id);
  if (cached) return { ...cached, ...meta, is_live: false, finished: Boolean(cached.finished || candidate?.finished) };
  const notified = getNotifyCachedMatch(id);
  if (notified) return { ...notified, ...(candidate || {}), id, is_live: false, finished: Boolean(notified.finished || candidate?.finished) };
  return { ...(candidate || {}), id };
}

function resolveMatchCardList(items) {
  const liveById = currentLiveById();
  return (items || []).map(item => resolveMatchCardData(item, liveById));
}

function isLiveMatchId(id, liveById = null) {
  const k = String(id || "");
  if (!k) return false;
  const liveMap = liveById || currentLiveById();
  return liveMap.has(k);
}

function resolveNotifyVisibleCards(items) {
  // Notification cards are user-owned history: keep every notified match visible
  // until the user removes it or presses "Очистить", even after it leaves /api/live
  // or the server live cache is pruned after 24h.
  const liveById = currentLiveById();
  const out = [];
  for (const item of items || []) {
    const card = resolveMatchCardData(item, liveById);
    const id = String(card?.id || item?.id || item?.match_id || "");
    if (!id) continue;
    const live = liveById.has(id);
    const merged = live ? { ...card, is_live: true, finished: false } : { ...card, is_live: false, finished: true, period: card.period || "FT" };
    saveNotifyCache(id, merged);
    out.push(merged);
  }
  return out;
}

function goalTotal(m) {
  return safeInt(m?.score_home, 0) + safeInt(m?.score_away, 0);
}

function goalScoreText(m) {
  return `${safeInt(m?.score_home, 0)}-${safeInt(m?.score_away, 0)}`;
}

function rememberGoalNotifyScore(m) {
  if (!m?.id) return;
  const scores = getGoalNotifyScores();
  scores[String(m.id)] = { score: goalScoreText(m), total: goalTotal(m), ts: Date.now() };
  saveGoalNotifyScores(scores);
}

function forgetGoalNotifyScore(id) {
  const scores = getGoalNotifyScores();
  delete scores[String(id)];
  saveGoalNotifyScores(scores);
}

function rememberAutoGoalNotifyForMatches(matches) {
  const ids = getAutoGoalNotifies();
  const scores = getGoalNotifyScores();
  let changed = false;
  for (const m of matches || []) {
    const id = String(m?.id || m?.match_id || "");
    if (!id || ids.has(id)) continue;
    ids.add(id);
    scores[id] = { score: goalScoreText(m), total: goalTotal(m), ts: Date.now(), auto: true };
    changed = true;
  }
  if (changed) {
    saveAutoGoalNotifies(ids);
    saveGoalNotifyScores(scores);
  }
}

function forgetAutoGoalNotifyForMatches(matchIds) {
  const ids = getAutoGoalNotifies();
  const scores = getGoalNotifyScores();
  let changed = false;
  for (const raw of matchIds || []) {
    const id = String(raw || "").trim();
    if (!id) continue;
    if (ids.delete(id)) changed = true;
    if (scores[id]?.auto) {
      delete scores[id];
      changed = true;
    }
  }
  if (changed) {
    saveAutoGoalNotifies(ids);
    saveGoalNotifyScores(scores);
  }
}

function askConfirm(message) {
  return new Promise(resolve => {
    if (tg?.showConfirm) {
      try { tg.showConfirm(message, ok => resolve(!!ok)); return; } catch (_) {}
    }
    resolve(window.confirm(message));
  });
}

function syncGoalNotify(id, enabled) {
  fetch("/api/goal-subscribe", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ init_data: tg?.initData || "", match_id: String(id), enabled: !!enabled }),
  }).catch(() => {});
}

async function toggleFavWithGoalPrompt(id) {
  const k = String(id || "");
  if (!k) return;
  const wasFav = isFav(k);
  const nowFav = toggleFav(k);
  const goalSet = getGoalNotifies();

  if (nowFav && !wasFav && !goalSet.has(k)) {
    const addGoalNotify = await askConfirm("Добавить уведомления на гол для этого матча?");
    if (addGoalNotify) {
      goalSet.add(k);
      saveGoalNotifies(goalSet);
      const m = findCurrentMatchById(k);
      if (m) rememberGoalNotifyScore(m);
      syncGoalNotify(k, true);
      try { tg?.HapticFeedback?.notificationOccurred?.("success"); } catch (_) {}
    }
  } else if (!nowFav) {
    if (goalSet.delete(k)) {
      saveGoalNotifies(goalSet);
      forgetGoalNotifyScore(k);
      syncGoalNotify(k, false);
    }
  }
  render();
}

// v9.30: сортировка лент от топовых лиг к менее топовым.
// Раньше коэффициенты/сигнал могли поднимать слабые лиги выше АПЛ/Ла Лиги.
// Теперь главный ключ — сила турнира, а сигнал/кф работают только внутри одного уровня.
function sortText(v) {
  return String(v || "")
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/ё/g, "е")
    .replace(/[^a-zа-я0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

function hasPhrase(text, phrase) {
  const t = ` ${sortText(text)} `;
  const p = ` ${sortText(phrase)} `;
  return p.trim() ? t.includes(p) : false;
}

function anyPhrase(text, phrases) {
  return (phrases || []).some(p => hasPhrase(text, p));
}

const LEAGUE_POWER_RULES = [
  // Еврокубки / международные топ-турниры
  { rank: 1, league: ["uefa champions league", "champions league", "лига чемпионов"] },
  { rank: 2, league: ["uefa europa league", "europa league", "лига европы"] },
  { rank: 3, league: ["conference league", "лига конференций"] },
  { rank: 4, league: ["copa libertadores", "libertadores", "кубок либертадорес"] },
  { rank: 5, league: ["copa sudamericana", "sudamericana"] },
  { rank: 6, league: ["world cup", "euro", "copa america", "afcon", "asian cup", "чемпионат мира", "чемпионат европы"] },

  // Топ-5 Европа
  { rank: 10, country: ["england", "англия"], league: ["premier league", "премьер лига", "премьер лига", "apl", "epl", "апл"] },
  { rank: 11, country: ["spain", "испания"], league: ["la liga", "laliga", "primera division", "примера", "ла лига"] },
  { rank: 12, country: ["italy", "италия"], league: ["serie a", "серия a", "серия а"] },
  { rank: 13, country: ["germany", "германия"], league: ["bundesliga", "бундеслига"] },
  { rank: 14, country: ["france", "франция"], league: ["ligue 1", "лига 1"] },

  // Сильные европейские чемпионаты
  { rank: 20, country: ["netherlands", "нидерланды", "holland"], league: ["eredivisie", "эредивизи"] },
  { rank: 21, country: ["portugal", "португалия"], league: ["primeira liga", "liga portugal", "примейра"] },
  { rank: 22, country: ["turkey", "турция"], league: ["super lig", "super league", "суперлига"] },
  { rank: 23, country: ["belgium", "бельгия"], league: ["pro league", "first division a", "jupiler"] },
  { rank: 24, country: ["scotland", "шотландия"], league: ["premiership", "premier league"] },
  { rank: 25, country: ["austria", "австрия"], league: ["bundesliga"] },
  { rank: 26, country: ["switzerland", "швейцария"], league: ["super league"] },
  { rank: 27, country: ["denmark", "дания"], league: ["superliga", "super league"] },
  { rank: 28, country: ["norway", "норвегия"], league: ["eliteserien"] },
  { rank: 29, country: ["sweden", "швеция"], league: ["allsvenskan"] },
  { rank: 30, country: ["greece", "греция"], league: ["super league"] },
  { rank: 31, country: ["poland", "польша"], league: ["ekstraklasa"] },
  { rank: 32, country: ["czech", "czech republic", "czechia", "чехия"], league: ["first league", "1 liga"] },

  // Америка / Азия / сильные внешние чемпионаты
  { rank: 40, country: ["brazil", "бразилия"], league: ["serie a", "brasileirao", "brasileiro serie a"] },
  { rank: 41, country: ["argentina", "аргентина"], league: ["liga profesional", "primera division", "primera división", "аргентина примера"] },
  { rank: 42, country: ["usa", "united states", "сша"], league: ["major league soccer", "mls"] },
  { rank: 43, country: ["mexico", "мексика"], league: ["liga mx"] },
  { rank: 44, country: ["colombia", "колумбия"], league: ["categoria primera a", "categoría primera a", "primera a"] },
  { rank: 45, country: ["chile", "чили"], league: ["primera division", "primera división"] },
  { rank: 46, country: ["uruguay", "уругвай"], league: ["primera division", "primera división"] },
  { rank: 47, country: ["paraguay", "парагвай"], league: ["primera division", "primera división"] },
  { rank: 48, country: ["ecuador", "эквадор"], league: ["liga pro", "serie a"] },
  { rank: 49, country: ["peru", "перу"], league: ["liga 1", "primera division"] },
  { rank: 50, country: ["japan", "япония"], league: ["j1", "j1 league", "j league"] },
  { rank: 51, country: ["south korea", "korea", "южная корея"], league: ["k league 1", "kleague 1"] },
  { rank: 52, country: ["china", "китай"], league: ["super league"] },
  { rank: 53, country: ["australia", "австралия"], league: ["a league", "a-league"] },
  { rank: 54, country: ["saudi arabia", "саудовская аравия"], league: ["pro league", "professional league"] },
  { rank: 55, country: ["uae", "united arab emirates", "оаэ"], league: ["pro league"] },
  { rank: 56, country: ["qatar", "катар"], league: ["stars league"] },
  { rank: 57, country: ["egypt", "египет"], league: ["premier league"] },
  { rank: 58, country: ["south africa", "юар"], league: ["premier", "psl"] },
  { rank: 88, country: ["china", "китай"], league: ["national youth school football league", "youth school football league"] },

  // Вторые дивизионы топ-стран — ниже главных лиг, но выше случайных низших лиг
  { rank: 100, country: ["england", "англия"], league: ["championship"] },
  { rank: 101, country: ["spain", "испания"], league: ["segunda", "la liga 2", "laliga 2"] },
  { rank: 102, country: ["italy", "италия"], league: ["serie b", "серия b", "серия б"] },
  { rank: 103, country: ["germany", "германия"], league: ["2 bundesliga", "bundesliga 2"] },
  { rank: 104, country: ["france", "франция"], league: ["ligue 2", "лига 2"] },
  { rank: 105, country: ["netherlands", "нидерланды"], league: ["eerste divisie"] },
  { rank: 106, country: ["portugal", "португалия"], league: ["liga portugal 2", "segunda liga"] },
  { rank: 107, country: ["brazil", "бразилия"], league: ["serie b", "brasileiro serie b"] },
  { rank: 108, country: ["argentina", "аргентина"], league: ["primera nacional", "arg primera nacional"] },
  { rank: 109, country: ["usa", "united states", "сша"], league: ["usl championship"] },
  { rank: 110, country: ["japan", "япония"], league: ["j2", "j2 league"] },
];

const COUNTRY_POWER_ORDER = [
  "england", "англия", "spain", "испания", "italy", "италия", "germany", "германия", "france", "франция",
  "netherlands", "нидерланды", "portugal", "португалия", "turkey", "турция", "brazil", "бразилия",
  "argentina", "аргентина", "usa", "united states", "сша", "belgium", "бельгия", "scotland", "шотландия",
  "austria", "австрия", "switzerland", "швейцария", "denmark", "дания", "norway", "норвегия", "sweden", "швеция",
  "mexico", "мексика", "colombia", "колумбия", "japan", "япония", "south korea", "korea", "южная корея",
  "china", "китай", "australia", "австралия", "saudi arabia", "саудовская аравия", "qatar", "катар"
];

function countryPowerRank(country) {
  const c = sortText(country);
  for (let i = 0; i < COUNTRY_POWER_ORDER.length; i++) {
    if (hasPhrase(c, COUNTRY_POWER_ORDER[i])) return 300 + Math.floor(i / 2);
  }
  return 900;
}

function leaguePowerRank(country, league) {
  const c = sortText(country);
  const l = sortText(league);
  const low = `${c} ${l}`;

  // Женские/молодежные/резервные/любительские/товарищеские турниры держим ниже
  // взрослых основных лиг. Проверка стоит ДО правил топ-лиг, чтобы Premier League 2,
  // U21 или Women Champions League не поднимались выше настоящих топ-турниров.
  if (anyPhrase(low, [
    "women", "woman", "female", "u17", "u18", "u19", "u20", "u21", "u23",
    "reserve", "reserves", "youth", "academy", "development", "professional development",
    "amateur", "regional", "state league", "premier league 2",
    "division 2", "division 3", "third", "fourth", "friendly", "friendlies", "club friendly",
    "жен", "женщ", "молод", "юнош", "резерв", "товарищ"
  ])) {
    return 1200 + countryPowerRank(country);
  }

  for (const rule of LEAGUE_POWER_RULES) {
    if (rule.country && !anyPhrase(c, rule.country)) continue;
    if (anyPhrase(l, rule.league)) return rule.rank;
  }

  return countryPowerRank(country);
}


function isInternationalClubFriendly(groupOrMatch) {
  const league = String(groupOrMatch?.league || "").toLowerCase();
  const country = String(groupOrMatch?.country || "").toLowerCase();
  return /international\s+club\s+friendly|club\s+friendl|товарищеск.*клуб/.test(`${country} ${league}`);
}

function matchHasDetailedStats(match) {
  const m = match || {};
  if (m.stats_available === false || m.has_statistics === false) return false;
  if (m.has_stats === true || m.stats_available === true || m.has_statistics === true) return true;
  const stats = (m.stats && typeof m.stats === "object") ? m.stats : {};
  if (!Object.keys(stats).length) return false;
  const meaningful = [
    "shots", "shots_home", "shots_away", "shots_total",
    "on_target", "on_target_home", "on_target_away", "on_target_total",
    "off_target", "off_target_home", "off_target_away", "off_target_total",
    "attacks", "attacks_home", "attacks_away", "attacks_total",
    "dangerous", "dangerous_home", "dangerous_away", "dangerous_total",
    "corners", "corners_home", "corners_away", "corners_total",
    "yellow_cards", "yellow_cards_home", "yellow_cards_away", "yellow_cards_total",
    "red_cards", "red_cards_home", "red_cards_away", "red_cards_total",
    "possession", "possession_home", "possession_away"
  ];
  return meaningful.some(key => {
    if (!Object.prototype.hasOwnProperty.call(stats, key)) return false;
    const value = stats[key];
    if (value && typeof value === "object") {
      return safeInt(value.home, 0) > 0 || safeInt(value.away, 0) > 0;
    }
    return Number(value) > 0;
  });
}

function internationalFriendlyLeagueIcon(g) {
  const logo = String(g?.league_logo || "").trim();
  if (logo) {
    return `<span class="special-league-logo"><img src="${esc(logo)}" alt="" loading="lazy" onerror="this.parentElement.classList.add('logo-error')"/><i>⚽</i></span>`;
  }
  return `<span class="special-league-logo logo-error"><i>⚽</i></span>`;
}

function compareLeagueGroups(a, b) {
  // International Club Friendly is intentionally pinned near the top even
  // when SportScore does not provide advanced statistics for its matches.
  const aFriendly = isInternationalClubFriendly(a) ? 1 : 0;
  const bFriendly = isInternationalClubFriendly(b) ? 1 : 0;
  if (aFriendly !== bFriendly) return bFriendly - aFriendly;

  // All leagues without shots/attacks/corners/cards go below leagues with
  // detailed live data. This keeps the useful analytical matches first.
  const aStats = a?.has_stats ? 1 : 0;
  const bStats = b?.has_stats ? 1 : 0;
  if (aStats !== bStats) return bStats - aStats;

  const aCode = String(a?.country_code || "").trim() || inferCountryCodeFromText(a?.country, a?.league);
  const bCode = String(b?.country_code || "").trim() || inferCountryCodeFromText(b?.country, b?.league);
  const aHasFlag = aCode && aCode.length === 2 ? 1 : 0;
  const bHasFlag = bCode && bCode.length === 2 ? 1 : 0;
  if (aHasFlag !== bHasFlag) return bHasFlag - aHasFlag;

  const ar = leaguePowerRank(a.country, a.league);
  const br = leaguePowerRank(b.country, b.league);
  if (ar !== br) return ar - br;

  if (a.signal_max !== b.signal_max) return b.signal_max - a.signal_max;
  const ao = a.has_odds ? 1 : 0;
  const bo = b.has_odds ? 1 : 0;
  if (ao !== bo) return bo - ao;
  if (a.odds_count !== b.odds_count) return b.odds_count - a.odds_count;
  if (a.matches.length !== b.matches.length) return b.matches.length - a.matches.length;
  const cn = a.country.localeCompare(b.country, "ru");
  if (cn !== 0) return cn;
  return a.league.localeCompare(b.league, "ru");
}

function matchHasOdds(m) {
  return !!(m && (m.has_odds || m.hasOdds || m.odds));
}

function groupByLeague(matches) {
  // Returns array of { country, country_code, league, league_logo, has_odds, odds_count, matches[] }
  const map = new Map();
  for (const m of matches) {
    const c = m.country || "Без страны";
    const l = m.league || "Без лиги";
    const key = c + "|||" + l;
    if (!map.has(key)) {
      map.set(key, { country: c, country_code: m.country_code || inferCountryCodeFromText(c, l) || "", league: l, league_logo: m.league_logo || "", has_odds: false, odds_count: 0, has_stats: false, stats_count: 0, signal_count: 0, signal_max: 0, matches: [] });
    }
    const g = map.get(key);
    g.matches.push(m);
    if (matchHasOdds(m)) {
      g.has_odds = true;
      g.odds_count += 1;
    }
    if (matchHasDetailedStats(m)) {
      g.has_stats = true;
      g.stats_count += 1;
    }
    if (!g.league_logo && m.league_logo) g.league_logo = m.league_logo;
    const sigScore = matchSignalScore(m);
    if (sigScore) {
      g.signal_count += 1;
      g.signal_max = Math.max(g.signal_max, safeInt(sigScore, 0));
    }
  }

  for (const g of map.values()) {
    // Inside a league: matches with odds first, then regular live order.
    g.matches.sort((a, b) => {
      const as = matchSignalScore(a);
      const bs = matchSignalScore(b);
      if (as !== bs) return bs - as;
      const ao = matchHasOdds(a) ? 1 : 0;
      const bo = matchHasOdds(b) ? 1 : 0;
      if (ao !== bo) return bo - ao;
      return safeInt(b.minute, 0) - safeInt(a.minute, 0);
    });
  }

  return [...map.values()].sort(compareLeagueGroups);
}

function statTotal(s, key) {
  const flatTotal = s?.[`${key}_total`];
  if (flatTotal !== undefined && flatTotal !== null && flatTotal !== "") return safeInt(flatTotal, 0);
  const flatHome = s?.[`${key}_home`];
  const flatAway = s?.[`${key}_away`];
  if (flatHome !== undefined || flatAway !== undefined) return safeInt(flatHome, 0) + safeInt(flatAway, 0);
  const nested = s?.[key];
  if (nested && typeof nested === "object") return safeInt(nested.home, 0) + safeInt(nested.away, 0);
  return 0;
}

function statMaxSide(s, key, def = 0) {
  const nested = s?.[key];
  if (nested && typeof nested === "object") return Math.max(safeInt(nested.home, def), safeInt(nested.away, def));
  return Math.max(safeInt(s?.[`${key}_home`], def), safeInt(s?.[`${key}_away`], def));
}

function statSide(s, key, side) {
  const nested = s?.[key];
  if (nested && typeof nested === "object") return safeInt(nested[side], 0);
  return safeInt(s?.[`${key}_${side}`], 0);
}

function scorePartsFromMatch(m) {
  const h = safeInt(m?.score_home, 0);
  const a = safeInt(m?.score_away, 0);
  return { home: h, away: a, total: h + a, diff: Math.abs(h - a), text: `${h}-${a}` };
}

function pressureWeightedScore(attacks, dangerous, shots, onTarget, corners, goals = 0) {
  // Формула Attack Momentum под live-статистику: опасные моменты важнее обычных атак.
  return (attacks * 0.4) + (dangerous * 2.5) + (shots * 4.0) + (onTarget * 7.0) + (corners * 3.0) + (goals * 10.0);
}

function pressurePowerFromStats(stats, side) {
  const attacks = statSide(stats, "attacks", side);
  const dangerous = statSide(stats, "dangerous", side);
  const shots = statSide(stats, "shots", side);
  const onTarget = statSide(stats, "on_target", side);
  const corners = statSide(stats, "corners", side);
  return pressureWeightedScore(attacks, dangerous, shots, onTarget, corners);
}

function xgLiteWeightedScore(dangerous, shots, onTarget, corners) {
  // Строгий xG-lite без голов: оцениваем качество давления по доступной live-статистике.
  return (dangerous * 0.005) + (shots * 0.06) + (onTarget * 0.14) + (corners * 0.025);
}

function xgLiteSideFromStats(stats, side) {
  const dangerous = statSide(stats, "dangerous", side);
  const shots = statSide(stats, "shots", side);
  const onTarget = statSide(stats, "on_target", side);
  const corners = statSide(stats, "corners", side);
  return Number(xgLiteWeightedScore(dangerous, shots, onTarget, corners).toFixed(2));
}

function xgLitePairFromStats(stats) {
  return {
    home: xgLiteSideFromStats(stats || {}, "home"),
    away: xgLiteSideFromStats(stats || {}, "away"),
  };
}


function oddsMarketLabel(market) {
  return ({"1":"П1","x":"Х","2":"П2","over":"ТБ","under":"ТМ"})[String(market || "").toLowerCase()] || "КФ";
}
function oddsMarketValue(odds, market) {
  const src = (odds && typeof odds === "object") ? odds : {};
  const key = String(market || "").toLowerCase();
  let value = null;
  if (["1","x","2"].includes(key)) value = (src.eu || {})[key === "x" ? "X" : key];
  else if (["over","under"].includes(key)) value = (src.bs || {})[key];
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : 0;
}
function oddsFilterSnapshot(m, f) {
  const market = String(f?.odds_market || "").toLowerCase();
  if (!["1","x","2","over","under"].includes(market)) return null;
  const before = oddsMarketValue(m?.prematch_odds || {}, market);
  const now = oddsMarketValue(m?.live_odds || m?.odds || {}, market);
  if (!(before > 0 && now > 0)) return null;
  const pct = ((now - before) / before) * 100;
  const direction = pct > .01 ? "up" : pct < -.01 ? "down" : "same";
  return { available:true, market, label:oddsMarketLabel(market), prematch:before, live:now, delta:now-before, pct, direction };
}

function matchPassesCoreFilter(m, f) {
  f = f || {};
  if (String(f.signal_type || "") === "goal_wait" && f.goal_signal_enabled === false) return false;
  const minute = safeInt(m.minute, 0);
  const minMinute = clamp(safeInt(f.minute_min, 0), 0, 130);
  const maxMinute = clamp(safeInt(f.minute_max, 130), 0, 130);
  if (minute < minMinute || minute > maxMinute) return false;
  const score = scorePartsFromMatch(m);
  const goalsMax = safeInt(f.goals_max, 0);
  const scoreDiffMax = safeInt(f.score_diff_max, -1);
  if (goalsMax > 0 && score.total > goalsMax) return false;
  if (scoreDiffMax >= 0 && score.diff > scoreDiffMax) return false;
  let scoreList = f.scores || [];
  if (typeof scoreList === "string") scoreList = scoreList.split(",").map(x => x.trim()).filter(Boolean);
  if (scoreList.length && !scoreList.includes(score.text)) return false;
  const s = m.stats || {};
  const checks = [
    ["shots", f.shots_min],
    ["on_target", f.on_target_min],
    ["off_target", f.off_target_min],
    ["dangerous", f.dangerous_min],
    ["attacks", f.attacks_min],
    ["corners", f.corners_min],
    ["yellow_cards", f.yellow_cards_min],
    ["red_cards", f.red_cards_min],
  ];
  for (const [key, min] of checks) {
    if (safeInt(min, 0) > 0 && statTotal(s, key) < safeInt(min, 0)) return false;
  }
  if (f.possession_min) {
    const possHome = statSide(s, "possession", "home");
    const possAway = statSide(s, "possession", "away");
    if ((possHome + possAway) <= 0) return false;
    if (Math.max(possHome, possAway) < f.possession_min) return false;
  }
  if (f.pressure_min) {
    const hp = pressurePowerFromStats(s, "home");
    const ap = pressurePowerFromStats(s, "away");
    const total = hp + ap;
    if (total <= 0) return false;
    const maxPct = Math.round((Math.max(hp, ap) / total) * 100);
    if (maxPct < safeInt(f.pressure_min, 60)) return false;
  }
  if (f.odds_market) {
    const ov = oddsFilterSnapshot(m, f);
    if (!ov) return false;
    const wasMin = Number(f.odds_was_min) || 0;
    const wasMax = Number(f.odds_was_max) || 0;
    const nowMin = Number(f.odds_now_min) || 0;
    const nowMax = Number(f.odds_now_max) || 0;
    if (wasMin > 0 && ov.prematch < wasMin) return false;
    if (wasMax > 0 && ov.prematch > wasMax) return false;
    if (nowMin > 0 && ov.live < nowMin) return false;
    if (nowMax > 0 && ov.live > nowMax) return false;
    if (f.odds_direction === "up" && ov.direction !== "up") return false;
    if (f.odds_direction === "down" && ov.direction !== "down") return false;
    const pctMin = Number(f.odds_change_pct_min) || 0;
    if (pctMin > 0 && Math.abs(ov.pct) < pctMin) return false;
  }
  if (f.countries && f.countries.length && !f.countries.includes(m.country)) return false;
  return true;
}
function ratingBonus(value, min, maxBonus, fullExtraRatio = 0.75) {
  const threshold = safeInt(min, 0);
  if (threshold <= 0) return 0;
  const val = safeInt(value, 0);
  if (val < threshold) return 0;
  const needed = Math.max(1, Math.ceil(threshold * fullExtraRatio));
  return Math.min(maxBonus, ((val - threshold) / needed) * maxBonus);
}

function filterRatingLabel(score) {
  const n = safeInt(score, 0);
  if (n >= 90) return "🔥 Топ";
  if (n >= 82) return "🟢 Сильный";
  if (n >= 72) return "🟡 Хороший";
  if (n >= 62) return "⚪ Подходит";
  return "Слабый";
}

function statReason(label, value, min) {
  const threshold = safeInt(min, 0);
  const val = safeInt(value, 0);
  return threshold > 0 ? `${label} ${val}/${threshold}` : `${label} ${val}`;
}

function pressureSummaryFromStats(stats) {
  const homePower = pressurePowerFromStats(stats, "home");
  const awayPower = pressurePowerFromStats(stats, "away");
  const total = homePower + awayPower;
  const pct = total > 0 ? Math.round((Math.max(homePower, awayPower) / total) * 100) : 0;
  const side = homePower > awayPower ? "хозяев" : awayPower > homePower ? "гостей" : "обоюдно";
  return { pct, side };
}

function filterSignalForMatch(m, cfg, opts = {}) {
  const f = normalizeNotifyFilter(cfg || defaultNotifyFilter());
  if (!matchPassesCoreFilter(m, f)) return null;

  const s = m.stats || {};
  const score = scorePartsFromMatch(m);
  const minute = safeInt(m.minute, 0);
  const shots = statTotal(s, "shots");
  const onTarget = statTotal(s, "on_target");
  const dangerous = statTotal(s, "dangerous");
  const attacks = statTotal(s, "attacks");
  const corners = statTotal(s, "corners");
  const offTarget = statTotal(s, "off_target");
  const pressure = pressureSummaryFromStats(s);

  let index = 55;
  const minMinute = clamp(safeInt(f.minute_min, 0), 0, 130);
  const maxMinute = clamp(safeInt(f.minute_max, 130), 0, 130);
  const midMinute = (minMinute + maxMinute) / 2;
  const minuteSpan = Math.max(1, maxMinute - minMinute);
  const minuteFit = 1 - Math.min(1, Math.abs(minute - midMinute) / Math.max(1, minuteSpan / 2));
  index += 7 + minuteFit * 5;

  if (score.text === "0-0") index += 10;
  else if (score.diff === 0) index += 7;
  else if (score.diff === 1) index += 3;
  if (score.total <= 1) index += 3;

  index += ratingBonus(shots, f.shots_min, 10);
  index += ratingBonus(onTarget, f.on_target_min, 11);
  index += ratingBonus(dangerous, f.dangerous_min, 11);
  index += ratingBonus(attacks, f.attacks_min, 5);
  index += ratingBonus(corners, f.corners_min, 6);
  index += ratingBonus(offTarget, f.off_target_min, 3);
  if (safeInt(f.pressure_min, 0) > 0 && pressure.pct) {
    index += Math.min(7, Math.max(0, pressure.pct - safeInt(f.pressure_min, 60)) * 0.45);
  }

  const oddsSnap = f.odds_market ? oddsFilterSnapshot(m, f) : null;
  if (oddsSnap) {
    const arrow = oddsSnap.direction === "up" ? "↑" : oddsSnap.direction === "down" ? "↓" : "→";
    reasons.push(`${oddsSnap.label} ${oddsSnap.prematch.toFixed(2)}${arrow}${oddsSnap.live.toFixed(2)} (${oddsSnap.pct > 0 ? "+" : ""}${oddsSnap.pct.toFixed(1)}%)`);
    index += Math.min(10, 3 + Math.abs(oddsSnap.pct) * .25);
  }

  const leagueRank = leaguePowerRank(m.country, m.league);
  if (leagueRank <= 32) index += 4;
  else if (leagueRank <= 110) index += 2;
  else if (leagueRank >= 1200) index -= 4;

  const finalScore = clamp(Math.round(index), 1, 100);
  const reasons = [
    `${minute || "LIVE"} минута (${minMinute}–${maxMinute})`,
    `счёт ${score.text}`,
  ];
  if (safeInt(f.shots_min, 0) > 0) reasons.push(statReason("удары", shots, f.shots_min));
  if (safeInt(f.on_target_min, 0) > 0) reasons.push(statReason("в створ", onTarget, f.on_target_min));
  if (safeInt(f.dangerous_min, 0) > 0) reasons.push(statReason("опасные", dangerous, f.dangerous_min));
  if (safeInt(f.attacks_min, 0) > 0) reasons.push(statReason("атаки", attacks, f.attacks_min));
  if (safeInt(f.corners_min, 0) > 0) reasons.push(statReason("угловые", corners, f.corners_min));
  if (safeInt(f.pressure_min, 0) > 0 && pressure.pct) reasons.push(`давление ${pressure.pct}% ${pressure.side}`);
  if (leagueRank <= 32) reasons.push("топ-лига");

  return {
    type: opts.kind || "filter",
    score: finalScore,
    label: filterRatingLabel(finalScore),
    reason: reasons.slice(0, 5).join(" · "),
    reasons,
    profile: opts.profile || "",
    oddsSnapshot: oddsSnap || null,
  };
}

function signalMetaFromFilter(m, cfg, opts = {}) {
  const sig = filterSignalForMatch(m, cfg, opts);
  if (!sig) return {};
  return {
    filter_score: sig.score,
    filter_label: sig.label,
    filter_reason: sig.reason,
    filter_reasons: sig.reasons,
    filter_profile: sig.profile || "",
  };
}


function normalizeAlertReasons(value) {
  let arr = [];
  if (Array.isArray(value)) arr = value;
  else if (typeof value === "string") arr = value.split(/[·\n|;]+/);
  const out = [];
  const seen = new Set();
  for (const item of arr) {
    const clean = String(item || "").replace(/\s+/g, " ").trim().slice(0, 80);
    if (!clean || seen.has(clean)) continue;
    out.push(clean);
    seen.add(clean);
    if (out.length >= 8) break;
  }
  return out;
}

function notifyFilterSignal(m, cfg = null, label = "Фильтр") {
  const f = normalizeNotifyFilter(cfg || getNotifyFilter());
  if (!matchPassesCoreFilter(m, f)) return null;
  const s = m.stats || {};
  const score = scorePartsFromMatch(m);
  const minute = safeInt(m.minute, 0);
  const minMinute = clamp(safeInt(f.minute_min, 0), 0, 130);
  const maxMinute = clamp(safeInt(f.minute_max, 130), 0, 130);
  const reasons = [];
  const add = (reason) => {
    const clean = String(reason || "").replace(/\s+/g, " ").trim().slice(0, 80);
    if (clean && !reasons.includes(clean) && reasons.length < 8) reasons.push(clean);
  };

  add(minute ? `${minute} минута в диапазоне ${minMinute}-${maxMinute}` : "LIVE в нужном диапазоне");
  const scores = Array.isArray(f.scores) ? f.scores : [];
  if (scores.length) add(`счёт ${score.text}`);
  if (safeInt(f.goals_max, 0) > 0) add(`голов ${score.total}/${safeInt(f.goals_max, 0)}`);
  if (safeInt(f.score_diff_max, -1) >= 0) add(`разница ${score.diff}/${safeInt(f.score_diff_max, -1)}`);

  let rating = 48;
  if (minute && maxMinute >= minMinute) {
    const span = Math.max(1, maxMinute - minMinute);
    const center = (minMinute + maxMinute) / 2;
    const dist = Math.min(1, Math.abs(minute - center) / Math.max(1, span / 2));
    rating += 5 + (4 * (1 - dist));
  } else {
    rating += 4;
  }

  if (score.total === 0) rating += 10;
  else if (score.diff === 0) rating += 8;
  else if (score.diff === 1) rating += 5;
  else rating += 2;

  const statSpecs = [
    ["shots", "удары", 8, 0.65],
    ["on_target", "в створ", 9, 1.35],
    ["off_target", "мимо", 4, 0.45],
    ["dangerous", "опасные атаки", 9, 0.16],
    ["attacks", "атаки", 5, 0.045],
    ["corners", "угловые", 6, 0.85],
    ["yellow_cards", "жёлтые", 2, 0.35],
    ["red_cards", "красные", 2, 0.8],
  ];
  for (const [key, ru, cap, slope] of statSpecs) {
    const minVal = safeInt(f[`${key}_min`], 0);
    if (minVal <= 0) continue;
    const val = statTotal(s, key);
    add(`${ru} ${val}/${minVal}`);
    rating += Math.min(cap, (cap * 0.50) + Math.max(0, val - minVal) * slope);
  }

  const possMin = safeInt(f.possession_min, 0);
  if (possMin > 0) {
    const poss = statMaxSide(s, "possession", 0);
    add(`владение ${poss}%/${possMin}%`);
    rating += Math.min(4, 2 + Math.max(0, poss - possMin) * 0.10);
  }

  const pressureMin = safeInt(f.pressure_min, 0);
  if (pressureMin > 0) {
    const hp = pressurePowerFromStats(s, "home");
    const ap = pressurePowerFromStats(s, "away");
    const total = hp + ap;
    const pressurePct = total > 0 ? Math.round((Math.max(hp, ap) / total) * 100) : 0;
    const sideLabel = hp > ap ? "хозяев" : ap > hp ? "гостей" : "обоюдно";
    add(`давление ${pressurePct}%/${pressureMin}% ${sideLabel}`);
    rating += Math.min(8, 4 + Math.max(0, pressurePct - pressureMin) * 0.18);
  }

  const oddsSnap = f.odds_market ? oddsFilterSnapshot(m, f) : null;
  if (oddsSnap) {
    const arrow = oddsSnap.direction === "up" ? "↑" : oddsSnap.direction === "down" ? "↓" : "→";
    add(`${oddsSnap.label} ${oddsSnap.prematch.toFixed(2)}${arrow}${oddsSnap.live.toFixed(2)} (${oddsSnap.pct > 0 ? "+" : ""}${oddsSnap.pct.toFixed(1)}%)`);
    rating += Math.min(10, 3 + Math.abs(oddsSnap.pct) * .25);
  }

  if (Array.isArray(f.countries) && f.countries.length && f.countries.includes(m.country)) {
    add(`страна ${m.country}`);
    rating += 2;
  }

  const index = clamp(Math.round(rating), 1, 100);
  return {
    type: "notify_filter",
    label,
    index,
    reasons: normalizeAlertReasons(reasons),
    oddsSnapshot: oddsSnap || null,
  };
}

function notifySignalExtra(sig) {
  if (!sig) return {};
  const reasons = normalizeAlertReasons(sig.reasons || []);
  return {
    alert_score: safeInt(sig.index, 0),
    alert_reasons: reasons,
    alert_reason: reasons.join(" · "),
    odds_filter_market: sig.oddsSnapshot?.market || "",
    odds_filter_snapshot: sig.oddsSnapshot || {},
  };
}

function goalWaitSignal(m, cfg = null) {
  const f = normalizeNotifyFilter(cfg || fixedGoalWaitFilter(true));
  if (f.goal_signal_enabled === false) return null;
  if (!matchPassesCoreFilter(m, f)) return null;
  const s = m.stats || {};
  const score = scorePartsFromMatch(m);
  const shots = statTotal(s, "shots");
  const onTarget = statTotal(s, "on_target");
  const dangerous = statTotal(s, "dangerous");
  const corners = statTotal(s, "corners");
  const attacks = statTotal(s, "attacks");
  const minute = safeInt(m.minute, 0);

  const homePower = pressurePowerFromStats(s, "home");
  const awayPower = pressurePowerFromStats(s, "away");
  const pressureTotal = homePower + awayPower;
  const pressurePct = pressureTotal > 0 ? Math.round((Math.max(homePower, awayPower) / pressureTotal) * 100) : 50;
  const side = homePower > awayPower ? "home" : awayPower > homePower ? "away" : "both";
  const sideLabel = side === "home" ? "хозяев" : side === "away" ? "гостей" : "обоюдно";

  let index = 62;
  index += Math.min(12, Math.max(0, shots - f.shots_min) * 1.2);
  index += Math.min(10, Math.max(0, onTarget - f.on_target_min) * 2.0);
  index += Math.min(10, Math.max(0, dangerous - f.dangerous_min) * 0.35);
  index += Math.min(8, Math.max(0, corners - f.corners_min) * 1.7);
  if (attacks && f.attacks_min) index += Math.min(6, Math.max(0, attacks - f.attacks_min) * 0.08);
  if (score.text === "0-0") index += 7;
  else if (score.diff === 0) index += 5;
  if (minute >= 65 && minute <= 80) index += 5;
  index = clamp(Math.round(index), 60, 99);

  return {
    type: "goal_wait",
    icon: "",
    label: "Ждём гол",
    side,
    sideLabel,
    index,
    reasons: [
      `${minute || "LIVE"} минута`,
      `счёт ${score.text}`,
      `удары ${shots}`,
      `в створ ${onTarget}`,
      `опасные атаки ${dangerous}`,
      `угловые ${corners}`,
      `давление ${pressurePct}% ${sideLabel}`,
    ],
  };
}

function matchSignalScore(m) {
  const alertScore = safeInt(m?.alert_score, 0);
  if (alertScore > 0) return alertScore;
  const metaScore = safeInt(m?.filter_score, 0);
  if (metaScore > 0) return metaScore;
  return goalWaitSignal(m)?.index || 0;
}

function renderGoalWaitBadge(m) {
  const sig = goalWaitSignal(m);
  if (!sig) return "";
  return `<div class="match-signal-badge" title="${esc(sig.reasons.join(' · '))}"><b>${sig.index}/100</b><em>${esc(sig.label)}</em></div>`;
}

function renderMatchSignalBadge(m) {
  const score = safeInt(m?.alert_score || m?.filter_score, 0);
  if (score > 0) {
    const reasons = normalizeAlertReasons(m?.alert_reasons || m?.alert_reason || m?.filter_reasons || m?.filter_reason || []);
    const title = reasons.length ? reasons.join(" · ") : "Оценка по фильтру";
    const label = m?.filter_label || filterRatingLabel(score);
    return `<div class="match-signal-badge filter-score-badge" title="${esc(title)}"><b>${score}/100</b><em>${esc(label)}</em></div>`;
  }
  return renderGoalWaitBadge(m);
}

function renderFilterReasonLine(m) {
  const score = safeInt(m?.alert_score || m?.filter_score, 0);
  if (score <= 0) return "";
  const reasons = normalizeAlertReasons(m?.alert_reasons || m?.alert_reason || m?.filter_reasons || m?.filter_reason || []);
  const reason = reasons.slice(0, 5).join(" · ").trim();
  if (!reason) return "";
  const profile = String(m?.filter_profile || "").trim();
  return `<div class="match-filter-reason"><span>Причина${profile ? ` · ${esc(profile)}` : ""}:</span> ${esc(reason)}</div>`;
}

function renderGoalWaitDetailSignal(m, stats) {
  const match = { ...(m || {}), stats: stats || m?.stats || {} };
  const sig = goalWaitSignal(match);
  if (!sig) return "";
  return `<div class="goal-signal-card">
    <button class="info-mini-btn card-corner" type="button" onclick="showGoalWaitInfo()" aria-label="Что означает Ждём гол" title="Что означает Ждём гол">!</button>
    <div class="goal-signal-head"><b>${esc(sig.label)}</b><strong>${sig.index}/100</strong></div>
    <div class="goal-signal-sub">Активный матч: мало голов или ничейный счёт.</div>
    <div class="goal-signal-grid">${sig.reasons.map(r => `<div>${esc(r)}</div>`).join("")}</div>
  </div>`;
}

function matchPassesFilter(m, f) {
  return matchPassesCoreFilter(m, f);
}

function filteredMatches() {
  const all = flattenLive(state.live);
  let arr = all.filter(m => matchPassesFilter(m, state.filters));
  if (state.mainTab === "goal_wait") arr = arr.filter(m => !!goalWaitSignal(m));
  // v7: search by team / league / country name (case-insensitive, substring).
  const q = String(state.search || "").trim().toLowerCase();
  if (q) {
    arr = arr.filter(m =>
      String(m.home || "").toLowerCase().includes(q) ||
      String(m.away || "").toLowerCase().includes(q) ||
      String(m.league || "").toLowerCase().includes(q) ||
      String(m.country || "").toLowerCase().includes(q)
    );
  }
  return arr;
}

// ============================================================
//  Detail navigation + last opened match
// ============================================================
function normalizeMatchId(id) {
  return String(id || "").trim();
}

function uniqueIds(list) {
  const out = [];
  const seen = new Set();
  for (const x of (Array.isArray(list) ? list : [])) {
    const id = normalizeMatchId(x);
    if (!id || seen.has(id)) continue;
    seen.add(id);
    out.push(id);
  }
  return out;
}

function visibleMatchRowIds() {
  return uniqueIds(Array.from(document.querySelectorAll(".match-row[data-id]")).map(el => el.dataset.id));
}

function liveMatchIds() {
  return uniqueIds(flattenLive(state.live).map(m => m && m.id));
}

function currentFeedIdsForNav() {
  // Works for the main feed after filters/search. If the DOM list exists, it
  // wins because it also supports Favorites and Notifications screens.
  const rows = visibleMatchRowIds();
  if (rows.length) return rows;
  if (state.view === "matches") return uniqueIds(filteredMatches().map(m => m.id));
  return liveMatchIds();
}

function setDetailNavContext(ids, currentId) {
  const clean = uniqueIds(ids);
  const id = normalizeMatchId(currentId);
  state.detailNavIds = clean;
  state.detailNavIndex = clean.indexOf(id);
  if (state.detailNavIndex < 0 && id) {
    state.detailNavIds = [id, ...clean.filter(x => x !== id)];
    state.detailNavIndex = 0;
  }
}

function captureDetailNavFromScreen(currentId) {
  setDetailNavContext(currentFeedIdsForNav(), currentId);
}

function detailNavInfo() {
  const id = normalizeMatchId(state.selectedMatch || state.detail?.match?.id);
  let ids = uniqueIds(state.detailNavIds);
  if (!ids.length) ids = currentFeedIdsForNav();
  let index = ids.indexOf(id);
  if (index < 0 && id) {
    ids = [id, ...ids.filter(x => x !== id)];
    index = 0;
  }
  state.detailNavIds = ids;
  state.detailNavIndex = index;
  return {
    ids,
    index,
    total: ids.length,
    hasPrev: index > 0,
    hasNext: index >= 0 && index < ids.length - 1,
  };
}

function saveLastOpenedDetail(id, mode = "detail") {
  const k = normalizeMatchId(id);
  if (!k) return;
  const nav = detailNavInfo();
  const payload = {
    id: k,
    ts: Date.now(),
    mode,
    navIds: nav.ids.slice(0, 200),
    navIndex: nav.index,
  };
  try { localStorage.setItem(LAST_DETAIL_KEY, JSON.stringify(payload)); } catch (_) {}
}

function setLastOpenedMode(mode) {
  try {
    const raw = localStorage.getItem(LAST_DETAIL_KEY);
    if (!raw) return;
    const payload = JSON.parse(raw) || {};
    payload.mode = mode;
    payload.ts = Date.now();
    localStorage.setItem(LAST_DETAIL_KEY, JSON.stringify(payload));
  } catch (_) {}
}

function getLastOpenedDetail() {
  try {
    const payload = JSON.parse(localStorage.getItem(LAST_DETAIL_KEY) || "null");
    if (!payload || !payload.id) return null;
    if (Date.now() - safeInt(payload.ts, 0) > LAST_DETAIL_TTL_MS) {
      localStorage.removeItem(LAST_DETAIL_KEY);
      return null;
    }
    return payload;
  } catch (_) {
    return null;
  }
}

function clearLastOpenedDetail() {
  try { localStorage.removeItem(LAST_DETAIL_KEY); } catch (_) {}
}

function maybeRestoreLastOpenedDetail() {
  if (startupMatchId()) { state.detailBootRestoreTried = true; return false; }
  if (state.detailBootRestoreTried) return false;
  state.detailBootRestoreTried = true;

  const saved = getLastOpenedDetail();
  if (!saved || saved.mode !== "detail") return false;

  const id = normalizeMatchId(saved.id);
  const liveIds = liveMatchIds();
  if (!id || !liveIds.includes(id)) {
    clearLastOpenedDetail();
    return false;
  }

  const liveSet = new Set(liveIds);
  let navIds = uniqueIds(saved.navIds || []).filter(x => liveSet.has(x));
  if (!navIds.includes(id)) navIds.unshift(id);
  if (navIds.length < 2) navIds = liveIds;
  setDetailNavContext(navIds, id);

  loadDetail(id, { keepNav: true, restored: true });
  return true;
}

function renderDetailSwipeHud() {
  return "";
}

function renderDetailToast() {
  return state.detailToast ? `<div class="detail-toast">${esc(state.detailToast)}</div>` : "";
}

function showDetailToast(text) {
  state.detailToast = String(text || "");
  render();
  const token = state.detailToast;
  setTimeout(() => {
    if (state.detailToast === token) {
      state.detailToast = "";
      if (state.view === "detail") render();
    }
  }, 850);
}

function navigateDetail(delta) {
  const nav = detailNavInfo();
  if (nav.total < 2 || nav.index < 0) return;
  const nextIndex = nav.index + (delta > 0 ? 1 : -1);
  if (nextIndex < 0 || nextIndex >= nav.total) {
    try { tg?.HapticFeedback?.notificationOccurred?.("warning"); } catch (_) {}
    showDetailToast(delta > 0 ? "Это последний матч" : "Это первый матч");
    return;
  }
  const nextId = nav.ids[nextIndex];
  state.detailNavIndex = nextIndex;
  try { tg?.HapticFeedback?.impactOccurred?.("light"); } catch (_) {}
  loadDetail(nextId, { keepNav: true, fromSwipe: true });
}

let _detailSwipeStart = null;
function bindDetailSwipeHandlers() {
  if (app.__detailSwipeBound) return;
  app.__detailSwipeBound = true;

  app.addEventListener("touchstart", (e) => {
    if (state.view !== "detail" || state.sheet || !e.touches || e.touches.length !== 1) {
      _detailSwipeStart = null;
      return;
    }
    const target = e.target;
    if (target?.closest?.("button,input,select,textarea,a,.sheet,.bottom-nav")) {
      _detailSwipeStart = null;
      return;
    }
    const t = e.touches[0];
    _detailSwipeStart = {
      x: t.clientX,
      y: t.clientY,
      lastX: t.clientX,
      lastY: t.clientY,
      moved: false,
      at: Date.now()
    };
  }, { passive: true });

  app.addEventListener("touchmove", (e) => {
    if (!_detailSwipeStart || state.view !== "detail" || state.sheet || !e.touches || !e.touches.length) return;
    const t = e.touches[0];
    _detailSwipeStart.lastX = t.clientX;
    _detailSwipeStart.lastY = t.clientY;
    if (Math.abs(t.clientX - _detailSwipeStart.x) > 8 || Math.abs(t.clientY - _detailSwipeStart.y) > 8) {
      _detailSwipeStart.moved = true;
    }
  }, { passive: true });

  app.addEventListener("touchend", (e) => {
    if (!_detailSwipeStart || state.view !== "detail" || state.sheet) {
      _detailSwipeStart = null;
      return;
    }
    const fallback = _detailSwipeStart;
    const t = (e.changedTouches && e.changedTouches[0]) || null;
    const endX = t ? t.clientX : fallback.lastX;
    const endY = t ? t.clientY : fallback.lastY;
    const dx = endX - fallback.x;
    const dy = endY - fallback.y;
    const dt = Date.now() - fallback.at;
    const moved = fallback.moved;
    _detailSwipeStart = null;

    const absX = Math.abs(dx);
    const absY = Math.abs(dy);
    if (!moved || dt > 950 || absX < 48 || absY > 80 || absX < absY * 1.25) return;

    // left swipe = next match, right swipe = previous match
    navigateDetail(dx < 0 ? 1 : -1);
  }, { passive: true });
}

// ============================================================
//  API
// ============================================================
let _loadLiveInFlight = false;
async function loadLive(force = false) {
  if (_loadLiveInFlight) return;
  _loadLiveInFlight = true;
  const preserveMatchScroll = state.view === "matches" && !state.sheet;
  if (preserveMatchScroll) saveMatchListPosition();
  try {
    const res = await fetch(`/api/live${force ? "?force=1" : ""}`, { cache: "no-store" });
    state.live = await res.json();
    // v6: snapshot every currently-favorited match so finished cards survive
    // after the server drops them from the live cache.
    try { refreshFavCacheFromLive(flattenLive(state.live)); } catch (_) {}
  } catch (err) {
    state.live = { ok: false, total: 0, countries: [], error: String(err) };
  } finally {
    state.loading = false;
    checkNotifyMatches();
    checkGoalWaitNotifyMatches();
    checkGoalAlerts();

    if (maybeRestoreLastOpenedDetail()) {
      _loadLiveInFlight = false;
      return;
    }

    if (preserveMatchScroll && document.getElementById("match-feed")) {
      refreshMatchesScreenOnly({ preserveHeight: true });
      restoreMatchListPosition();
    } else {
      render();
      if (preserveMatchScroll) restoreMatchListPosition();
    }
    _loadLiveInFlight = false;
  }
}


function getPressureHistory() {
  try { return JSON.parse(localStorage.getItem(PRESSURE_HISTORY_KEY) || "{}") || {}; }
  catch { return {}; }
}
function savePressureHistory(obj) {
  try { localStorage.setItem(PRESSURE_HISTORY_KEY, JSON.stringify(obj || {})); }
  catch (_) {}
}
function statPairValue(stats, key, side) {
  const p = stats && stats[key] ? stats[key] : {};
  return safeInt(p[side], 0);
}
function pressureFlatFromStats(stats) {
  return {
    attacks_home: statPairValue(stats, "attacks", "home"),
    attacks_away: statPairValue(stats, "attacks", "away"),
    dangerous_home: statPairValue(stats, "dangerous", "home"),
    dangerous_away: statPairValue(stats, "dangerous", "away"),
    shots_home: statPairValue(stats, "shots", "home"),
    shots_away: statPairValue(stats, "shots", "away"),
    on_target_home: statPairValue(stats, "on_target", "home"),
    on_target_away: statPairValue(stats, "on_target", "away"),
    corners_home: statPairValue(stats, "corners", "home"),
    corners_away: statPairValue(stats, "corners", "away"),
  };
}
function pressureDelta(latest, oldest, key) {
  return Math.max(0, safeInt(latest[key], 0) - safeInt(oldest[key], 0));
}
function pressureSidePayload(latest, oldest, side) {
  const suf = side === "home" ? "_home" : "_away";
  const attacks = pressureDelta(latest, oldest, "attacks" + suf);
  const dangerous = pressureDelta(latest, oldest, "dangerous" + suf);
  const shots = pressureDelta(latest, oldest, "shots" + suf);
  const onTarget = pressureDelta(latest, oldest, "on_target" + suf);
  const corners = pressureDelta(latest, oldest, "corners" + suf);
  const goals = pressureDelta(latest, oldest, "__chart_score" + suf);
  const score = pressureWeightedScore(attacks, dangerous, shots, onTarget, corners, goals);
  return {
    score,
    attacks_delta: attacks,
    dangerous_delta: dangerous,
    shots_delta: shots,
    on_target_delta: onTarget,
    corners_delta: corners,
    goals_delta: goals,
  };
}
function currentPressureSidePayload(flat, side) {
  const suf = side === "home" ? "_home" : "_away";
  const zero = {};
  for (const k of Object.keys(flat || {})) zero[k] = 0;
  return pressureSidePayload(flat, zero, side);
}
function buildPressurePayload(latestFlat, oldestFlat, spanSeconds, mode, sampleCount) {
  const home = mode === "current_snapshot" ? currentPressureSidePayload(latestFlat, "home") : pressureSidePayload(latestFlat, oldestFlat, "home");
  const away = mode === "current_snapshot" ? currentPressureSidePayload(latestFlat, "away") : pressureSidePayload(latestFlat, oldestFlat, "away");
  const total = Number(home.score || 0) + Number(away.score || 0);
  if (total > 0) {
    home.percent = Math.round((Number(home.score || 0) / total) * 100);
    away.percent = Math.max(0, 100 - home.percent);
  } else {
    home.percent = 50;
    away.percent = 50;
  }
  const diff = Math.abs(Number(home.score || 0) - Number(away.score || 0));
  let leader = "none";
  if (total > 0 && diff <= Math.max(3, total * 0.12)) leader = "balanced";
  else if (total > 0) leader = Number(home.score || 0) > Number(away.score || 0) ? "home" : "away";
  return {
    available: true,
    source: "client",
    mode,
    window_minutes: 20,
    span_seconds: Math.max(0, spanSeconds || 0),
    sample_count: sampleCount || 1,
    leader,
    home,
    away,
  };
}
function attachClientPressure(payload) {
  if (!payload || !payload.ok || !payload.match || !payload.match.id) return payload;
  // v9.19: the server now collects pressure history for every live match in a
  // background thread (collector, ~every 60s) independent of any user
  // activity. If the server already returned a useable pressure indicator,
  // prefer it — it spans the full match history, not just snapshots seen by
  // this device. The client-side fallback below remains for edge cases (e.g.
  // server just (re)started and has only one snapshot for this match yet).
  if (payload.pressure && payload.pressure.available === true) {
    return payload;
  }
  const stats = payload.stats || {};
  if (!stats || !Object.keys(stats).length) {
    payload.pressure = payload.pressure || { available: false, window_minutes: 20, reason: "no_stats" };
    return payload;
  }
  const mid = String(payload.match.id);
  const now = Math.floor(Date.now() / 1000);
  const flat = pressureFlatFromStats(stats);
  const store = getPressureHistory();
  const list = Array.isArray(store[mid]) ? store[mid] : [];
  const last = list.length ? list[list.length - 1] : null;
  const changed = !last || JSON.stringify(last.stats || {}) !== JSON.stringify(flat);
  if (!last || changed || now - safeInt(last.ts, 0) >= 12) list.push({ ts: now, stats: flat });
  const cutoff = now - 1200;
  const fresh = list.filter(x => x && safeInt(x.ts, 0) >= now - 10800).slice(-240);
  store[mid] = fresh;
  savePressureHistory(store);
  const inWindow = fresh.filter(x => safeInt(x.ts, 0) >= cutoff);
  const oldest = inWindow[0] || fresh[0];
  const latest = fresh[fresh.length - 1];
  if (oldest && latest && safeInt(latest.ts, 0) > safeInt(oldest.ts, 0)) {
    payload.pressure = buildPressurePayload(latest.stats || flat, oldest.stats || flat, safeInt(latest.ts, 0) - safeInt(oldest.ts, 0), "last20", fresh.length);
  } else {
    payload.pressure = buildPressurePayload(flat, flat, 0, "current_snapshot", fresh.length || 1);
  }
  return payload;
}

function syncDetailPayloadWithLive(payload) {
  if (!payload || !payload.ok || !payload.match) return payload;
  const id = String(payload.match.id || state.selectedMatch || "");
  const live = flattenLive(state.live).find(row => String(row?.id || "") === id);
  if (!live || live.finished || live.is_live === false) return payload;

  const match = { ...payload.match };
  const liveMinute = safeInt(live.minute, 0);
  const detailMinute = safeInt(match.minute, 0);
  const detailText = String(match.minute_text || "").trim();
  const periodOnly = /^(?:1st|2nd|first|second)\s*(?:half|period)$|^(?:1|2)[тt]$|^ht$|^перерыв$/i.test(detailText);
  const liveClockFresher = liveMinute > 0 && (
    detailMinute <= 0 ||
    liveMinute > detailMinute + 1 ||
    (liveMinute > 10 && (detailMinute === 1 || detailMinute === 2)) ||
    periodOnly
  );

  // Keep exact identity and logos from the main Live row.
  for (const key of [
    "id","provider_match_id","slug","link","home","away","home_id","away_id",
    "home_logo","away_logo","country","country_code","league","league_logo",
    "competition_path","competition_id","competition_slug","sport"
  ]) {
    const value = live[key];
    if (value !== undefined && value !== null && value !== "") match[key] = value;
  }

  if (liveClockFresher) {
    match.minute = liveMinute;
    match.minute_text = normalizeMatchMinuteText(live.minute_text, liveMinute);
    match.period = live.period || (liveMinute > 45 ? "2T" : "1T");
  }

  const detailHome = safeInt(match.score_home, 0);
  const detailAway = safeInt(match.score_away, 0);
  const liveHome = safeInt(live.score_home, 0);
  const liveAway = safeInt(live.score_away, 0);
  // Never replace a newer detail goal with an older list score, but do promote
  // the list score when it is clearly ahead.
  if (liveHome + liveAway > detailHome + detailAway || payload.detail_mismatch) {
    match.score_home = liveHome;
    match.score_away = liveAway;
    match.score = live.score || `${liveHome}-${liveAway}`;
  }

  match.is_live = true;
  match.finished = false;
  match.status = "live";
  return { ...payload, match, finished: false };
}

let _loadDetailSeq = 0;
async function loadDetail(id, opts = {}) {
  id = normalizeMatchId(id);
  if (!id) return;
  const seq = ++_loadDetailSeq;
  if (!opts.keepNav) captureDetailNavFromScreen(id);
  if (opts.returnView) state.detailReturnView = String(opts.returnView);
  else if (state.view !== "detail") state.detailReturnView = ["competition", "favorites", "notify"].includes(state.view) ? state.view : "matches";
  state.selectedMatch = id;
  state.view = "detail";
  // V10.33: show a cached/full detail or a lightweight Live preview instantly.
  // The SportScore detail request continues in the background.
  state.detail = readFastDetailCache(id) || fastDetailPreviewFromLive(id);
  if (state.detail?.ok) state.detail = syncDetailPayloadWithLive(state.detail);
  state.avgTotalOpen = false;
  state.avgTotalLoading = false;
  state.avgTotalData = null;
  state.avgTotalError = "";
  state.detailTab = "details";
  state.detailMatchesSide = "home";
  state.detailToast = "";
  saveLastOpenedDetail(id, "detail");
  render();
  try {
    const res = await fetch(`/api/match?id=${encodeURIComponent(id)}`, { cache: "no-store" });
    let payload = await res.json();
    if (seq !== _loadDetailSeq) return;
    if (payload && payload.ok) {
      payload = syncDetailPayloadWithLive(payload);
      payload = attachClientPressure(payload);
      if (payload.match && isFav(id)) {
        saveFavCache(id, { ...payload.match, finished: Boolean(payload.finished || payload.match.finished) });
      }
      state.detail = payload;
      saveFastDetailCache(id, payload);
    } else if (payload && payload.error === "match_not_found") {
      // v6: backend says match is gone (finished + cleaned up). Try local cache
      // — the favorites cache stores the last live snapshot, so we can still
      // show a card for it.
      const cached = getFavCachedMatch(id) || getNotifyCachedMatch(id);
      if (cached) {
        state.detail = {
          ok: true,
          match: { ...cached, finished: true },
          stats: cached.stats || {},
          events: [],
          avg: { home: { avg: null, count: 0, zero_zero: 0 }, away: { avg: null, count: 0, zero_zero: 0 } },
          finished: true,
          from_cache: true,
        };
      } else {
        state.detail = { ok: false, error: "match_not_found", message: payload.message || "Матч не найден." };
      }
    } else {
      state.detail = payload || { ok: false, error: "unknown" };
    }
  } catch (err) {
    if (seq !== _loadDetailSeq) return;
    // Network error — try cache as a final fallback.
    const cached = getFavCachedMatch(id) || getNotifyCachedMatch(id);
    if (cached) {
      state.detail = {
        ok: true, match: { ...cached, finished: true }, stats: cached.stats || {}, events: [],
        avg: { home: { avg: null, count: 0, zero_zero: 0 }, away: { avg: null, count: 0, zero_zero: 0 } },
        finished: true, from_cache: true,
      };
    } else {
      state.detail = { ok: false, error: String(err) };
    }
  }
  render();
}

async function loadNotifyMatches(rerender = true) {
  state.notifyMatchesLoading = true;
  if (rerender && state.view === "notify") render();
  try {
    const res = await fetch(`/api/notify/matches`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ init_data: tg?.initData || "" }),
      cache: "no-store",
    });
    const payload = await res.json();
    state.notifyMatches = payload.items || [];
    saveNotifyCacheFromAlerts(state.notifyMatches);
  } catch (err) {
    state.notifyMatches = state.notifyMatches || [];
  } finally {
    state.notifyMatchesLoading = false;
    if (rerender && state.view === "notify") render();
  }
}

function currentNotifyMatchIdsForClear() {
  const ids = new Set();
  for (const item of [...(state.notifyMatches || []), ...(state.inAppAlerts || [])]) {
    const id = String(item?.id || item?.match_id || "").trim();
    if (id) ids.add(id);
  }
  try {
    for (const id of Object.keys(getNotifyCache() || {})) {
      const clean = String(id || "").trim();
      if (clean) ids.add(clean);
    }
  } catch (_) {}
  return [...ids];
}

async function clearNotifyMatches() {
  if (!confirm("Очистить найденные матчи?")) return;
  const matchIds = currentNotifyMatchIdsForClear();
  try {
    const res = await fetch("/api/notify/clear", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ init_data: tg?.initData || "", match_ids: matchIds, clear_all: true }),
    });
    let payload = {};
    try { payload = await res.json(); } catch (_) {}
    if (!res.ok || payload.ok === false) throw new Error(payload.error || `HTTP ${res.status}`);
    state.notifyMatches = [];
    state.inAppAlerts = [];
    state.unreadAlerts = 0;
    forgetAutoGoalNotifyForMatches(matchIds);
    clearNotifyCache();
  } catch (err) {
    try { tg?.showAlert?.(`Не удалось очистить на сервере. Открой Mini App заново и повтори.

${String(err?.message || err || "")}`); } catch (_) {}
  }
  render();
}

async function removeNotifyMatch(id) {
  const k = String(id || "");
  if (!k) return;
  state.notifyMatches = (state.notifyMatches || []).filter(x => String(x?.id || x?.match_id || "") !== k);
  state.inAppAlerts = (state.inAppAlerts || []).filter(x => String(x?.id || x?.match_id || "") !== k);
  removeNotifyCache(k);
  forgetAutoGoalNotifyForMatches([k]);
  try {
    const res = await fetch("/api/notify/remove", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ init_data: tg?.initData || "", match_id: k }),
    });
    let payload = {};
    try { payload = await res.json(); } catch (_) {}
    if (!res.ok || payload.ok === false) throw new Error(payload.error || `HTTP ${res.status}`);
  } catch (err) {
    try { tg?.showAlert?.(`Не удалось удалить матч на сервере. Открой Mini App заново и повтори.

${String(err?.message || err || "")}`); } catch (_) {}
  }
  if (state.view === "notify") render();
}

// ============================================================
//  Notify check: if a match matches the filter and was not seen yet,
//  push an in-app alert + (if Telegram tg.HapticFeedback available) buzz
// ============================================================
function checkNotifyMatches() {
  const cfg = getNotifyFilter();
  if (!cfg.enabled) return;
  const seen = getSeenAlerts();
  const newAlerts = [];
  for (const m of flattenLive(state.live)) {
    const sig = notifyFilterSignal(m, cfg, "Фильтр");
    if (!sig) continue;
    const id = String(m.id);
    if (seen.has(id)) continue;
    seen.add(id);
    newAlerts.push(notifySnapshotFromMatch(m, {
      id,
      ts: Date.now(),
      title: `Матч нашёлся: ${m.home} ${m.score_home}-${m.score_away} ${m.away}`,
      subtitle: `${m.minute_text || ""} · ${m.country} · ${m.league}`,
      alert_kind: "filter",
      alert_title: `Матч нашёлся: ${m.home} ${m.score_home}-${m.score_away} ${m.away}`,
      alert_subtitle: `${m.minute_text || ""} · ${m.country} · ${m.league}`,
      ...notifySignalExtra(sig),
    }));
  }
  if (newAlerts.length) {
    saveSeenAlerts(seen);
    saveNotifyCacheFromAlerts(newAlerts);
    // v9.67: filter notifications should not automatically enable goal alerts.
    // Goal alerts stay manual (favorite prompt) or come from the separate Ждём гол flow.
    state.inAppAlerts = [...newAlerts, ...state.inAppAlerts].slice(0, 50);
    state.unreadAlerts = Math.min(99, state.unreadAlerts + newAlerts.length);
    try { tg?.HapticFeedback?.notificationOccurred?.("warning"); } catch (_) {}
    playAlertSound("found");
    // Server-side delivery/storage. Telegram message is short; details stay in the app.
    for (const a of newAlerts) {
      fetch("/api/notify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          init_data: tg?.initData || "",
          match_id: a.id,
          match: a,
        }),
      }).then(() => loadNotifyMatches(false)).catch(() => {});
    }
  }
}

// ============================================================
//  Fixed "Ждём гол" notifications from the main tab
// ============================================================
function checkGoalWaitNotifyMatches() {
  if (!isGoalWaitPushEnabled()) return;
  const seen = getGoalWaitSeen();
  const cfg = fixedGoalWaitFilter(true);
  const newAlerts = [];
  for (const m of flattenLive(state.live)) {
    const sig = goalWaitSignal(m, cfg);
    if (!sig) continue;
    const id = String(m.id || "");
    if (!id || seen.has(id)) continue;
    seen.add(id);
    newAlerts.push(notifySnapshotFromMatch(m, {
      id,
      ts: Date.now(),
      title: `Ждём гол: ${m.home} ${m.score_home}-${m.score_away} ${m.away}`,
      subtitle: `${m.minute_text || ""} · ${m.country || ""} · ${m.league || ""}`,
      alert_kind: "goal_wait",
      alert_title: `Ждём гол: ${m.home} ${m.score_home}-${m.score_away} ${m.away}`,
      alert_subtitle: `${m.minute_text || ""} · ${m.country || ""} · ${m.league || ""}`,
      ...notifySignalExtra(sig),
    }));
  }
  if (newAlerts.length) {
    saveGoalWaitSeen(seen);
    saveNotifyCacheFromAlerts(newAlerts);
    if (getGoalWaitAutoGoalEnabled()) rememberAutoGoalNotifyForMatches(newAlerts);
    state.inAppAlerts = [...newAlerts, ...state.inAppAlerts].slice(0, 50);
    state.unreadAlerts = Math.min(99, state.unreadAlerts + newAlerts.length);
    try { tg?.HapticFeedback?.notificationOccurred?.("warning"); } catch (_) {}
    playAlertSound("found");
    for (const a of newAlerts) {
      fetch("/api/notify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ init_data: tg?.initData || "", match_id: a.id, match: a, auto_goal: getGoalWaitAutoGoalEnabled() }),
      }).then(() => loadNotifyMatches(false)).catch(() => {});
    }
  }
}

function toggleGoalWaitNotifyEnabled() {
  const next = !getGoalWaitNotifyEnabled();
  setGoalWaitNotifyEnabled(next);
  fetch("/api/goal-wait-subscribe", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      init_data: tg?.initData || "",
      enabled: isGoalWaitPushEnabled(),
      auto_goal_enabled: getGoalWaitAutoGoalEnabled(),
    }),
  }).catch(() => {});
  if (next) checkGoalWaitNotifyMatches();
  render();
}

function toggleGoalWaitAutoGoalEnabled() {
  const next = !getGoalWaitAutoGoalEnabled();
  setGoalWaitAutoGoalEnabled(next);
  if (!next) {
    // Stop local auto goal tracking that came from Ждём гол alerts.
    saveAutoGoalNotifies(new Set());
  }
  fetch("/api/goal-wait-subscribe", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      init_data: tg?.initData || "",
      enabled: isGoalWaitPushEnabled(),
      auto_goal_enabled: next,
    }),
  }).catch(() => {});
  render();
}

// ============================================================
//  Goal alerts for starred matches
// ============================================================
function checkGoalAlerts() {
  const ids = new Set([...getGoalNotifies(), ...getAutoGoalNotifies()]);
  if (!ids.size) return;
  const saved = getGoalNotifyScores();
  let changed = false;
  const newAlerts = [];

  for (const m of flattenLive(state.live)) {
    const id = String(m.id || "");
    if (!ids.has(id)) continue;
    const score = goalScoreText(m);
    const total = goalTotal(m);
    const prev = saved[id];
    if (!prev) {
      saved[id] = { score, total, ts: Date.now() };
      changed = true;
      continue;
    }
    const prevTotal = safeInt(prev.total, total);
    if (total > prevTotal) {
      newAlerts.push(notifySnapshotFromMatch(m, {
        id,
        ts: Date.now(),
        alert_kind: "goal",
        alert_title: `Гол! ${m.home} ${score} ${m.away}`,
        alert_subtitle: `${m.minute_text || ""} · ${m.country || ""} · ${m.league || ""}`,
        score,
      }));
    }
    if (prev.score !== score || prevTotal !== total) {
      saved[id] = { score, total, ts: Date.now(), auto: !!prev.auto };
      changed = true;
    }
  }

  if (changed) saveGoalNotifyScores(saved);
  if (newAlerts.length) {
    saveNotifyCacheFromAlerts(newAlerts);
    state.inAppAlerts = [...newAlerts, ...state.inAppAlerts].slice(0, 50);
    state.unreadAlerts = Math.min(99, state.unreadAlerts + newAlerts.length);
    try { tg?.HapticFeedback?.notificationOccurred?.("success"); } catch (_) {}
    playAlertSound("goal");
    for (const a of newAlerts) {
      fetch("/api/notify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ init_data: tg?.initData || "", match_id: a.id, match: a }),
      }).then(() => loadNotifyMatches(false)).catch(() => {});
    }
  }
}
// ============================================================
//  RENDERING
// ============================================================
function render() {
  app.classList.toggle("detail-mode", state.view === "detail" || state.view === "team" || state.view === "competition");
  app.classList.toggle("main-mode", state.view === "matches");
  if (state.view === "competition") return renderCompetitionView();
  if (state.view === "team") return renderTeamView();
  if (state.view === "detail") return renderDetail();
  if (state.view === "favorites") return renderFavorites();
  if (state.view === "notify") return renderNotify();
  return renderMatches();
}

// ----------------------------------------
//  Matches feed (main screen)
// ----------------------------------------
function renderMatches() {
  const total = state.live ? safeInt(state.live.total, flattenLive(state.live).length) : 0;
  app.innerHTML = `
    ${renderTopbar(total)}
    <div id="goal-wait-notify-strip">${renderGoalWaitNotifyStrip()}</div>
    <div id="match-feed">${renderMatchFeedInner()}</div>
    ${renderSportScoreAttribution()}
    ${renderBottomNav("matches")}
    ${renderSheet()}
  `;
  bindMatchHandlers();
}

function renderMatchFeedInner() {
  if (state.loading) return `<div class="loading"><div class="spinner"></div>Загрузка матчей…</div>`;
  const visible = filteredMatches();
  const groups = groupByLeague(visible);
  if (groups.length === 0) return renderEmpty();
  return groups.map(renderLeagueGroup).join("");
}

// v7/v9.42: feed-only update keeps focus/scroll and avoids repainting the whole app.
function sameHtml(a, b) {
  return String(a || "").trim() === String(b || "").trim();
}

function childRows(group) {
  return Array.from(group?.children || []).filter(el => el.classList && el.classList.contains("match-row"));
}


function flashLiveChanged(el) {
  if (!el) return;
  el.classList.remove("live-field-updated");
  // force restart the tiny highlight without a full repaint
  void el.offsetWidth;
  el.classList.add("live-field-updated");
  window.setTimeout(() => {
    try { el.classList.remove("live-field-updated"); } catch (_) {}
  }, 520);
}

function syncClassAndDataset(cur, next) {
  if (!cur || !next) return;
  if (cur.className !== next.className) cur.className = next.className;
  for (const attr of Array.from(cur.attributes || [])) {
    if (attr.name.startsWith("data-") && !next.hasAttribute(attr.name)) cur.removeAttribute(attr.name);
  }
  for (const attr of Array.from(next.attributes || [])) {
    if (attr.name.startsWith("data-") && cur.getAttribute(attr.name) !== attr.value) cur.setAttribute(attr.name, attr.value);
  }
}

function setTextLive(el, value) {
  if (!el) return false;
  const next = String(value ?? "");
  if (el.textContent === next) return false;
  el.textContent = next;
  flashLiveChanged(el);
  return true;
}

function replaceOuterIfDifferent(cur, next) {
  if (!cur || !next) return false;
  if (sameHtml(cur.outerHTML, next.outerHTML)) return false;
  cur.outerHTML = next.outerHTML;
  return true;
}

function patchScoreRows(curRow, nextRow) {
  const curScores = Array.from(curRow.querySelectorAll(".match-score-row"));
  const nextScores = Array.from(nextRow.querySelectorAll(".match-score-row"));
  if (curScores.length !== nextScores.length) {
    const curScoreBox = curRow.querySelector(".match-score");
    const nextScoreBox = nextRow.querySelector(".match-score");
    if (curScoreBox && nextScoreBox && !sameHtml(curScoreBox.outerHTML, nextScoreBox.outerHTML)) curScoreBox.outerHTML = nextScoreBox.outerHTML;
    return;
  }
  for (let i = 0; i < nextScores.length; i++) {
    const cur = curScores[i];
    const next = nextScores[i];
    if (cur.className !== next.className) cur.className = next.className;
    setTextLive(cur, next.textContent);
  }
}

function patchTeamLines(curRow, nextRow) {
  const curTeams = curRow.querySelector(".match-teams");
  const nextTeams = nextRow.querySelector(".match-teams");
  if (!curTeams || !nextTeams) return false;

  const curLines = Array.from(curTeams.querySelectorAll(":scope > .match-team-line"));
  const nextLines = Array.from(nextTeams.querySelectorAll(":scope > .match-team-line"));
  if (curLines.length !== nextLines.length) {
    if (!sameHtml(curTeams.outerHTML, nextTeams.outerHTML)) curTeams.outerHTML = nextTeams.outerHTML;
    return true;
  }

  // Team names/logos rarely change. Keep existing nodes when possible so logos do not blink.
  for (let i = 0; i < nextLines.length; i++) {
    const curLine = curLines[i];
    const nextLine = nextLines[i];
    const curName = curLine.querySelector(".match-team");
    const nextName = nextLine.querySelector(".match-team");
    const curLogo = curLine.querySelector("img");
    const nextLogo = nextLine.querySelector("img");

    if (curName && nextName) setTextLive(curName, nextName.textContent);
    if (curLogo && nextLogo && curLogo.getAttribute("src") !== nextLogo.getAttribute("src")) {
      curLogo.setAttribute("src", nextLogo.getAttribute("src") || "");
    } else if (!curLogo || !nextLogo) {
      if (!sameHtml(curLine.outerHTML, nextLine.outerHTML)) curLine.outerHTML = nextLine.outerHTML;
    }
  }

  // Badges / reason block after the two team lines can change often.
  const curExtra = Array.from(curTeams.children).slice(nextLines.length).map(el => el.outerHTML).join("");
  const nextExtra = Array.from(nextTeams.children).slice(nextLines.length).map(el => el.outerHTML).join("");
  if (!sameHtml(curExtra, nextExtra)) {
    Array.from(curTeams.children).slice(nextLines.length).forEach(el => el.remove());
    Array.from(nextTeams.children).slice(nextLines.length).forEach(el => curTeams.appendChild(el.cloneNode(true)));
  }
  return true;
}

function patchStarButton(curRow, nextRow) {
  const cur = curRow.querySelector(".star-btn");
  const next = nextRow.querySelector(".star-btn");
  if (!cur || !next) return replaceOuterIfDifferent(cur, next);
  if (cur.className !== next.className) cur.className = next.className;
  if (cur.getAttribute("title") !== next.getAttribute("title")) cur.setAttribute("title", next.getAttribute("title") || "");
  if (cur.dataset.fav !== next.dataset.fav) cur.dataset.fav = next.dataset.fav || "";
  if (cur.textContent !== next.textContent) cur.textContent = next.textContent;
}

function patchMinute(curRow, nextRow) {
  const cur = curRow.querySelector(".match-minute");
  const next = nextRow.querySelector(".match-minute");
  if (!cur || !next) return replaceOuterIfDifferent(cur, next);
  if (cur.className !== next.className) cur.className = next.className;
  setTextLive(cur, next.textContent);
}

function patchMatchRowInPlace(curRow, nextRow) {
  if (!curRow || !nextRow) return false;
  syncClassAndDataset(curRow, nextRow);

  const curHeat = curRow.querySelector(".match-heat-edge");
  const nextHeat = nextRow.querySelector(".match-heat-edge");
  if (curHeat && nextHeat && curHeat.className !== nextHeat.className) curHeat.className = nextHeat.className;

  patchMinute(curRow, nextRow);
  patchTeamLines(curRow, nextRow);
  patchScoreRows(curRow, nextRow);
  patchStarButton(curRow, nextRow);
  return true;
}

function patchLeagueGroupInPlace(curGroup, nextGroup) {
  syncClassAndDataset(curGroup, nextGroup);

  const curHeader = curGroup.querySelector(".league-header");
  const nextHeader = nextGroup.querySelector(".league-header");
  if (curHeader && nextHeader && !sameHtml(curHeader.outerHTML, nextHeader.outerHTML)) {
    curHeader.outerHTML = nextHeader.outerHTML;
  }

  const rowsById = new Map(childRows(curGroup).map(row => [String(row.dataset.id || ""), row]));
  const nextRows = childRows(nextGroup);
  const seen = new Set();
  let anchor = curGroup.querySelector(".league-header");

  for (const nextRow of nextRows) {
    const id = String(nextRow.dataset.id || "");
    let curRow = rowsById.get(id);
    if (!curRow) {
      curRow = nextRow.cloneNode(true);
      curRow.classList.add("live-patch-enter");
      curGroup.insertBefore(curRow, anchor ? anchor.nextSibling : null);
      requestAnimationFrame(() => curRow.classList.remove("live-patch-enter"));
    } else {
      patchMatchRowInPlace(curRow, nextRow);
      if (anchor && anchor.nextSibling !== curRow) {
        curGroup.insertBefore(curRow, anchor.nextSibling);
      }
    }
    seen.add(id);
    anchor = curRow;
  }

  for (const curRow of childRows(curGroup)) {
    const id = String(curRow.dataset.id || "");
    if (!seen.has(id)) {
      curRow.classList.add("live-patch-leave");
      window.setTimeout(() => {
        try { curRow.remove(); } catch (_) {}
      }, 180);
    }
  }
}

function patchMatchFeedDom(node, nextHTML) {
  if (!node) return false;
  if (sameHtml(node.innerHTML, nextHTML)) return false;

  const tpl = document.createElement("template");
  tpl.innerHTML = nextHTML.trim();
  const nextChildren = Array.from(tpl.content.children);

  const allNextGroups = nextChildren.length > 0 && nextChildren.every(el => el.classList && el.classList.contains("league-group"));
  if (!allNextGroups) {
    node.innerHTML = nextHTML;
    return true;
  }

  const currentGroups = Array.from(node.children).filter(el => el.classList && el.classList.contains("league-group"));
  const currentByKey = new Map(currentGroups.map(g => [String(g.dataset.leagueKey || ""), g]));
  const seenKeys = new Set();
  let anchor = null;

  for (const nextGroup of nextChildren) {
    const key = String(nextGroup.dataset.leagueKey || "");
    let curGroup = currentByKey.get(key);

    if (!curGroup) {
      curGroup = nextGroup.cloneNode(true);
      curGroup.classList.add("live-patch-enter");
      node.insertBefore(curGroup, anchor ? anchor.nextSibling : node.firstChild);
      requestAnimationFrame(() => curGroup.classList.remove("live-patch-enter"));
    } else {
      patchLeagueGroupInPlace(curGroup, nextGroup);
      const wantedBefore = anchor ? anchor.nextSibling : node.firstChild;
      if (wantedBefore !== curGroup) node.insertBefore(curGroup, wantedBefore);
    }

    seenKeys.add(key);
    anchor = curGroup;
  }

  for (const group of currentGroups) {
    const key = String(group.dataset.leagueKey || "");
    if (!seenKeys.has(key)) {
      group.classList.add("live-patch-leave");
      window.setTimeout(() => {
        try { group.remove(); } catch (_) {}
      }, 180);
    }
  }

  return true;
}

function replaceOuterIfChanged(el, html) {
  if (!el) return false;
  if (sameHtml(el.outerHTML, html)) return false;
  el.outerHTML = html;
  return true;
}

// v9.43: stable feed update keeps existing row/group nodes when possible.
// This avoids the full-screen blink that came from replacing the whole feed every refresh.
function refreshMatchFeedOnly(opts = {}) {
  const node = document.getElementById("match-feed");
  if (!node) { render(); return; }

  const active = document.activeElement;
  const inputFocused = active && active.id === "match-search-input";
  const prevHeight = node.offsetHeight;
  if (opts.preserveHeight && prevHeight > 0) {
    node.style.minHeight = `${prevHeight}px`;
    node.classList.add("feed-soft-refresh");
  }

  const nextHTML = renderMatchFeedInner();
  const changed = patchMatchFeedDom(node, nextHTML);
  if (changed) bindMatchHandlers();

  if (inputFocused) {
    const input = document.getElementById("match-search-input");
    if (input) {
      input.focus({ preventScroll: true });
      const len = input.value.length;
      try { input.setSelectionRange(len, len); } catch (_) {}
    }
  }

  // Also refresh the clear-button visibility next to the input without rebuilding the topbar.
  const clearBtn = document.querySelector(".search-clear");
  const wantBtn = !!String(state.search || "").trim();
  if (wantBtn && !clearBtn) {
    const row = document.querySelector(".search-row");
    if (row) {
      const b = document.createElement("button");
      b.className = "search-clear";
      b.setAttribute("aria-label", "Очистить");
      b.textContent = "×";
      b.onclick = () => clearSearch();
      row.appendChild(b);
    }
  } else if (!wantBtn && clearBtn) {
    clearBtn.remove();
  }

  if (opts.preserveHeight) {
    requestAnimationFrame(() => {
      node.classList.remove("feed-soft-refresh");
      node.style.minHeight = "";
    });
  }
}

function refreshMatchesScreenOnly(opts = {}) {
  const total = state.live ? safeInt(state.live.total, flattenLive(state.live).length) : 0;
  const count = document.querySelector(".topbar .live-count");
  const countText = `· ${total} матчей`;
  if (count && count.textContent !== countText) count.textContent = countText;

  const tabs = document.querySelector(".main-feed-tabs");
  if (tabs) replaceOuterIfChanged(tabs, renderMainFeedTabs());

  const strip = document.getElementById("goal-wait-notify-strip");
  const stripHtml = renderGoalWaitNotifyStrip();
  if (strip && !sameHtml(strip.innerHTML, stripHtml)) strip.innerHTML = stripHtml;

  refreshMatchFeedOnly(opts);

  const nav = document.querySelector(".bottom-nav");
  if (nav) replaceOuterIfChanged(nav, renderBottomNav("matches"));
}

function setMainTab(tab) {
  state.mainTab = tab === "goal_wait" ? "goal_wait" : "all";
  const strip = document.getElementById("goal-wait-notify-strip");
  if (strip) strip.innerHTML = renderGoalWaitNotifyStrip();
  refreshMatchFeedOnly();
  const tabs = document.querySelectorAll(".main-feed-tab");
  tabs.forEach(btn => btn.classList.toggle("active", btn.dataset.tab === state.mainTab));
}

function renderMainFeedTabs() {
  const goalCount = flattenLive(state.live).filter(m => !!goalWaitSignal(m)).length;
  return `<div class="main-feed-tabs">
    <button class="main-feed-tab ${state.mainTab === "all" ? "active" : ""}" data-tab="all" onclick="setMainTab('all')">Все</button>
    <button class="main-feed-tab ${state.mainTab === "goal_wait" ? "active" : ""}" data-tab="goal_wait" onclick="setMainTab('goal_wait')">Ждём гол${goalCount ? ` <span>${goalCount}</span>` : ""}</button>
  </div>`;
}

function renderGoalWaitNotifyStrip() {
  if (state.mainTab !== "goal_wait") return "";
  const enabled = isGoalWaitPushEnabled();
  const viaFilter = getNotifyEnabled() && !getGoalWaitNotifyEnabled();
  const autoGoal = getGoalWaitAutoGoalEnabled();
  return `<div class="goal-wait-notify-strip multi">
    <div class="goal-wait-notify-row">
      <div>
        <b>Уведомления</b>
        <span>${enabled ? (viaFilter ? "включены через фильтр" : "включены") : "выключены"}</span>
      </div>
      <button class="goal-wait-notify-btn ${enabled ? "on" : ""}" onclick="toggleGoalWaitNotifyEnabled()">${enabled ? "ON" : "OFF"}</button>
    </div>
    <div class="goal-wait-notify-row secondary">
      <div>
        <b>Гол после найденного матча</b>
        <span>${autoGoal ? "бот пришлёт гол по матчу из Ждём гол" : "авто-голы выключены"}</span>
      </div>
      <button class="goal-wait-notify-btn ${autoGoal ? "on" : ""}" onclick="toggleGoalWaitAutoGoalEnabled()">${autoGoal ? "ON" : "OFF"}</button>
    </div>
  </div>`;
}

function renderTopbar(total) {
  const q = esc(state.search || "");
  const hasQ = !!String(state.search || "").trim();
  return `
    <div class="topbar">
      <div class="topbar-row">
        <div class="live-status">
          <div class="live-dot"></div>
          <span class="live-label">LIVE</span>
        </div>
        <span class="live-count">· ${total} матчей</span>
        <div class="topbar-actions">
          <button class="icon-btn" onclick="loadLive(true)" title="Обновить">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
              <path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/>
            </svg>
          </button>
          <button class="icon-btn accent" onclick="openSheet('filters')" title="Фильтры">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="4" y1="6" x2="20" y2="6"/><line x1="7" y1="12" x2="17" y2="12"/><line x1="10" y1="18" x2="14" y2="18"/>
            </svg>
          </button>
          <button class="icon-btn accent info" onclick="showMainFeedInfo()" title="Подсветка и свайпы">
            <span class="icon-btn-mark">!</span>
          </button>
        </div>
      </div>
      ${renderMainFeedTabs()}
      <div class="search-row">
        <span class="search-icon" aria-hidden="true">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
        </span>
        <input
          type="text"
          inputmode="search"
          autocomplete="off"
          autocorrect="off"
          spellcheck="false"
          class="search-input"
          id="match-search-input"
          placeholder="Поиск команды, лиги, страны…"
          value="${q}"
          oninput="onSearchInput(this.value)"
        />
        ${hasQ ? `<button class="search-clear" onclick="clearSearch()" aria-label="Очистить">×</button>` : ""}
      </div>
    </div>
  `;
}

function leagueHeaderIcon(g) {
  if (isInternationalClubFriendly(g)) return internationalFriendlyLeagueIcon(g);
  const multi = multiLeagueFlag(g);
  if (multi) return multi;
  const code = String(g?.country_code || "").trim() || inferCountryCodeFromText(g?.country, g?.league);
  return flagSvg(code, g?.country || g?.league || "");
}

function renderEmpty() {
  return `
    <div class="empty">
      <div class="empty-icon">•</div>
      <div>Нет матчей под этот фильтр</div>
      <div style="font-size: 10px; color: var(--text-faint); margin-top: 8px;">
        Попробуйте сбросить фильтры или подождать обновления.
      </div>
    </div>
  `;
}

function leagueGroupKey(g) {
  return `${g?.country || ""}||${g?.league || ""}`;
}

function renderLeagueGroup(g) {
  return `
    <div class="league-group ${g.has_stats ? "has-live-stats" : "no-live-stats"} ${isInternationalClubFriendly(g) ? "international-friendly" : ""}" data-league-key="${esc(leagueGroupKey(g))}">
      <div class="league-header">
        <div class="league-flag">${leagueHeaderIcon(g)}</div>
        <div class="league-text">
          <div class="league-country">${esc(g.country)}</div>
          <div class="league-name">${esc(g.league)}</div>
        </div>
        <div class="league-count">${g.matches.length}</div>
      </div>
      ${g.matches.map(renderMatchRow).join("")}
    </div>
  `;
}

function renderNotifyReasonBlock(m) {
  const score = safeInt(m?.alert_score || m?.filter_score, 0);
  const reasons = normalizeAlertReasons(m?.alert_reasons || m?.alert_reason || m?.filter_reasons || m?.filter_reason || []);
  if (!score && !reasons.length) return "";
  const kind = String(m?.alert_kind || "").toLowerCase();
  const label = kind === "goal_wait" ? "Ждём гол" : kind === "goal" ? "Гол" : "Фильтр";
  const tone = score >= 85 ? "hot" : score >= 70 ? "good" : "ok";
  const reasonText = reasons.slice(0, 5).join(" · ");
  return `<div class="match-alert-analysis ${tone}" title="${esc(reasonText)}">
    ${score ? `<span class="match-alert-score"><b>${score}</b>/100</span>` : ""}
    <span class="match-alert-label">${esc(label)}</span>
    ${reasonText ? `<span class="match-alert-reason">Причина: ${esc(reasonText)}</span>` : ""}
  </div>`;
}

function buildAvgDataFromMatch(match) {
  const m = match || {};
  const homeAvg = Number(m?.home_total_avg ?? m?.home_avg_total ?? m?.home_avg_goals ?? m?.home_avg ?? m?.avg_total_home);
  const awayAvg = Number(m?.away_total_avg ?? m?.away_avg_total ?? m?.away_avg_goals ?? m?.away_avg ?? m?.avg_total_away);
  const avgData = {};
  if (Number.isFinite(homeAvg) && homeAvg > 0) avgData.home = { total_avg: homeAvg };
  if (Number.isFinite(awayAvg) && awayAvg > 0) avgData.away = { total_avg: awayAvg };
  return Object.keys(avgData).length ? avgData : null;
}

function matchHeatTone(match) {
  const m = match || {};
  const stats = (m && typeof m.stats === "object" && m.stats) ? m.stats : m;
  const pulse = computeMatchPulse(m, stats, buildAvgDataFromMatch(m));
  const score = safeInt(pulse?.score, 0);
  const minute = safeInt(m.minute, 0);
  if (score >= 92) return { cls: "heat-max", score };
  if (score >= 50 && minute >= 60) return { cls: "heat-blue", score };
  return { cls: "", score };
}

function renderMatchRow(m) {
  const fav = isFav(m.id);
  const minuteText = m.minute_text || (m.minute ? `${m.minute}'` : "LIVE");
  const minute = safeInt(m.minute, 0);
  const isHT = (m.period === "HT") || /HT|перерыв/i.test(minuteText);
  const isFinished = m.finished === true;  // v6
  const sh = safeInt(m.score_home);
  const sa = safeInt(m.score_away);
  const heat = matchHeatTone(m);
  // v6: finished favorites show a muted "ЗАВЕРШ" badge instead of a live minute.
  const oddsBadge = "";
  const minuteCell = isFinished
    ? `<div class="match-minute finished">ЗАВЕРШ${oddsBadge}</div>`
    : `<div class="match-minute ${isHT ? "ht" : ""}">${esc(minuteText)}${oddsBadge}</div>`;
  const alertBlock = renderNotifyReasonBlock(m);
  return `
    <div class="match-row${isFinished ? " finished" : ""}${matchHasOdds(m) ? " has-odds" : ""}${heat.cls ? ` ${heat.cls}` : ""}" data-id="${esc(m.id)}" data-heat-score="${heat.score}">
      <span class="match-heat-edge" aria-hidden="true"></span>
      ${minuteCell}
      <div class="match-teams">
        <div class="match-team-line">${teamLogoSmall(m, "home")}<div class="match-team">${esc(m.home)}</div></div>
        <div class="match-team-line">${teamLogoSmall(m, "away")}<div class="match-team">${esc(m.away)}</div></div>
        ${alertBlock || renderGoalWaitBadge(m)}
      </div>
      <div class="match-score">
        <div class="match-score-row ${sh > 0 ? "scored" : ""}">${sh}</div>
        <div class="match-score-row ${sa > 0 ? "scored" : ""}">${sa}</div>
      </div>
      <button class="star-btn ${fav ? "active" : ""}" data-fav="${esc(m.id)}" title="${fav ? "Убрать" : "В избранное"}">
        ${fav ? "★" : "☆"}
      </button>
    </div>
  `;
}

function bindMatchHandlers() {
  for (const el of document.querySelectorAll(".match-row")) {
    if (el.__boundRow) continue;
    el.__boundRow = true;
    el.addEventListener("click", (e) => {
      if (e.target.closest("[data-fav]")) return;
      const id = el.dataset.id;
      saveMatchListPosition(id);
      captureDetailNavFromScreen(id);
      loadDetail(id, { keepNav: true });
    });
  }
  for (const btn of document.querySelectorAll("[data-fav]")) {
    if (btn.__boundFav) continue;
    btn.__boundFav = true;
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleFavWithGoalPrompt(btn.dataset.fav);
    });
  }
}

// ----------------------------------------
//  Bottom nav
// ----------------------------------------
function renderBottomNav(active) {
  const icons = {
    matches: `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="m12 7 3 2.2-1.1 3.5h-3.8L9 9.2 12 7Z"/><path d="m7.1 11.2-2.3 1.5M16.9 11.2l2.3 1.5M9.1 16.1l-1 2.4M14.9 16.1l1 2.4"/></svg>`,
    favorites: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3.8 2.5 5.1 5.6.8-4 4 1 5.5-5.1-2.7-5.1 2.7 1-5.5-4-4 5.6-.8L12 3.8Z"/></svg>`,
    notify: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 7h18s-3 0-3-7"/><path d="M10 20h4"/></svg>`,
  };
  const tab = (id, label) => {
    const isActive = active === id;
    const badge = id === "notify" && state.unreadAlerts > 0
      ? `<span class="nav-badge">${state.unreadAlerts}</span>`
      : "";
    return `
      <button class="nav-tab ${isActive ? "active" : ""}" onclick="switchView('${id}')">
        <span class="nav-icon">${icons[id] || ""}</span>
        <span class="nav-label">${label}</span>
        ${badge}
      </button>
    `;
  };
  return `
    <div class="bottom-nav">
      ${tab("matches", "Матчи")}
      ${tab("favorites", "Избранное")}
      ${tab("notify", "Уведомления")}
    </div>
  `;
}

function switchView(v) {
  if (v !== "detail") setLastOpenedMode(v);
  state.view = v;
  if (v === "notify") {
    state.unreadAlerts = 0;
    loadNotifyMatches(false);
  }
  render();
}

// ----------------------------------------
//  Favorites screen
// ----------------------------------------
function renderFavorites() {
  const fav = getFavs();
  // v6: merge live matches with cached snapshots so finished favorites still
  // show up here. Live data wins; cache fills the gap for finished matches.
  const liveById = currentLiveById();
  const merged = [];
  for (const k of fav) {
    const key = String(k);
    const card = resolveMatchCardData({ id: key }, liveById);
    if (card && (card.home || card.away || card.league)) merged.push(card);
    // If neither live nor cached — silently skip (no data anywhere).
  }
  // Sort: live first, then by cached_at desc (most recently finished on top).
  merged.sort((a, b) => {
    if (a.is_live !== b.is_live) return a.is_live ? -1 : 1;
    return (b.cached_at || 0) - (a.cached_at || 0);
  });
  const groups = groupByLeague(merged);
  app.innerHTML = `
    <div class="topbar">
      <div class="topbar-row">
        <div class="live-status">
          <div class="live-dot"></div>
          <span class="live-label">ИЗБРАННОЕ</span>
        </div>
        <span class="live-count">· ${merged.length}</span>
      </div>
    </div>
    ${merged.length === 0 ? renderFavEmpty() : groups.map(renderLeagueGroup).join("")}
    ${renderSportScoreAttribution()}
    ${renderBottomNav("favorites")}
  `;
  bindMatchHandlers();
  refreshFavoriteSnapshotsFromBackend(merged);
}

function renderFavEmpty() {
  return `
    <div class="fav-empty">
      <div class="fav-empty-icon">☆</div>
      <div class="fav-empty-title">Пока нет избранных матчей</div>
      <div class="fav-empty-text">Откройте любой матч в списке и нажмите ★, чтобы добавить сюда. После окончания матча карточка останется в избранном.</div>
    </div>
  `;
}

// ----------------------------------------
//  Notify (alerts) screen
// ----------------------------------------
function renderNotify() {
  const cfg = getNotifyFilter();
  const enabled = cfg.enabled;
  const found = state.notifyMatches || [];
  const localOnly = state.inAppAlerts || [];
  const shown = found.length ? found : localOnly;
  const isFilter = state.notifyTab === "filter";
  app.innerHTML = `
    <div class="topbar">
      <div class="topbar-row">
        <div class="live-status">
          <div class="live-dot" style="background:${enabled ? "var(--green)" : "#4b5563"};box-shadow:none;animation:none;"></div>
          <span class="live-label" style="color:${enabled ? "var(--green)" : "var(--text-muted)"}">УВЕДОМЛЕНИЯ</span>
        </div>
        <span class="live-count">· ${enabled ? "включены" : "выключены"}</span>
        <div class="topbar-actions">
          <button class="icon-btn" onclick="loadNotifyMatches(true)" title="Обновить">↻</button>
        </div>
      </div>
      <div class="notify-tabs">
        <button class="notify-tab ${!isFilter ? "active" : ""}" onclick="setNotifyTab('found')">Найденные</button>
        <button class="notify-tab ${isFilter ? "active" : ""}" onclick="setNotifyTab('filter')">Фильтр уведомлений</button>
      </div>
    </div>

    ${isFilter ? renderNotifyFilterPanel(cfg, enabled) : renderNotifyFoundPanel(shown, found.length)}
    ${renderSportScoreAttribution()}
    ${renderBottomNav("notify")}
    ${renderSheet()}
  `;
  bindMatchHandlers();
  if (!isFilter && shown.length) {
    refreshFavoriteSnapshotsFromBackend(resolveMatchCardList(shown.map(renderAlert)));
  }
}

function renderNotifyFilterPanel(cfg, enabled) {
  return `
    <div class="section-card">
      <div class="toggle-row">
        <div>
          <div class="label">Слать уведомления, когда матч подходит под фильтр</div>
          <div class="hint">В Telegram придёт “Матч нашёлся…” и сила матча /100. Если потом будет гол — придёт отдельное уведомление о голе.</div>
        </div>
        <div class="switch ${enabled ? "on" : ""}" onclick="toggleNotifyEnabled()"></div>
      </div>
    </div>

    <div class="section-card">
      <div class="toggle-row">
        <div>
          <div class="label">Звук в приложении при найденном матче</div>
          <div class="hint">Короткий сигнал сработает в открытом Mini App. Обычно нужен первый тап по экрану, чтобы Telegram разрешил звук.</div>
        </div>
        <div class="switch ${getAlertSoundEnabled() ? "on" : ""}" onclick="toggleAlertSound()"></div>
      </div>
    </div>

    ${tg?.initData ? "" : `
      <div class="notify-status warn">
        ⚠ Открой приложение из Telegram-бота, чтобы push-уведомления приходили в Telegram.
      </div>
    `}

    <div class="section-card notify-profiles-card">
      <div class="label">Профили фильтра</div>
      <div class="hint">Сохранение автоматически включает выбранный профиль. При переключении уведомления остаются включёнными.</div>
      ${renderNotifyProfileSwitch("panel")}
    </div>

    <div class="section-card notify-filter-summary">
      <div class="page-title" style="margin:0 0 8px;">Текущий фильтр <span class="notify-active-profile-badge">Профиль ${esc(getActiveNotifyProfile())} · ${enabled ? "ON" : "OFF"}</span></div>
      <div class="filter-summary-grid">
        <div><span>Минута</span><b>${safeInt(cfg.minute_min)}–${safeInt(cfg.minute_max)}</b></div>
        <div><span>Счёт</span><b>${(cfg.scores || []).length ? esc((cfg.scores || []).join(", ")) : "любой"}</b></div>
        <div><span>Удары</span><b>${safeInt(cfg.shots_min)}</b></div>
        <div><span>В створ</span><b>${safeInt(cfg.on_target_min)}</b></div>
        <div><span>Опасные атаки</span><b>${safeInt(cfg.dangerous_min)}</b></div>
        <div><span>Атаки</span><b>${safeInt(cfg.attacks_min)}</b></div>
      </div>
      <button class="btn primary full-btn" onclick="openSheet('notify-edit')">Настроить фильтр</button>
      <button class="btn secondary full-btn notify-test-btn" onclick="testTelegramNotification()">Проверить Telegram-уведомление</button>
    </div>
  `;
}

function renderNotifyFoundPanel(items, serverCount) {
  // Keep notified matches visible until manual remove/clear; live data is merged when available.
  const matchObjects = resolveNotifyVisibleCards((items || []).map(renderAlert));
  const total = matchObjects.length || 0;
  const groups = groupByLeague(matchObjects);
  return `
    <div class="page-title">Найденные матчи</div>
    <div class="page-subtitle">${state.notifyMatchesLoading ? "загрузка…" : total + " матчей · хранятся до ручной очистки"}</div>
    <div class="actions-row notify-actions">
      <button class="action-btn" onclick="loadNotifyMatches(true)">↻ Обновить</button>
      <button class="action-btn" onclick="clearNotifyMatches()">Очистить</button>
    </div>
    ${total === 0 ? `
      <div class="fav-empty">
        <div class="fav-empty-icon">🔔</div>
        <div class="fav-empty-title">Пока нет найденных матчей</div>
        <div class="fav-empty-text">Когда матч подойдёт под твой фильтр, он сохранится здесь. В Telegram придёт короткое сообщение.</div>
      </div>
    ` : groups.map(renderLeagueGroup).join("")}
  `;
}

function renderAlert(a) {
  // v8: normalise alert object to look like a match for renderLeagueGroup/renderMatchRow
  const id = String(a.id || a.match_id || "");
  const home = a.home || (a.alert_title ? a.alert_title.split(" — ")[0] : "Хозяева");
  const away = a.away || (a.alert_title ? a.alert_title.split(" — ")[1] : "Гости");
  const ts = safeInt(a.found_at || (a.ts ? Math.floor(a.ts / 1000) : 0), 0);
  const tm = ts ? new Date(ts * 1000) : new Date();
  const timeStr = String(tm.getHours()).padStart(2,"0") + ":" + String(tm.getMinutes()).padStart(2,"0");
  return {
    id,
    home,
    away,
    home_logo: a.home_logo || "",
    away_logo: a.away_logo || "",
    score_home: safeInt(a.score_home, 0),
    score_away: safeInt(a.score_away, 0),
    minute: safeInt(a.minute, 0),
    minute_text: (a.minute_text || (a.minute ? `${a.minute}'` : "")) + (ts ? `  ${timeStr}` : ""),
    country: a.country || "",
    country_code: a.country_code || "",
    league: a.league || "",
    period: a.period || "LIVE",
    finished: Boolean(a.finished),
    stats: a.stats || {},
    prematch_odds: a.prematch_odds || {},
    live_odds: a.live_odds || a.odds || {},
    odds_movement: a.odds_movement || {},
    odds_filter_market: a.odds_filter_market || "",
    odds_filter_snapshot: a.odds_filter_snapshot || {},
    alert_kind: a.alert_kind || "",
    alert_title: a.alert_title || "",
    alert_subtitle: a.alert_subtitle || "",
    alert_score: safeInt(a.alert_score || a.filter_score, 0),
    alert_reasons: normalizeAlertReasons(a.alert_reasons || a.alert_reason || a.filter_reasons || a.filter_reason || []),
    alert_reason: String(a.alert_reason || a.filter_reason || ""),
    found_at: ts,
  };
}

function setNotifyTab(tab) {
  state.notifyTab = tab === "filter" ? "filter" : "found";
  if (state.notifyTab === "found") loadNotifyMatches(false);
  render();
}

function toggleNotifyEnabled() {
  const current = getNotifyFilter();
  const cfg = setOnlyNotifyProfileEnabled(getActiveNotifyProfile(), !current.enabled);
  // Sync enabled/disabled state with server. Enabling this profile turns off the other profiles.
  syncNotifyFilterToServer(cfg, { keepalive: true, warn: true });
  if (cfg.enabled) {
    checkNotifyMatches();
    checkGoalWaitNotifyMatches();
  }
  render();
}

// ----------------------------------------
//  Detail screen
// ----------------------------------------
function recentRowTeamScores(row) {
  const side = String(row?.side || "");
  const home = safeInt(row?.score_home);
  const away = safeInt(row?.score_away);
  return side === "away" ? {gf: away, ga: home, total: home + away} : {gf: home, ga: away, total: home + away};
}

function trendStreak(rows, predicate) {
  let count = 0;
  for (const row of rows || []) {
    if (!predicate(row)) break;
    count += 1;
  }
  return count;
}

function buildTeamTrends(data, side, match) {
  const rows = Array.isArray(data?.matches) ? data.matches.slice(0, 10) : [];
  if (!rows.length) return [];
  const teamName = side === "away" ? match?.away : match?.home;
  const logo = side === "away" ? match?.away_logo : match?.home_logo;
  const trends = [];
  const addStreak = (label, fn, minimum = 2) => {
    const value = trendStreak(rows, fn);
    if (value >= minimum) trends.push({teamName, logo, label, value: String(value), score: value * 10});
  };
  addStreak("Без поражений", row => String(row?.result || "").toUpperCase() !== "L");
  addStreak("Без побед", row => String(row?.result || "").toUpperCase() !== "W");
  addStreak("Не пропускает", row => recentRowTeamScores(row).ga === 0);
  addStreak("Не забивает", row => recentRowTeamScores(row).gf === 0);
  addStreak("Забивает в каждом матче", row => recentRowTeamScores(row).gf > 0, 3);

  const sample = rows.slice(0, 8);
  const addFrequency = (label, fn, minimum = 4) => {
    const hits = sample.filter(fn).length;
    if (hits >= minimum) trends.push({teamName, logo, label, value: `${hits}/${sample.length}`, score: hits});
  };
  addFrequency("Более 2.5 голов", row => recentRowTeamScores(row).total >= 3);
  addFrequency("Менее 2.5 голов", row => recentRowTeamScores(row).total <= 2);
  addFrequency("Обе команды забивали", row => {
    const s = recentRowTeamScores(row);
    return s.gf > 0 && s.ga > 0;
  });
  addFrequency("Сухой матч", row => recentRowTeamScores(row).ga === 0, 3);
  return trends;
}

function renderTrendLogo(item) {
  const logo = String(item?.logo || "").trim();
  const name = String(item?.teamName || "Команда");
  return `<span class="match-trend-logo ${logo ? "" : "logo-error"}">${logo ? `<img src="${esc(logo)}" alt="" loading="lazy" onerror="this.parentElement.classList.add('logo-error')" />` : ""}<i>${esc(initials(name))}</i></span>`;
}

function renderDetailTrendsContent(d) {
  const m = d?.match || state.detail?.match || {};
  const avg = state.avgTotalData || d?.avg || {};
  const trends = [
    ...buildTeamTrends(avg?.home || {}, "home", m),
    ...buildTeamTrends(avg?.away || {}, "away", m),
  ].sort((a,b) => Number(b.score || 0) - Number(a.score || 0)).slice(0, 12);
  return `<div class="match-trends-card"><div class="match-trends-head"><div><span>ФОРМА КОМАНД</span><h3>Тренды последних матчей</h3></div><em>до 10 игр</em></div><div class="match-trends-list">${trends.length ? trends.map(item => `<div class="match-trend-row">${renderTrendLogo(item)}<div><b>${esc(item.label)}</b><span>${esc(item.teamName || "")}</span></div><strong>${esc(item.value)}</strong></div>`).join("") : `<div class="detail-tab-empty"><b>Тренды пока недоступны</b><span>SportScore ещё не передал историю последних матчей.</span></div>`}</div></div>`;
}

function renderLiveMatchStandings(d) {
  const rows = Array.isArray(d?.standings) ? d.standings : [];
  const m = d?.match || {};
  const compPath = String(m?.competition_path || "");
  const teamCell = row => {
    const name = String(row?.team || "Команда");
    const slug = String(row?.team_slug || "");
    const logo = String(row?.logo || "");
    const inner = `${logo ? `<span class="live-standings-logo"><img src="${esc(logo)}" alt="" loading="lazy" onerror="this.parentElement.classList.add('logo-error')" /></span>` : ""}<span>${esc(name)}</span>`;
    return slug ? `<button type="button" class="live-standings-team" onclick="return openTeamFromInternal(decodeURIComponent('${encodeURIComponent(slug)}'),decodeURIComponent('${encodeURIComponent(name)}'),decodeURIComponent('${encodeURIComponent(compPath)}'),event,'football')">${inner}</button>` : `<div class="live-standings-team">${inner}</div>`;
  };
  return `<section class="live-match-standings"><div class="live-standings-title"><span>STANDINGS</span><h3>Турнирная таблица</h3></div>${rows.length ? `<div class="live-standings-table-wrap"><table class="live-standings-table"><thead><tr><th>#</th><th class="team-col">КОМАНДА</th><th>И</th><th>В</th><th>Н</th><th>П</th><th>РМ</th><th>О</th></tr></thead><tbody>${rows.map(row => `<tr class="${row?.is_home ? "current-home" : row?.is_away ? "current-away" : ""}"><td class="rank-col">${safeInt(row?.position)}</td><td class="team-col">${teamCell(row)}</td><td>${safeInt(row?.played)}</td><td>${safeInt(row?.wins)}</td><td>${safeInt(row?.draws)}</td><td>${safeInt(row?.losses)}</td><td class="gd-col">${esc(row?.goal_difference ?? '—')}</td><td class="pts-col"><b>${safeInt(row?.points)}</b></td></tr>`).join("")}</tbody></table></div>` : `<div class="live-standings-empty">Таблица этой лиги пока не передана SportScore.</div>`}</section>`;
}

function renderDetail() {
  if (!state.detail) {
    app.innerHTML = `
      <div class="detail-screen">
        <div class="detail-topbar">
          <button class="back-btn" onclick="goBack()">‹</button>
          <div class="detail-breadcrumb">Загрузка…</div>
        </div>
        ${renderDetailSwipeHud()}
        <div class="loading"><div class="spinner"></div>Грузим матч…</div>
        ${renderDetailToast()}
      </div>
    `;
    bindDetailSwipeHandlers();
    return;
  }
  const d = state.detail;
  const m = d.match || {};
  const s = d.stats || {};
  const avg = d.avg || {};
  const fav = isFav(m.id);
  const activeTab = ["stats", "matches", "trends", "table"].includes(state.detailTab) ? state.detailTab : "details";

  app.innerHTML = `
    <div class="detail-screen">
      <div class="detail-topbar">
        <button class="back-btn" onclick="goBack()">‹</button>
        <div class="detail-breadcrumb">${leagueHeaderIcon({country_code: m.country_code, country: m.country, league: m.league})} ${esc(m.country)} · ${esc(m.league)}</div>
        <button class="star-btn ${fav ? "active" : ""}" onclick="toggleFavWithGoalPrompt('${esc(m.id)}')">${fav ? "★" : "☆"}</button>
      </div>

      ${renderDetailSwipeHud()}

      <div class="scoreboard">
        <div class="scoreboard-grid">
          <div class="scoreboard-team">
            ${teamBadge(m, "home")}
            <div class="team-name-big">${esc(m.home)}</div>
          </div>
          <div class="scoreboard-center">
            <div class="big-score">${safeInt(m.score_home)} : ${safeInt(m.score_away)}</div>
            <div class="live-pill${d.finished ? " finished" : ""}">
              <div class="live-dot"></div>
              ${d.finished ? "ЗАВЕРШЁН" : esc(m.minute_text || (m.minute ? `${m.minute}'` : "LIVE"))}
            </div>
          </div>
          <div class="scoreboard-team">
            ${teamBadge(m, "away")}
            <div class="team-name-big">${esc(m.away)}</div>
          </div>
        </div>
      </div>

      ${renderDetailTabs(activeTab)}
      <div class="detail-tab-content">
        ${activeTab === "stats" ? renderDetailStatsContent(d, s, avg) : (activeTab === "matches" ? renderDetailMatchesContent(d, avg) : (activeTab === "trends" ? renderDetailTrendsContent(d) : (activeTab === "table" ? renderDetailTableContent(d) : renderDetailDetailsContent(d, m, s))))}
      </div>
      ${renderDetailToast()}
    </div>
  `;
  bindDetailSwipeHandlers();

  if (activeTab === "stats" || activeTab === "matches" || activeTab === "trends") ensureAvgTotalLoaded();
}

function renderDetailTabs(activeTab) {
  return `<div class="detail-tabs five-tabs">
    <button type="button" class="tab-btn ${activeTab === "details" ? "active" : ""}" onclick="setDetailTab('details')">Детали</button>
    <button type="button" class="tab-btn ${activeTab === "stats" ? "active" : ""}" onclick="setDetailTab('stats')">Статистика</button>
    <button type="button" class="tab-btn ${activeTab === "matches" ? "active" : ""}" onclick="setDetailTab('matches')">Матчи</button>
    <button type="button" class="tab-btn ${activeTab === "trends" ? "active" : ""}" onclick="setDetailTab('trends')">Тренды</button>
    <button type="button" class="tab-btn ${activeTab === "table" ? "active" : ""}" onclick="setDetailTab('table')">Таблица</button>
  </div>`;
}

function renderDetailTableContent(d) {
  return `<div class="standings-tab-wrap">${renderLiveMatchStandings(d)}</div>`;
}

function renderDetailDetailsContent(d, m, s) {
  const oddsHtml = renderOddsSection(d.odds || {}, d.prematch_odds || {}, d.odds_movement || {}, !!m.is_live) || `<div class="detail-tab-empty">КФ пока нет.</div>`;
  return `
    ${oddsHtml}
    ${renderPressureChartFull(d)}
    ${renderMatchEvents(d.events || [], m)}
    ${renderLiveLineups(d, m)}
    ${renderMatchAbsences(d, m)}
    ${renderGoalWaitDetailSignal(m, s)}
  `;
}

function renderDetailStatsContent(d, s, avg) {
  return `
    ${renderLiveStatsTab(s, d.match || {}, state.avgTotalData || avg || {})}
    ${renderPressureSection(d.pressure || {})}
    ${renderAvgTotalPanel(avg)}
  `;
}

function resultLabelRu(code) {
  if (code === "W") return "Победа";
  if (code === "D") return "Ничья";
  if (code === "L") return "Поражение";
  return "—";
}

function shortResultRu(code) {
  if (code === "W") return "W";
  if (code === "D") return "D";
  if (code === "L") return "L";
  return "—";
}

function recentMatchSideText(side) {
  if (side === "home") return "Дома";
  if (side === "away") return "В гостях";
  return "";
}

function renderRecentTeamLogo(item, side) {
  const name = String(item?.[side] || "Команда");
  const logo = String(item?.[`${side}_logo`] || "").trim();
  return `<span class="recent-team-logo ${logo ? "" : "logo-error"}">${logo ? `<img src="${esc(logo)}" alt="" loading="lazy" onerror="this.parentElement.classList.add('logo-error')" />` : ""}<i>${esc(initials(name))}</i></span>`;
}

function renderRecentTeamEntry(item, side) {
  const name = String(item?.[side] || (side === "home" ? "Хозяева" : "Гости"));
  const teamSide = String(item?.side || "");
  const selected = teamSide === side ? " selected" : "";
  const id = String(item?.[`${side}_id`] || "");
  const score = safeInt(item?.[`score_${side}`]);
  const sport = String(item?.sport || state.detail?.match?.sport || state.sport || "football");
  const compPath = String(item?.competition_path || "");
  const nameHtml = id
    ? `<button type="button" class="recent-team-name-btn" onclick="return openTeamFromInternal(decodeURIComponent('${encodeURIComponent(id)}'),decodeURIComponent('${encodeURIComponent(name)}'),decodeURIComponent('${encodeURIComponent(compPath)}'),event,decodeURIComponent('${encodeURIComponent(sport)}'))">${esc(name)}</button>`
    : `<span>${esc(name)}</span>`;
  return `<div class="recent-list-team modern${selected}">${renderRecentTeamLogo(item, side)}<div class="recent-team-name-wrap">${nameHtml}${selected ? `<small>Выбранная команда</small>` : ""}</div><strong>${score}</strong></div>`;
}

function renderRecentListRow(item) {
  const result = String(item?.result || "").toUpperCase();
  const cls = result === "W" ? "win" : result === "D" ? "draw" : result === "L" ? "loss" : "";
  const date = item?.date || item?.date_text || "—";
  const league = typeof item?.league === "string" ? item.league : (item?.league?.name || item?.league?.title || "");
  const venue = recentMatchSideText(item?.side || "");
  const hs = safeInt(item?.score_home);
  const as = safeInt(item?.score_away);
  const total = item?.total === null || item?.total === undefined ? (hs + as) : safeInt(item.total);
  return `<div class="recent-list-row modern ${cls}">
    <div class="recent-match-topline">
      <span class="recent-match-date">${esc(date)}</span>
      ${league ? `<span class="recent-match-league">${esc(league)}</span>` : `<span></span>`}
      <span class="recent-match-result ${cls}">${esc(resultLabelRu(result))}</span>
    </div>
    <div class="recent-match-scoreboard">
      ${renderRecentTeamEntry(item, "home")}
      ${renderRecentTeamEntry(item, "away")}
    </div>
    <div class="recent-match-footer">
      <span>${esc(venue || "Матч")}</span>
      <span>Итог ${hs}:${as}</span>
      <span>Тотал ${total}</span>
    </div>
  </div>`;
}

function renderRecentTeamPanel(title, data, side, sport = "football") {
  const matches = Array.isArray(data?.matches) ? data.matches.slice(0, 10) : [];
  const count = safeInt(data?.count || matches.length);
  const avgTotal = avgDisplay(data?.total_avg ?? data?.avg);
  const scoredAvg = avgDisplay(data?.scored_avg);
  const concededAvg = avgDisplay(data?.conceded_avg);
  const wins = safeInt(data?.wins);
  const draws = safeInt(data?.draws);
  const losses = safeInt(data?.losses);
  const basketball = sport === "basketball";
  const tennis = sport === "tennis";
  const scoredLabel = basketball ? "Набирают" : tennis ? "Выигр. геймов" : "Забивают";
  const concededLabel = basketball ? "Пропускают" : tennis ? "Проигр. геймов" : "Пропускают";
  const record = basketball || tennis
    ? `<span>В ${wins}</span><span>П ${losses}</span><span>Побед ${teamPercent(data?.win_percent)}</span>`
    : `<span>В ${wins}</span><span>Н ${draws}</span><span>П ${losses}</span>`;

  return `<div class="recent-list-card ${side}">
    <div class="recent-list-summary recent-list-summary-top no-team-name">
      <div class="recent-list-team-head">
        <div class="recent-list-sub recent-list-sub-only">Последние ${count || 10} матчей</div>
      </div>
      <div class="recent-top-metrics recent-top-metrics-reordered">
        <div class="recent-metric"><span>${concededLabel}</span><strong>${concededAvg}</strong></div>
        <div class="recent-metric"><span>${scoredLabel}</span><strong>${scoredAvg}</strong></div>
        <div class="recent-metric main"><span>Средний тотал</span><strong>${avgTotal}</strong></div>
      </div>
    </div>
    <div class="recent-list-mini form-only">${record}</div>
    <div class="recent-list-body">
      ${matches.length ? matches.map(renderRecentListRow).join("") : `<div class="detail-tab-empty recent-empty"><b>История матчей пока не пришла</b><span>Обновите карточку через минуту. SportScore иногда отдаёт сводку раньше списка соперников.</span></div>`}
    </div>
  </div>`;
}

function renderRecentTeamPicker(m, activeSide) {
  const homeName = m.home || "Хозяева";
  const awayName = m.away || "Гости";
  return `<div class="recent-picker-wrap">
    <div class="recent-h2h-pill">
      ${teamLogoSmall(m, "home")}
      <span>ПОСЛЕДНИЕ 10</span>
      ${teamLogoSmall(m, "away")}
    </div>
    <div class="recent-team-switch">
      <button class="recent-team-btn ${activeSide === "home" ? "active" : ""}" title="${esc(homeName)}" aria-label="${esc(homeName)}" onclick="setDetailMatchesSide('home')">${esc(homeName)}</button>
      <button class="recent-team-btn ${activeSide === "away" ? "active" : ""}" title="${esc(awayName)}" aria-label="${esc(awayName)}" onclick="setDetailMatchesSide('away')">${esc(awayName)}</button>
    </div>
  </div>`;
}

function renderDetailMatchesContent(d, avg) {
  const m = state.detail?.match || d?.match || {};
  const currentAvg = state.avgTotalData || avg || {};
  const home = currentAvg.home || {};
  const away = currentAvg.away || {};
  const activeSide = state.detailMatchesSide === "away" ? "away" : "home";
  const data = activeSide === "home" ? home : away;
  const title = activeSide === "home" ? (m.home || "Хозяева") : (m.away || "Гости");
  const sport = String(m?.sport || state.sport || "football");
  return `<div class="matches-tab-section matches-list-mode">
    ${renderRecentTeamPicker(m, activeSide)}
    ${renderRecentTeamPanel(title, data, activeSide, sport)}
  </div>`;
}


// === Pressure charts (Attack-Momentum style) ===
// Two flavours, both reading server-side history that the collector worker
// captures every COLLECTOR_INTERVAL seconds (~60s) for EVERY live match,
// independent of whether the user has the match card open. So a chart for a
// match that has been live for 70 minutes always shows ~70 bars when the user
// first opens it.
//
//   renderPressureChartFull   — whole stored history (from match start)
//   renderPressureChartLast20 — same data, filtered to the last 20 minutes
//
// Both call pressureChartSvg() which renders a 520x96 SVG with home pressure
// going UP from the midline (green) and away pressure going DOWN (blue).
// Time flows left → right (oldest bar on the left, freshest on the right).

function pressureChartSvg(bars, opts) {
  // График в стиле Attack Momentum: 45 минут первого тайма + 45 минут второго.
  // Хозяева рисуются вверх от центральной линии, гости — вниз.
  opts = opts || {};
  const mode = opts.mode || "full";
  const HALF_BINS = 45;
  const TOTAL_BINS = mode === "full" ? HALF_BINS * 2 : 45;

  const VB_W = 520, VB_H = 96, padX = 5, padY = 7;
  const innerW = VB_W - padX * 2;
  const innerH = VB_H - padY * 2;
  const halfH = innerH / 2;
  const midY = padY + halfH;
  const slotW = innerW / TOTAL_BINS;
  const barW = Math.max(1.9, Math.min(slotW * 0.72, slotW - 0.65));
  const xForIndex = (i) => padX + i * slotW + (slotW - barW) / 2;
  const centerXForIndex = (i) => padX + i * slotW + slotW / 2;

  const src = Array.isArray(bars) ? bars.slice() : [];
  const match = opts.match || {};
  const goals = Array.isArray(opts.goals) ? opts.goals : [];
  const minute = safeInt(match.minute, 0);
  const period = String(match.period || "").toUpperCase();
  const isSecondHalfNow = mode === "full" && (period === "2T" || minute > 45);

  function activeBinsForMatch() {
    if (mode !== "full") return TOTAL_BINS;
    if (isSecondHalfNow) {
      const min2 = clamp(minute - 45, 1, HALF_BINS);
      return HALF_BINS + clamp(min2, 1, HALF_BINS);
    }
    return clamp(minute || 1, 1, HALF_BINS);
  }

  function momentumValue(b) {
    const h = Number(b && b.h) || 0;
    const a = Number(b && b.a) || 0;
    if (h <= 0 && a <= 0) return 0;
    if (h === a) return 0;
    return h > a ? h : -a;
  }

  function putStrongest(values, idx, v) {
    if (idx < 0 || idx >= values.length) return;
    const old = values[idx];
    if (old === null || Math.abs(v) >= Math.abs(old)) values[idx] = v;
  }

  function slotFromGoalMinute(rawMinute) {
    const gMin = safeInt(rawMinute, 0);
    if (gMin <= 0) return null;
    if (gMin > 45) return 45 + clamp(gMin - 46, 0, 44);
    return clamp(gMin - 1, 0, 44);
  }

  let values = new Array(TOTAL_BINS).fill(null);
  let slotToIndex = new Map();
  let activeCount = activeBinsForMatch();

  if (mode === "full") {
    for (let i = 0; i < TOTAL_BINS; i++) slotToIndex.set(i, i);
    for (const b of src) {
      // Server returns fixed 90-slot rows. Empty/future rows are layout data,
      // not real pressure samples, so they must not become neutral bars.
      if (b && b.empty === true) continue;
      const rawSlot = Number(b && b.slot);
      if (!Number.isFinite(rawSlot)) continue;
      const slot = clamp(Math.round(rawSlot), 0, TOTAL_BINS - 1);
      putStrongest(values, slot, momentumValue(b));
    }
  } else {
    const sampled = src.filter(b => !(b && b.empty === true));
    const visible = sampled.length > TOTAL_BINS ? sampled.slice(sampled.length - TOTAL_BINS) : sampled;
    visible.forEach((b, i) => {
      const idx = visible.length <= 1 ? TOTAL_BINS - 1 : Math.round((i / (visible.length - 1)) * (TOTAL_BINS - 1));
      const rawSlot = Number(b && b.slot);
      if (Number.isFinite(rawSlot)) slotToIndex.set(clamp(Math.round(rawSlot), 0, 89), idx);
      putStrongest(values, idx, momentumValue(b));
    });
    activeCount = TOTAL_BINS;
  }

  // Пустые активные минуты — это нейтральные отметки, будущие минуты не рисуем.
  for (let i = 0; i < activeCount; i++) {
    if (values[i] === null) values[i] = 0;
  }

  let peak = 0;
  for (const v of values) {
    if (v !== null) peak = Math.max(peak, Math.abs(Number(v) || 0));
  }
  if (peak <= 0) peak = 1;

  let defs = `<defs>
    <linearGradient id="pmHomeGrad" x1="0" y1="1" x2="0" y2="0">
      <stop offset="0%" stop-color="rgba(41,231,139,0.58)"/>
      <stop offset="100%" stop-color="rgba(41,231,139,1)"/>
    </linearGradient>
    <linearGradient id="pmAwayGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="rgba(118,139,255,0.58)"/>
      <stop offset="100%" stop-color="rgba(118,139,255,0.96)"/>
    </linearGradient>
    <filter id="pmGlow" x="-35%" y="-35%" width="170%" height="170%">
      <feGaussianBlur stdDeviation="1.2" result="blur"/>
      <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>`;

  let grid = "";
  for (let i = 5; i < TOTAL_BINS; i += 5) {
    const x = padX + i * slotW;
    const strong = mode === "full" && i === HALF_BINS;
    grid += `<line x1="${x.toFixed(2)}" y1="${padY}" x2="${x.toFixed(2)}" y2="${VB_H - padY}" stroke="${strong ? 'rgba(255,255,255,0.34)' : 'rgba(255,255,255,0.06)'}" stroke-width="${strong ? '1.15' : '0.5'}"/>`;
  }

  const elapsedW = (activeCount * slotW).toFixed(2);
  const elapsedTrack = mode === "full"
    ? `<rect x="${padX}" y="${(midY - 1).toFixed(2)}" width="${elapsedW}" height="2" rx="1" fill="rgba(255,255,255,0.10)"/>`
    : "";

  let rects = "";
  for (let i = 0; i < values.length; i++) {
    const v = values[i];
    if (v === null) continue;
    const x = xForIndex(i);
    if (!v) {
      rects += `<rect x="${x.toFixed(2)}" y="${(midY - 0.65).toFixed(2)}" width="${barW.toFixed(2)}" height="1.3" rx="0.6" fill="rgba(255,255,255,0.25)"/>`;
      continue;
    }
    const h = Math.max(3.2, (Math.abs(v) / peak) * (halfH - 2.5));
    if (v > 0) {
      rects += `<rect class="pressure-chart-bar" x="${x.toFixed(2)}" y="${(midY - h).toFixed(2)}" width="${barW.toFixed(2)}" height="${h.toFixed(2)}" rx="1.05" fill="url(#pmHomeGrad)"/>`;
    } else {
      rects += `<rect class="pressure-chart-bar" x="${x.toFixed(2)}" y="${midY.toFixed(2)}" width="${barW.toFixed(2)}" height="${h.toFixed(2)}" rx="1.05" fill="url(#pmAwayGrad)"/>`;
    }
  }

  let goalMarks = "";
  for (const g of goals) {
    const slot = slotFromGoalMinute(g && g.minute);
    if (slot === null) continue;
    const idx = mode === "full" ? slot : slotToIndex.get(slot);
    if (idx === undefined || idx === null || idx < 0 || idx >= TOTAL_BINS) continue;
    const gx = centerXForIndex(idx);
    const side = String(g && g.side || "").toLowerCase();
    const homeGoal = side === "home" || side === "h" || side === "1";
    const gy = homeGoal ? padY + 8 : VB_H - padY - 8;
    goalMarks += `<g filter="url(#pmGlow)">
      <circle cx="${gx.toFixed(2)}" cy="${gy.toFixed(2)}" r="5.5" fill="rgba(8,13,18,0.86)" stroke="${homeGoal ? 'rgba(41,231,139,0.95)' : 'rgba(118,139,255,0.95)'}" stroke-width="1.15"/>
      <text x="${gx.toFixed(2)}" y="${(gy + 2.9).toFixed(2)}" text-anchor="middle" font-size="8.5" fill="rgba(255,255,255,0.96)">⚽</text>
    </g>`;
  }

  const markerX = padX + clamp(activeCount, 1, TOTAL_BINS) * slotW;
  const marker = `<g>
    <line x1="${markerX.toFixed(2)}" y1="2" x2="${markerX.toFixed(2)}" y2="${VB_H - 2}" stroke="rgba(248, 113, 113, 0.92)" stroke-width="1.25"/>
    <circle cx="${markerX.toFixed(2)}" cy="${midY.toFixed(2)}" r="2.2" fill="rgba(248,113,113,0.96)"/>
  </g>`;

  const labels = mode === "full"
    ? `<text x="${(padX + 2).toFixed(2)}" y="${(VB_H - 3).toFixed(2)}" font-size="7" fill="rgba(255,255,255,0.36)">1'</text>
       <text x="${(padX + HALF_BINS * slotW + 2).toFixed(2)}" y="${(VB_H - 3).toFixed(2)}" font-size="7" fill="rgba(255,255,255,0.36)">46'</text>
       <text x="${(VB_W - padX - 12).toFixed(2)}" y="${(VB_H - 3).toFixed(2)}" font-size="7" fill="rgba(255,255,255,0.36)">90'</text>`
    : `<text x="${(padX + 2).toFixed(2)}" y="${(VB_H - 3).toFixed(2)}" font-size="7" fill="rgba(255,255,255,0.36)">-20</text>
       <text x="${(VB_W - padX - 17).toFixed(2)}" y="${(VB_H - 3).toFixed(2)}" font-size="7" fill="rgba(255,255,255,0.36)">now</text>`;

  return `<svg viewBox="0 0 ${VB_W} ${VB_H}" width="100%" height="${VB_H}" preserveAspectRatio="none" aria-hidden="true">
    ${defs}
    <rect x="0" y="0" width="${VB_W}" height="${VB_H}" fill="rgba(8, 13, 18, 0.52)"/>
    ${grid}
    ${elapsedTrack}
    <line x1="${padX}" y1="${midY}" x2="${VB_W - padX}" y2="${midY}" stroke="rgba(255,255,255,0.24)" stroke-width="0.8"/>
    ${rects}
    ${goalMarks}
    ${marker}
    ${labels}
  </svg>`;
}

function showPressureInfo(kind = "full") {
  const map = {
    full: [
      "График давления · весь матч",
      "",
      "Показывает, какая команда больше давила по ходу всего матча.",
      "Зелёные столбики — хозяева, светлые/синие — гости.",
      "Высота столбиков считается по атакам, опасным атакам, ударам, ударам в створ, угловым и импульсу гола.",
      "Метки голов показывают, в какой момент был забит гол.",
    ],
    last20: [
      "График давления · последние 20 минут",
      "",
      "Это тот же график давления, но только за последние 20 минут матча.",
      "Нужен, чтобы быстро понять текущий отрезок и свежий напор команд.",
      "Зелёные столбики — хозяева, светлые/синие — гости.",
    ],
    indicator: [
      "Индикатор давления",
      "",
      "Это быстрая сводка за окно последних минут.",
      "Проценты показывают, кто давил сильнее на этом отрезке.",
      "Расчёт идёт по атакам, опасным атакам, ударам, ударам в створ, угловым и импульсу гола.",
    ],
  };
  const msg = (map[kind] || map.full).join("\n");
  try {
    if (tg?.showAlert) return tg.showAlert(msg);
  } catch (_) {}
  alert(msg);
}

function showGoalWaitInfo() {
  const msg = [
    "Ждём гол",
    "",
    "Это сигнал матча, где есть хорошие шансы на следующий гол.",
    "Отдельный переключатель решает, нужно ли потом присылать уведомление о голе по найденному матчу.",
    "Он учитывает минуту, счёт, удары, удары в створ, опасные атаки, угловые и давление.",
    "Чем выше оценка /100, тем сильнее текущий сигнал.",
  ].join("\n");
  try {
    if (tg?.showAlert) return tg.showAlert(msg);
  } catch (_) {}
  alert(msg);
}

function pressureInfoButton(kind, title, extraClass = "") {
  const cls = ["info-mini-btn", extraClass].filter(Boolean).join(" ");
  return `<button class="${cls}" type="button" onclick="showPressureInfo('${kind}')" aria-label="${esc(title || 'Информация')}" title="${esc(title || 'Информация')}">!</button>`;
}

function pressureChartCard(title, headerRight, contentHtml, legendMatch, infoKind = "full") {
  // v9.24: optional left-side logo column. We only show logos when actual
  // logo URLs are present on the match payload — falls back gracefully to the
  // old centred layout when logos are missing (avoids two empty boxes on the
  // left for matches without crests).
  const m = legendMatch || {};
  const homeLogo = String(m.home_logo || "").trim();
  const awayLogo = String(m.away_logo || "").trim();
  const hasLogos = homeLogo || awayLogo;
  const logosCol = hasLogos
    ? `<div class="pressure-chart-logos" aria-hidden="true">
        <div class="pressure-chart-logo home">${homeLogo ? `<img src="${esc(homeLogo)}" alt="" onerror="this.style.display='none'"/>` : ""}</div>
        <div class="pressure-chart-logo away">${awayLogo ? `<img src="${esc(awayLogo)}" alt="" onerror="this.style.display='none'"/>` : ""}</div>
      </div>`
    : "";
  return `<div class="pressure-chart-section">
    <div class="pressure-chart-card">
      ${pressureInfoButton(infoKind, title, "card-corner")}
      <div class="pressure-chart-head">
        <div class="pressure-head-main"><span class="pressure-head-title">${title}</span></div>
        <span>${headerRight}</span>
      </div>
      <div class="pressure-chart-body ${hasLogos ? "has-logos" : ""}">
        ${logosCol}
        <div class="pressure-chart-wrap">${contentHtml}</div>
      </div>
      <div class="pressure-chart-legend">
        <span class="pressure-chart-legend-item home"><i></i>${esc(m.home || "Хозяева")}</span>
        <span class="pressure-chart-legend-item away"><i></i>${esc(m.away || "Гости")}</span>
      </div>
    </div>
  </div>`;
}


function chartMinuteSlotFromMatch(m) {
  const minute = safeInt(m && m.minute, 0);
  const period = String((m && m.period) || "").toUpperCase();
  if (minute <= 0) return 0;
  if (period === "2T" || minute > 45) {
    if (minute >= 90) return 89;
    return 45 + clamp(minute - 46, 0, 44);
  }
  if (minute >= 45) return 44;
  return clamp(minute - 1, 0, 44);
}

function pressureScoreFromCurrentStats(stats, side) {
  const attacks = statSide(stats, "attacks", side);
  const dangerous = statSide(stats, "dangerous", side);
  const shots = statSide(stats, "shots", side);
  const onTarget = statSide(stats, "on_target", side);
  const corners = statSide(stats, "corners", side);
  return pressureWeightedScore(attacks, dangerous, shots, onTarget, corners);
}

function buildPressureChartFallbackBars(detail, mode = "full") {
  const m = (detail && detail.match) || {};
  const stats = (detail && detail.stats) || {};
  const slotMax = mode === "full" ? chartMinuteSlotFromMatch(m) : 49;
  const statTotalValue = ["attacks", "dangerous", "shots", "on_target", "corners"].reduce((acc, key) => acc + statTotal(stats, key), 0);
  const minute = safeInt(m.minute, 0);
  if (!minute && !statTotalValue) return [];

  const homeScore = pressureScoreFromCurrentStats(stats, "home");
  const awayScore = pressureScoreFromCurrentStats(stats, "away");
  const pressureTotal = Math.max(1, homeScore + awayScore);
  const count = Math.max(4, Math.min(14, Math.round(Math.max(1, slotMax + 1) / 6)));
  const now = Math.floor(Date.now() / 1000);
  const bars = [];
  for (let i = 0; i < count; i++) {
    const ratio = count <= 1 ? 1 : i / (count - 1);
    // Put fallback samples across the elapsed match area instead of packing
    // every bar into the opening minutes (the old visual "cluster left" bug).
    const slot = mode === "full" ? Math.round(ratio * Math.max(0, slotMax)) : Math.round(ratio * 44);
    const scale = statTotalValue ? (0.18 + ratio * 0.82) / count : 0.18;
    // When there is no stat movement yet, keep a tiny neutral trace instead of
    // a blank chart. Real collector bars replace this as soon as history exists.
    let h = statTotalValue ? (homeScore / pressureTotal) * scale * 28 : 0.2;
    let a = statTotalValue ? (awayScore / pressureTotal) * scale * 28 : 0.2;
    if (Math.abs(h - a) < 0.05) {
      if (i % 2 === 0) h += 0.08;
      else a += 0.08;
    }
    bars.push({ t: now - (count - i) * 45, slot, h, a, fallback: true });
  }
  return bars;
}

function pressureGoalsFromEvents(events) {
  const goals = [];
  for (const ev of (Array.isArray(events) ? events : [])) {
    if (String(ev && ev.type || "").toLowerCase() !== "goal") continue;
    const minute = Number(ev && ev.minute) || 0;
    if (minute <= 0) continue;
    goals.push({ minute, side: String(ev.side || "").toLowerCase(), score: String(ev.score || "") });
  }
  return goals;
}

function chartHeaderMinuteLabel(match) {
  const m = match || {};
  const raw = String(m.minute_text || "").trim();
  if (raw && /\d|HT|LIVE|перерыв|FT/i.test(raw)) return raw;
  const minute = safeInt(m.minute, 0);
  return minute > 0 ? `${minute}'` : "LIVE";
}

function renderPressureChartFull(detail) {
  const m = detail && detail.match;
  if (!m || !m.id) return "";
  const pc = (detail && detail.pressure_chart) || {};
  const goals = pressureGoalsFromEvents(detail && detail.events);

  if (pc.available === false || !Array.isArray(pc.bars_full) || pc.bars_full.length === 0) {
    const fallbackBars = buildPressureChartFallbackBars(detail, "full");
    if (fallbackBars.length) {
      const svg = pressureChartSvg(fallbackBars, { now: Math.floor(Date.now() / 1000), mode: "full", goals, match: m });
      return pressureChartCard("График давления · весь матч", chartHeaderMinuteLabel(m), svg, m, "full");
    }
    return pressureChartCard(
      "График давления · весь матч",
      "сбор данных…",
      `<div class="pressure-chart-empty">Сервер собирает историю статистики. График появится после второго снимка (примерно через минуту после начала матча).</div>`,
      m,
      "full"
    );
  }
  const bars = pc.bars_full;
  const now = Number(pc.now_ts) || Math.floor(Date.now() / 1000);
  const firstTs = Number(bars[0].t);
  const lastTs = Number(bars[bars.length - 1].t);
  const spanMin = Math.max(1, Math.round((lastTs - firstTs) / 60));
  const svg = pressureChartSvg(bars, { now, mode: "full", goals, match: m });
  return pressureChartCard("График давления · весь матч", chartHeaderMinuteLabel(m), svg, m, "full");
}

function renderPressureChartLast20(detail) {
  const m = detail && detail.match;
  if (!m || !m.id) return "";
  const pc = (detail && detail.pressure_chart) || {};
  const windowSec = Number(pc.window_seconds_20m) || 1200;
  if (pc.available === false || !Array.isArray(pc.bars_20m) || pc.bars_20m.length === 0) {
    return pressureChartCard(
      "График давления · последние 20 мин",
      "сбор данных…",
      `<div class="pressure-chart-empty">Здесь будут только последние ${Math.round(windowSec / 60)} минут давления — отдельно от графика всего матча.</div>`,
      m,
      "last20"
    );
  }
  const bars = pc.bars_20m;
  const now = Number(pc.now_ts) || Math.floor(Date.now() / 1000);
  const firstTs = Number(bars[0].t);
  const collectedSec = Math.max(0, now - firstTs);
  const isFull = collectedSec >= windowSec - 30;
  const headerRight = isFull
    ? `последние ${Math.round(windowSec / 60)} мин`
    : `собрано ${Math.max(1, Math.round(collectedSec / 60))}/${Math.round(windowSec / 60)} мин`;
  const goals = pressureGoalsFromEvents(detail && detail.events);
  const svg = pressureChartSvg(bars, { now, mode: "last20", goals, match: m });
  return pressureChartCard("График давления · последние 20 мин", headerRight, svg, m, "last20");
}


function renderPressureSection(pressure) {
  if (!pressure || !Object.keys(pressure).length) return "";
  const win = safeInt(pressure.window_minutes, 20);
  if (pressure.available === false) {
    return `<div class="pressure-section">
      <div class="pressure-card muted">
        <div class="pressure-head">
          <div class="pressure-head-main"><span class="pressure-head-title">Индикатор давления · ${win} мин</span></div>
          <span class="pressure-head-note">сбор данных…</span>
        </div>
        <div class="pressure-empty">Собираю историю статистики за последние ${win} минут. Индикатор появится после второго снимка (≈12 секунд).</div>
      </div>
    </div>`;
  }

  const h = pressure.home || {};
  const a = pressure.away || {};
  const hp = Math.max(0, Math.min(100, safeInt(h.percent, 50)));
  const ap = Math.max(0, Math.min(100, safeInt(a.percent, 50)));
  const m = state.detail?.match || {};
  const isCurrentSnapshot = pressure.mode === "current_snapshot";
  const spanMin = isCurrentSnapshot
    ? 0
    : (pressure.span_match_minutes
        ? Math.max(1, Math.round(Number(pressure.span_match_minutes)))
        : (pressure.span_seconds ? Math.max(1, Math.round(Number(pressure.span_seconds) / 60)) : win));
  // v9.94: keep the pressure card title stable and clean.
  // The card still calculates the live 20-minute window internally, but the UI
  // no longer shows "собрано 11/20" or "Давление за 11 мин · окно 20 мин".
  const headerText = `Давление за ${win} минут`;
  const subText = "";

  function row(label, hk, ak) {
    return `<div class="pressure-stat-row">
      <span>${safeInt(h[hk], 0)}</span>
      <em>${label}</em>
      <span>${safeInt(a[ak], 0)}</span>
    </div>`;
  }

  return `<div class="pressure-section">
    <div class="pressure-card">
      <div class="pressure-head">
        <div class="pressure-head-main"><span class="pressure-head-title">${headerText}</span></div>
      </div>
      <div class="pressure-pct-row">
        <strong>${hp}%</strong>
        <small>${subText}</small>
        <strong>${ap}%</strong>
      </div>
      <div class="pressure-bar">
        <div class="pressure-home" style="width:${hp}%"></div>
        <div class="pressure-away" style="width:${ap}%"></div>
      </div>
      <div class="pressure-grid">
        ${row("Удары", "shots_delta", "shots_delta")}
        ${row("В створ", "on_target_delta", "on_target_delta")}
        ${row("Угловые", "corners_delta", "corners_delta")}
        ${row("Атаки", "attacks_delta", "attacks_delta")}
        ${row("Опасные атаки", "dangerous_delta", "dangerous_delta")}
      </div>
    </div>
  </div>`;
}


function renderOddsSection(odds, prematchOdds = {}, movement = {}, isLive = true) {
  const current = (odds && typeof odds === "object") ? odds : {};
  const prematch = (prematchOdds && typeof prematchOdds === "object") ? prematchOdds : {};
  const eu = current.eu || {};
  const bs = current.bs || {};
  const preEu = prematch.eu || {};
  const preBs = prematch.bs || {};
  const hasCurrent = !!(eu["1"] || eu["X"] || eu["2"] || bs.over || bs.under);
  const hasPrematch = !!(preEu["1"] || preEu["X"] || preEu["2"] || preBs.over || preBs.under);
  const showLive = !!(isLive && hasCurrent);
  if (!hasCurrent && !hasPrematch) return "";

  function num(v) {
    const n = Number(v);
    return Number.isFinite(n) && n > 0 ? n : null;
  }
  function fmtNum(v) {
    const n = num(v);
    return n == null ? "—" : n.toFixed(2).replace(".", ",");
  }
  function calcMove(before, now) {
    const a = num(before), b = num(now);
    if (a == null || b == null) return null;
    const pct = ((b - a) / a) * 100;
    return { before:a, now:b, pct, direction:pct > .01 ? "up" : pct < -.01 ? "down" : "same" };
  }
  function moveBadge(before, now, market) {
    const provided = movement && movement[market];
    const mv = provided && Number(provided.prematch) > 0 && Number(provided.live) > 0
      ? { before:Number(provided.prematch), now:Number(provided.live), pct:Number(provided.pct)||0, direction:String(provided.direction||"same") }
      : calcMove(before, now);
    if (!mv) return "";
    const arrow = mv.direction === "up" ? "↑" : mv.direction === "down" ? "↓" : "→";
    return `<span class="odds-move ${mv.direction}">${arrow} ${mv.pct > 0 ? "+" : ""}${mv.pct.toFixed(1).replace(".", ",")}%</span>`;
  }
  function oddsCell(label, val, isLow, preVal, market) {
    return `<div class="odds-cell">
      <div class="odds-label">${esc(label)}</div>
      <div class="odds-val ${isLow ? "low" : ""}">${fmtNum(val)}</div>
      ${showLive && num(preVal) != null ? `<div class="odds-before">до матча ${fmtNum(preVal)} ${moveBadge(preVal, val, market)}</div>` : ""}
    </div>`;
  }

  let rows = "";
  if (eu["1"] || eu["X"] || eu["2"] || (!hasCurrent && hasPrematch)) {
    const shown = hasCurrent ? eu : preEu;
    const vals = [shown["1"], shown["X"], shown["2"]].filter(v => num(v) != null).map(Number);
    const minV = vals.length ? Math.min(...vals) : null;
    rows += `<div class="odds-row compact">
      ${oddsCell("П1", shown["1"], Number(shown["1"]) === minV, preEu["1"], "1")}
      ${oddsCell("Ничья", shown["X"], Number(shown["X"]) === minV, preEu["X"], "x")}
      ${oddsCell("П2", shown["2"], Number(shown["2"]) === minV, preEu["2"], "2")}
    </div>`;
  }

  if (bs.over || bs.under || (!hasCurrent && (preBs.over || preBs.under))) {
    const shown = hasCurrent ? bs : preBs;
    const line = shown.line != null ? shown.line : preBs.line;
    const lineLabel = line != null ? " " + Number(line).toFixed(2).replace(".", ",") : "";
    const vals = [shown.over, shown.under].filter(v => num(v) != null).map(Number);
    const minB = vals.length ? Math.min(...vals) : null;
    rows += `<div class="odds-row compact odds-row-total">
      ${oddsCell("Больше" + lineLabel, shown.over, Number(shown.over) === minB, preBs.over, "over")}
      <div class="odds-cell odds-mid-label">ТОТАЛ</div>
      ${oddsCell("Меньше" + lineLabel, shown.under, Number(shown.under) === minB, preBs.under, "under")}
    </div>`;
  }

  return `<div class="odds-section compact under-score">
    <div class="odds-card">
      <div class="odds-header"><span class="odds-live-dot ${showLive ? "" : "prematch"}"></span> ${showLive ? "Лайв КФ" : isLive ? "Прематч КФ · Live пока нет" : "Прематч КФ"}</div>
      ${rows}
      ${showLive && hasPrematch ? `<div class="odds-history-note">Текущий коэффициент и значение перед началом матча</div>` : ""}
    </div>
  </div>`;
}

function renderMatchEvents(events, m) {
  const allowed = new Set(["goal", "yellow", "red"]);
  const items = Array.isArray(events) ? events.filter(ev => ev && allowed.has(String(ev.type || ""))) : [];
  const title = `<div class="match-chronology-head"><div><span>СОБЫТИЯ</span><h3>Хронология матча</h3></div><small>голы · жёлтые · красные</small></div>`;

  if (!items.length) {
    return `<section class="match-chronology">${title}<div class="match-chronology-empty">SportScore пока не передал события этого матча.</div></section>`;
  }

  const eventMinuteNum = ev => {
    const direct = Number(ev?.minute);
    if (Number.isFinite(direct) && direct > 0) return direct;
    const match = String(ev?.minute_text || "").match(/(\d{1,3})(?:\s*\+\s*(\d{1,2}))?/);
    return match ? (Number(match[1]) || 0) + (Number(match[2]) || 0) : 0;
  };
  const priority = { goal: 0, yellow: 1, red: 2 };
  const sorted = items.slice().sort((a, b) => {
    const minuteDiff = eventMinuteNum(a) - eventMinuteNum(b);
    return minuteDiff || ((priority[a.type] ?? 9) - (priority[b.type] ?? 9));
  });
  const homeName = String(m?.home || "Хозяева");
  const awayName = String(m?.away || "Гости");

  const rows = sorted.map(ev => {
    const kind = String(ev.type || "");
    const side = ev.side === "home" ? "home" : ev.side === "away" ? "away" : "neutral";
    const minute = eventMinuteNum(ev);
    const rawMinute = String(ev.minute_text || "").trim();
    const minuteText = rawMinute && rawMinute !== "—" ? rawMinute.replace(/'/g, "′") : (minute ? `${minute}′` : "—");
    const team = String(ev.team || (side === "home" ? homeName : side === "away" ? awayName : "")).trim();
    const player = String(ev.player || "").trim();
    const label = kind === "goal" ? "Гол" : kind === "yellow" ? "Жёлтая карточка" : "Красная карточка";
    const icon = kind === "goal" ? `<span class="chronology-ball">⚽</span>` : `<span class="chronology-card ${kind}"></span>`;
    const score = kind === "goal" && ev.score ? `<strong class="chronology-score">${esc(String(ev.score).replace(/-/g, " : "))}</strong>` : "";
    const detail = [player, team].filter(Boolean);
    return `<div class="match-chronology-row ${kind} ${side}">
      <div class="chronology-minute">${esc(minuteText)}</div>
      <div class="chronology-icon">${icon}</div>
      <div class="chronology-content"><b>${label}</b>${detail.length ? `<span>${esc(detail.join(" · "))}</span>` : ""}</div>
      ${score || `<span class="chronology-side-dot" aria-hidden="true"></span>`}
    </div>`;
  }).join("");

  return `<section class="match-chronology">${title}<div class="match-chronology-list">${rows}</div></section>`;
}


function lineupPlayerRole(player) {
  const role = String(player?.role || player?.lineup_role || player?.type || "").toLowerCase();
  return /sub|bench|reserve|запас/.test(role) ? "substitute" : "starter";
}

function lineupShortName(name) {
  const raw = String(name || "").replace(/\s+/g, " ").trim();
  if (!raw) return "Игрок";
  const parts = raw.split(" ").filter(Boolean);
  return parts.length > 1 ? parts[parts.length - 1] : raw;
}

function renderLiveLineupPlayer(player) {
  const p = player || {};
  const number = safeInt(p.number, 0);
  const position = String(p.position || "").trim();
  const displayName = lineupShortName(p.name || p.player_name || p.full_name || "Игрок");
  return `<div class="live-lineup-player simple">
    <span class="live-lineup-number">${number || "—"}</span>
    <span class="live-lineup-name surname-only"><b>${esc(displayName)}</b>${position ? `<small>${esc(position)}</small>` : ""}</span>
  </div>`;
}

function renderLiveLineupSide(side, teamName, teamLogo, formation, players, coach) {
  const rows = Array.isArray(players) ? players.filter(Boolean) : [];
  const starters = rows.filter(p => lineupPlayerRole(p) !== "substitute");
  const substitutes = rows.filter(p => lineupPlayerRole(p) === "substitute");
  const safeStarters = starters.length ? starters : (substitutes.length ? [] : rows);
  const logo = String(teamLogo || "").trim();
  const section = (title, list) => list.length ? `<div class="live-lineup-subhead">${title}</div><div class="live-lineup-list">${list.map(renderLiveLineupPlayer).join("")}</div>` : "";
  return `<div class="live-lineup-side ${side}">
    <div class="live-lineup-team-head">
      <span class="live-lineup-team-logo">${logo ? `<img src="${esc(logo)}" alt="" loading="lazy"/>` : "⚽"}</span>
      <span><b>${esc(teamName || "Команда")}</b>${formation ? `<small>Схема ${esc(formation)}</small>` : ""}</span>
    </div>
    ${section("СТАРТОВЫЙ СОСТАВ", safeStarters)}
    ${section("ЗАПАСНЫЕ", substitutes)}
    ${coach ? `<div class="live-lineup-coach"><span>Тренер</span><b>${esc(coach)}</b></div>` : ""}
  </div>`;
}

function renderLiveLineups(detail, match) {
  const d = detail || {};
  const m = match || {};
  const l = d.lineups || {};
  const home = Array.isArray(l.home) ? l.home : [];
  const away = Array.isArray(l.away) ? l.away : [];
  if (!l.announced || (!home.length && !away.length)) return "";
  return `<section class="live-lineups-card">
    <div class="live-section-heading"><div><span>LINEUPS</span><h3>Составы команд</h3></div><small>${l.confirmed ? "подтверждены" : "предварительные"}</small></div>
    <div class="live-lineups-grid">
      ${renderLiveLineupSide("home", m.home, m.home_logo, l.home_formation, home, l.home_coach)}
      ${renderLiveLineupSide("away", m.away, m.away_logo, l.away_formation, away, l.away_coach)}
    </div>
  </section>`;
}

function renderAbsencePlayer(player) {
  const p = player || {};
  const photo = String(p.photo || p.image || "").trim();
  return `<div class="live-absence-player">
    <span class="live-absence-avatar ${photo ? "" : "empty"}">${photo ? `<img src="${esc(photo)}" alt="" loading="lazy" onerror="this.parentElement.classList.add('empty')"/>` : "👤"}</span>
    <span><b>${esc(p.name || "Игрок")}</b>${p.reason ? `<small>${esc(p.reason)}</small>` : ""}</span>
  </div>`;
}

function renderMatchAbsences(detail, match) {
  const d = detail || {};
  const m = match || {};
  const a = d.absences || d.injuries || {};
  const home = Array.isArray(a.home) ? a.home : [];
  const away = Array.isArray(a.away) ? a.away : [];
  if (!home.length && !away.length) return "";
  const side = (name, logo, rows) => `<div class="live-absence-side"><div class="live-absence-team"><span>${logo ? `<img src="${esc(logo)}" alt="" loading="lazy"/>` : "⚽"}</span><b>${esc(name || "Команда")}</b></div>${rows.length ? rows.map(renderAbsencePlayer).join("") : `<div class="live-absence-empty">Нет данных</div>`}</div>`;
  return `<section class="live-absences-card">
    <div class="live-section-heading"><div><span>AVAILABILITY</span><h3>Травмы и дисквалификации</h3></div></div>
    <div class="live-absence-grid">${side(m.home, m.home_logo, home)}${side(m.away, m.away_logo, away)}</div>
  </section>`;
}

function renderDetailTab(s, avg) {
  return renderLiveStatsTab(s, state.detail?.match || {}, state.avgTotalData || state.detail?.avg || {});
}

function statBar(home, away, label) {
  const h = safeInt(home);
  const a = safeInt(away);
  const total = h + a || 1;
  const hPct = (h / total) * 100;
  const aPct = (a / total) * 100;
  return `
    <div class="stat-bar">
      <div class="stat-bar-head">
        <span class="stat-bar-value home">${h}</span>
        <span class="stat-bar-label">${esc(label)}</span>
        <span class="stat-bar-value away">${a}</span>
      </div>
      <div class="stat-bar-track">
        <div class="stat-bar-fill-h" style="width:${hPct}%"></div>
        <div class="stat-bar-fill-a" style="width:${aPct}%"></div>
      </div>
    </div>
  `;
}

function statBarDecimal(home, away, label, digits = 2) {
  const h = Number(home) || 0;
  const a = Number(away) || 0;
  const total = h + a || 1;
  const hPct = (h / total) * 100;
  const aPct = (a / total) * 100;
  return `
    <div class="stat-bar">
      <div class="stat-bar-head">
        <span class="stat-bar-value home">${h.toFixed(digits)}</span>
        <span class="stat-bar-label">${esc(label)}</span>
        <span class="stat-bar-value away">${a.toFixed(digits)}</span>
      </div>
      <div class="stat-bar-track">
        <div class="stat-bar-fill-h" style="width:${hPct}%"></div>
        <div class="stat-bar-fill-a" style="width:${aPct}%"></div>
      </div>
    </div>
  `;
}

function pctBar(home, away, label) {
  const h = clamp(safeInt(home, 50), 0, 100);
  const a = clamp(safeInt(away, 100 - h), 0, 100);
  return `
    <div class="stat-bar">
      <div class="stat-bar-head">
        <span class="stat-bar-value home">${h}%</span>
        <span class="stat-bar-label">${esc(label)}</span>
        <span class="stat-bar-value away">${a}%</span>
      </div>
      <div class="stat-bar-track">
        <div class="stat-bar-fill-h" style="width:${h}%"></div>
        <div class="stat-bar-fill-a" style="width:${a}%"></div>
      </div>
    </div>
  `;
}

function showPulseInfo() {
  const msg = [
    "Пульс матча — это быстрая шкала активности 0–100.",
    "",
    "Он считается без доп. нагрузки по минуте, счёту, ударам, ударам в створ, опасным атакам, угловым и общему давлению.",
    "",
    "0–39 — низкий темп",
    "40–69 — средний",
    "70–84 — высокий",
    "85–100 — очень высокий",
  ].join("\n");
  try {
    if (tg?.showAlert) return tg.showAlert(msg);
  } catch (_) {}
  alert(msg);
}

function showMainFeedInfo() {
  const msg = [
    "Подсветка, Ждём гол и свайпы",
    "",
    "На главной странице подсветка помогает быстро заметить важные матчи.",
    "",
    "• Яркий зелёно-изумрудный — очень горячий матч с пульсом 92+.",
    "• Тёмно-зелёный — умеренная активность: пульс 50+ после 60-й минуты.",
    "",
    "Что такое Ждём гол:",
    "Это матчи, где по времени, счёту и текущей активности есть хорошая вероятность следующего гола. Обычно это активные матчи с давлением, ударами и подходящей минутой.",
    "",
    "Свайпы между матчами:",
    "Открой карточку матча и проведи пальцем влево или вправо, чтобы перейти к следующему или предыдущему матчу из текущей ленты.",
  ].join("\n");
  try {
    if (tg?.showAlert) return tg.showAlert(msg);
  } catch (_) {}
  alert(msg);
}

function computeMatchPulse(match, stats, avgData) {
  const m = match || {};
  const s = stats || {};
  const minute = safeInt(m.minute, 0);
  const scoreHome = safeInt(m.score_home, 0);
  const scoreAway = safeInt(m.score_away, 0);
  const totalGoals = scoreHome + scoreAway;
  const goalDiff = Math.abs(scoreHome - scoreAway);
  const shots = statTotal(s, "shots");
  const onTarget = statTotal(s, "on_target");
  const offTarget = statTotal(s, "off_target");
  const attacks = statTotal(s, "attacks");
  const dangerous = statTotal(s, "dangerous");
  const corners = statTotal(s, "corners");
  const hp = pressurePowerFromStats(s, "home");
  const ap = pressurePowerFromStats(s, "away");
  const pressureTotal = hp + ap;
  const pressurePct = pressureTotal > 0 ? Math.round((Math.max(hp, ap) / pressureTotal) * 100) : 50;
  const pressureSide = hp > ap ? "хозяева" : ap > hp ? "гости" : "обе команды";
  const possHome = safeInt(s?.possession?.home, 0);
  const possAway = safeInt(s?.possession?.away, 0);
  const possessionKnown = (possHome + possAway) > 0;
  const possessionSwing = possessionKnown ? Math.max(Math.abs(possHome - 50), Math.abs(possAway - 50)) : 0;
  const avgSrc = avgData || {};
  const homeAvg = Number(avgSrc?.home?.total_avg ?? avgSrc?.home?.avg);
  const awayAvg = Number(avgSrc?.away?.total_avg ?? avgSrc?.away?.avg);
  const avgTotals = [homeAvg, awayAvg].filter(v => Number.isFinite(v) && v > 0);
  const avgTotal = avgTotals.length ? (avgTotals.reduce((acc, v) => acc + v, 0) / avgTotals.length) : null;

  let score = 4;

  // Более строгий вклад минуты: максимум в основном времени,
  // а в глубоком экстра-тайме не разгоняем оценку автоматически.
  if (minute >= 20 && minute < 45) score += Math.min(8, (minute - 20) * 0.18);
  else if (minute >= 45 && minute <= 75) score += 8 + Math.min(8, (minute - 45) * 0.20);
  else if (minute > 75 && minute <= 95) score += 10;
  else if (minute > 95) score += 7;

  // Основная активность — меньше весов, чтобы 100/100 было только у реально сильных матчей.
  score += Math.min(12, shots * 0.45);
  score += Math.min(18, onTarget * 1.8);
  score += Math.min(8, offTarget * 0.35);
  score += Math.min(8, attacks * 0.02);
  score += Math.min(14, dangerous * 0.09);
  score += Math.min(6, corners * 1.1);
  score += Math.min(8, Math.max(0, pressurePct - 52) * 0.22);
  score += Math.min(4, Math.max(0, possessionSwing - 10) * 0.12);

  // Средний тотал влияет мягко и только при действительно хорошем фоне команд.
  if (avgTotal != null) {
    if (avgTotal >= 3.0) score += 6;
    else if (avgTotal >= 2.6) score += 4;
    else if (avgTotal >= 2.2) score += 2;
    else if (avgTotal < 2.0) score -= 3;
  }

  // Контекст счёта.
  if (totalGoals === 0 && minute >= 25) score += 6;
  else if (goalDiff === 0 && totalGoals <= 2) score += 4;
  else if (goalDiff === 1 && minute >= 50) score += 2;

  // Бонус только за сильную комбинацию метрик, а не за один показатель.
  if (onTarget >= 6 && dangerous >= 60) score += 10;
  else if (onTarget >= 4 && dangerous >= 40) score += 6;
  else if (onTarget >= 3 && dangerous >= 30) score += 3;

  if (shots >= 20 && corners >= 8) score += 5;

  // Штрафы: если матч сырой или темп обманчивый, режем оценку.
  if (minute < 15) score -= 10;
  if (onTarget <= 1 && dangerous < 15) score -= 12;
  else if (onTarget <= 2 && dangerous < 25) score -= 8;
  if (shots < 8 && minute >= 35) score -= 6;
  if (totalGoals >= 4 && goalDiff >= 2) score -= 4;

  const finalScore = clamp(Math.round(score), 1, 100);
  const level = finalScore >= 88 ? "Очень высокий темп" : finalScore >= 72 ? "Высокий темп" : finalScore >= 50 ? "Средний темп" : "Низкий темп";
  const summary = `${minute || "LIVE"} мин · удары ${shots} · в створ ${onTarget} · опасные ${dangerous}`;
  return { score: finalScore, level, summary, pressurePct, pressureSide, avgTotal };
}

function renderPulseStat(match, stats, avgData) {
  const pulse = computeMatchPulse(match, stats, avgData);
  const filled = Math.max(1, Math.round(pulse.score / 10));
  const bars = Array.from({ length: 10 }, (_, i) => `<span class="pulse-seg ${i < filled ? "on" : ""}"></span>`).join("");
  return `<div class="match-pulse-card">
    <button class="pulse-info-btn card-corner" type="button" onclick="showPulseInfo()" aria-label="Что означает пульс матча" title="Что означает пульс матча">!</button>
    <div class="match-pulse-head">
      <div class="match-pulse-title">Пульс матча</div>
      <div class="match-pulse-score">${pulse.score}/100</div>
    </div>
    <div class="match-pulse-track-mini" aria-label="Пульс матча ${pulse.score} из 100">${bars}</div>
    <div class="match-pulse-meta">
      <span>${esc(pulse.level)}</span>
      <span>${esc(pulse.summary)}</span>
      ${pulse.avgTotal != null ? `<span>Средний тотал: ${avgDisplay(pulse.avgTotal, 2)}</span>` : ""}
      <span>Давление: ${pulse.pressurePct}% · ${esc(pulse.pressureSide)}</span>
    </div>
  </div>`;
}

function liveStatsHaveData(s) {
  if (!s || typeof s !== "object") return false;
  return ["possession", "shots", "on_target", "off_target", "attacks", "dangerous", "corners", "yellow_cards", "red_cards"].some(key => {
    const pair = s[key];
    return pair && typeof pair === "object" && (safeInt(pair.home, 0) > 0 || safeInt(pair.away, 0) > 0);
  });
}

function renderLiveStatsTab(s, match, avgData) {
  if (!liveStatsHaveData(s)) {
    return `<div class="empty" style="padding:40px 20px;">У этой лиги пока нет расширенной live-статистики.</div>`;
  }
  const poss = s.possession || { home: 0, away: 0 };
  const shots = s.shots || { home: 0, away: 0 };
  const ontarget = s.on_target || { home: 0, away: 0 };
  const offtarget = s.off_target || { home: 0, away: 0 };
  const attacks = s.attacks || { home: 0, away: 0 };
  const dangerous = s.dangerous || { home: 0, away: 0 };
  const corners = s.corners || { home: 0, away: 0 };
  const xgLite = xgLitePairFromStats(s);
  const yellow = s.yellow_cards || { home: 0, away: 0 };
  const red = s.red_cards || { home: 0, away: 0 };
  return `
    <div class="stat-section">
      <div class="stat-section-title">Лайв-статистика</div>
      ${renderPulseStat(match, s, avgData)}
      ${statBarDecimal(xgLite.home, xgLite.away, "xG-lite", 2)}
      ${pctBar(poss.home, poss.away, "Владение")}
      ${statBar(shots.home, shots.away, "Удары")}
      ${statBar(ontarget.home, ontarget.away, "В створ")}
      ${statBar(offtarget.home, offtarget.away, "Мимо")}
      ${statBar(attacks.home, attacks.away, "Атаки")}
      ${statBar(dangerous.home, dangerous.away, "Опасные")}
      ${statBar(corners.home, corners.away, "Угловые")}
      ${statBar(yellow.home, yellow.away, "Жёлтые")}
      ${statBar(red.home, red.away, "Красные")}
    </div>
  `;
}

function renderAllStatsTab(s) {
  if (!liveStatsHaveData(s)) {
    return `<div class="empty" style="padding:40px 20px;">У этой лиги пока нет расширенной live-статистики.</div>`;
  }
  const m = state.detail?.match || {};
  const poss = s.possession || { home: 0, away: 0 };
  const shots = s.shots || { home: 0, away: 0 };
  const ontarget = s.on_target || { home: 0, away: 0 };
  const offtarget = s.off_target || { home: 0, away: 0 };
  const dangerous = s.dangerous || { home: 0, away: 0 };
  const corners = s.corners || { home: 0, away: 0 };
  const attacks = s.attacks || { home: 0, away: 0 };
  const yellow = s.yellow_cards || { home: 0, away: 0 };
  const red = s.red_cards || { home: 0, away: 0 };
  return `
    <div class="stat-section">
      <div class="stat-section-title">Команда хозяев</div>
      <div class="avg-card" style="margin-left:0;margin-right:0;">
        <div class="avg-row"><span class="avg-team">${esc(m.home)}</span><div class="avg-value"><strong>${safeInt(m.score_home)}</strong> голов</div></div>
        <div class="avg-row"><span class="avg-team">Владение</span><div class="avg-value"><strong>${safeInt(poss.home,0)}%</strong></div></div>
        <div class="avg-row"><span class="avg-team">Удары</span><div class="avg-value"><strong>${safeInt(shots.home)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">В створ</span><div class="avg-value"><strong>${safeInt(ontarget.home)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">Мимо</span><div class="avg-value"><strong>${safeInt(offtarget.home)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">Атаки</span><div class="avg-value"><strong>${safeInt(attacks.home)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">Опасные атаки</span><div class="avg-value"><strong>${safeInt(dangerous.home)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">Угловые</span><div class="avg-value"><strong>${safeInt(corners.home)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">Жёлтые</span><div class="avg-value"><strong>${safeInt(yellow.home)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">Красные</span><div class="avg-value"><strong>${safeInt(red.home)}</strong></div></div>
      </div>
      <div class="stat-section-title">Команда гостей</div>
      <div class="avg-card" style="margin-left:0;margin-right:0;">
        <div class="avg-row"><span class="avg-team">${esc(m.away)}</span><div class="avg-value"><strong>${safeInt(m.score_away)}</strong> голов</div></div>
        <div class="avg-row"><span class="avg-team">Владение</span><div class="avg-value"><strong>${safeInt(poss.away,0)}%</strong></div></div>
        <div class="avg-row"><span class="avg-team">Удары</span><div class="avg-value"><strong>${safeInt(shots.away)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">В створ</span><div class="avg-value"><strong>${safeInt(ontarget.away)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">Мимо</span><div class="avg-value"><strong>${safeInt(offtarget.away)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">Атаки</span><div class="avg-value"><strong>${safeInt(attacks.away)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">Опасные атаки</span><div class="avg-value"><strong>${safeInt(dangerous.away)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">Угловые</span><div class="avg-value"><strong>${safeInt(corners.away)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">Жёлтые</span><div class="avg-value"><strong>${safeInt(yellow.away)}</strong></div></div>
        <div class="avg-row"><span class="avg-team">Красные</span><div class="avg-value"><strong>${safeInt(red.away)}</strong></div></div>
      </div>
    </div>
  `;
}

function avgDisplay(v, digits = 2) {
  if (v === null || v === undefined || v === "") return "—";
  const n = Number(v);
  if (!Number.isFinite(n)) return esc(v);
  return n.toFixed(digits).replace(/\.00$/, "").replace(/(\.\d)0$/, "$1");
}

function metricInt(v) {
  const n = Number(v);
  return Number.isFinite(n) ? String(Math.round(n)) : "—";
}

function avgCompareBar(left, right) {
  const l = Math.max(0, Number(left) || 0);
  const r = Math.max(0, Number(right) || 0);
  const total = l + r;
  const lPct = total > 0 ? (l / total) * 100 : 50;
  const rPct = total > 0 ? (r / total) * 100 : 50;
  return `<div class="stat-bar-track avg-compare-track"><div class="stat-bar-fill-h" style="width:${lPct}%"></div><div class="stat-bar-fill-a" style="width:${rPct}%"></div></div>`;
}

function renderAvgCompareRow(label, leftSum, rightSum, leftAvg, rightAvg) {
  return `
    <div class="avg-compare-row">
      <div class="avg-compare-head">
        <span class="avg-compare-big home">${metricInt(leftSum)}</span>
        <span class="avg-compare-label">${esc(label)}</span>
        <span class="avg-compare-big away">${metricInt(rightSum)}</span>
      </div>
      ${avgCompareBar(Number.isFinite(Number(leftAvg)) ? Number(leftAvg) : Number(leftSum), Number.isFinite(Number(rightAvg)) ? Number(rightAvg) : Number(rightSum))}
      <div class="avg-compare-sub">
        <span class="avg-compare-small home">${avgDisplay(leftAvg)}</span>
        <span class="avg-compare-sub-label">В среднем за матч</span>
        <span class="avg-compare-small away">${avgDisplay(rightAvg)}</span>
      </div>
    </div>
  `;
}

function renderAvgCountRow(label, leftCount, rightCount, leftTotal, rightTotal) {
  const l = Number(leftCount) || 0;
  const r = Number(rightCount) || 0;
  const lt = Number(leftTotal) || 0;
  const rt = Number(rightTotal) || 0;
  const lp = lt > 0 ? Math.round((l / lt) * 100) : null;
  const rp = rt > 0 ? Math.round((r / rt) * 100) : null;
  return `
    <div class="avg-compare-row form-compare-row">
      <div class="avg-compare-head">
        <span class="avg-compare-big home">${metricInt(l)}</span>
        <span class="avg-compare-label">${esc(label)}</span>
        <span class="avg-compare-big away">${metricInt(r)}</span>
      </div>
      ${avgCompareBar(l, r)}
      <div class="avg-compare-sub">
        <span class="avg-compare-small home">${lp == null ? "—" : lp + "%"}</span>
        <span class="avg-compare-sub-label">Доля за период</span>
        <span class="avg-compare-small away">${rp == null ? "—" : rp + "%"}</span>
      </div>
    </div>
  `;
}

function renderAvgTotalPanel(fallbackAvg) {
  const m = state.detail?.match || {};
  if (state.avgTotalLoading) {
    return `<div class="avg-total-panel"><div class="loading"><div class="spinner"></div>Считаю средние…</div></div>`;
  }
  if (state.avgTotalError) {
    return `<div class="avg-total-panel"><div class="empty" style="padding:24px 14px;">${esc(state.avgTotalError)}</div></div>`;
  }
  const avg = state.avgTotalData || fallbackAvg || {};
  const h = avg.home || {};
  const a = avg.away || {};
  if (!h.count && !a.count && !h.avg && !a.avg) {
    return `<div class="avg-total-panel"><div class="empty" style="padding:24px 14px;">Нет данных по средним за последние матчи.</div></div>`;
  }
  const homeCount = safeInt(h.count);
  const awayCount = safeInt(a.count);

  return `
    <div class="avg-total-panel">
      <div class="stat-section-title">Форма · последние ${Math.max(homeCount, awayCount) || 10} матчей</div>
      <div class="avg-compare-card">
        ${renderAvgCountRow("Победы", h.count ? h.wins : 0, a.count ? a.wins : 0, homeCount, awayCount)}
        ${renderAvgCountRow("Ничьи", h.count ? h.draws : 0, a.count ? a.draws : 0, homeCount, awayCount)}
        ${renderAvgCountRow("Поражения", h.count ? h.losses : 0, a.count ? a.losses : 0, homeCount, awayCount)}
        ${renderAvgCompareRow("Забито", h.count ? h.scored_sum : null, a.count ? a.scored_sum : null, h.scored_avg, a.scored_avg)}
        ${renderAvgCompareRow("Пропущено", h.count ? h.conceded_sum : null, a.count ? a.conceded_sum : null, h.conceded_avg, a.conceded_avg)}
        ${renderAvgCompareRow("Тотал матч", h.count ? (h.total_sum ?? h.avg) : null, a.count ? (a.total_sum ?? a.avg) : null, h.total_avg ?? h.avg, a.total_avg ?? a.avg)}
      </div>
    </div>
  `;
}

function renderAvgTab(avg) {
  return renderAvgTotalPanel(avg);
}

async function toggleAvgTotal() {
  if (state.avgTotalOpen) {
    state.avgTotalOpen = false;
    render();
    return;
  }
  state.avgTotalOpen = true;
  if (state.avgTotalData) {
    render();
    return;
  }
  state.avgTotalLoading = true;
  state.avgTotalError = "";
  render();
  try {
    const id = state.selectedMatch || state.detail?.match?.id || "";
    const res = await fetch(`/api/match/avg?id=${encodeURIComponent(id)}`, { cache: "no-store" });
    const payload = await res.json();
    if (!payload.ok) throw new Error(payload.error || "avg failed");
    state.avgTotalData = payload.avg || {};
  } catch (err) {
    state.avgTotalError = "Не удалось загрузить средний тотал.";
  } finally {
    state.avgTotalLoading = false;
    render();
  }
}

function setDetailTab(t) {
  const allowed = ["details", "stats", "matches", "trends", "table"];
  const next = allowed.includes(t) ? t : "details";
  if (state.detailTab === next) return;
  state.detailTab = next;
  render();
  if (next === "stats" || next === "matches" || next === "trends") ensureAvgTotalLoaded();
}

function setDetailMatchesSide(side) {
  const next = side === "away" ? "away" : "home";
  if (state.detailMatchesSide === next) return;
  state.detailMatchesSide = next;
  render();
  ensureAvgTotalLoaded();
}

async function ensureAvgTotalLoaded() {
  if (state.view !== "detail") return;
  if (state.avgTotalLoading || state.avgTotalData || state.avgTotalError) return;
  const id = state.selectedMatch || state.detail?.match?.id || "";
  if (!id) return;
  state.avgTotalLoading = true;
  state.avgTotalError = "";
  render();
  try {
    const res = await fetch(`/api/match/avg?id=${encodeURIComponent(id)}`, { cache: "no-store" });
    const payload = await res.json();
    if (!payload.ok) throw new Error(payload.error || "avg failed");
    state.avgTotalData = payload.avg || {};
  } catch (err) {
    state.avgTotalError = "Не удалось загрузить средний тотал.";
  } finally {
    state.avgTotalLoading = false;
    render();
  }
}
function toggleFavRender(id) { toggleFavWithGoalPrompt(id); }
function goBack() {
  const target = state.detailReturnView || "matches";
  setLastOpenedMode(target === "matches" ? "matches" : target);
  state.view = target;
  state.selectedMatch = null;
  state.detail = null;
  state.avgTotalOpen = false;
  state.avgTotalLoading = false;
  state.avgTotalData = null;
  state.avgTotalError = "";
  state.detailTab = "details";
  state.detailMatchesSide = "home";
  render();
  if (target === "matches") restoreMatchListPosition();
}

// ----------------------------------------
//  Sheets (bottom slide-up modals)
// ----------------------------------------
function renderSheet() {
  if (!state.sheet) return "";
  if (state.sheet === "filters") return renderFiltersSheet();
  if (state.sheet === "notify-edit") return renderNotifyEditSheet();
  return "";
}

function openSheet(kind) {
  state.sheet = kind;
  render();
  // animate in next tick
  requestAnimationFrame(() => {
    document.querySelector(".sheet-overlay")?.classList.add("open");
    document.querySelector(".sheet")?.classList.add("open");
  });
}

function closeSheet(rerender = true) {
  document.querySelector(".sheet-overlay")?.classList.remove("open");
  document.querySelector(".sheet")?.classList.remove("open");
  setTimeout(() => {
    state.sheet = null;
    if (rerender) render();
  }, 240);
}

function renderFiltersSheet() {
  const f = state.filters;
  const field = (id, label, value, detail = "Суммарно от", suffix = "", min = 0, max = "") => {
    const maxAttr = max === "" ? "" : ` max="${max}"`;
    return `<label class="filter-condition-row" for="${id}">
      <span class="filter-condition-copy">
        <b>${label}</b>
        <small>${detail}</small>
      </span>
      <span class="filter-value-wrap ${suffix ? "has-suffix" : ""}">
        <input type="number" class="filter-value-input" id="${id}" min="${min}"${maxAttr} value="${value}" />
        ${suffix ? `<em>${suffix}</em>` : ""}
      </span>
    </label>`;
  };

  return `
    <div class="sheet-overlay" onclick="closeSheet()"></div>
    <div class="sheet notify-filter-sheet main-filter-sheet">
      <div class="sheet-handle"></div>

      <div class="sheet-header notify-filter-hero">
        <div class="notify-filter-heading">
          <div class="filter-eyebrow">Главная лента</div>
          <div class="filter-heading-row">
            <div class="sheet-title">Фильтр матчей</div>
            <button class="sheet-reset premium-reset" onclick="resetFilters()">Сбросить</button>
          </div>
          <div class="filter-subtitle">Показывать только матчи, которые соответствуют заданным условиям</div>
        </div>
      </div>

      <div class="sheet-body notify-filter-body">
        <section class="filter-section">
          <div class="filter-section-header">
            <span>Период матча</span>
            <small>минуты</small>
          </div>
          <div class="filter-minute-row">
            <label class="filter-range-field" for="f-min-from">
              <span>От</span>
              <input type="number" class="filter-minute-input" id="f-min-from" min="0" max="130" value="${f.minute_min}" />
            </label>
            <div class="filter-minute-sep"></div>
            <label class="filter-range-field" for="f-min-to">
              <span>До</span>
              <input type="number" class="filter-minute-input" id="f-min-to" min="0" max="130" value="${f.minute_max}" />
            </label>
          </div>
        </section>

        <section class="filter-section">
          <div class="filter-section-header">
            <span>Статистика матча</span>
            <small>минимум</small>
          </div>
          <div class="filter-condition-list">
            ${field("f-shots", "Удары", f.shots_min)}
            ${field("f-on-target", "Удары в створ", f.on_target_min)}
            ${field("f-off-target", "Удары мимо", f.off_target_min || 0)}
            ${field("f-dangerous", "Опасные атаки", f.dangerous_min)}
            ${field("f-attacks", "Все атаки", f.attacks_min)}
            ${field("f-corners", "Угловые", f.corners_min)}
            ${field("f-yellow-cards", "Жёлтые карточки", f.yellow_cards_min || 0)}
            ${field("f-red-cards", "Красные карточки", f.red_cards_min || 0)}
          </div>
        </section>

        <section class="filter-section">
          <div class="filter-section-header">
            <span>Дополнительные условия</span>
          </div>
          <div class="filter-condition-list">
            ${field("f-possession", "Владение мячом", f.possession_min || 0, "Максимум одной команды от", "%", 0, 100)}
          </div>
          <label class="filter-score-block" for="f-scores">
            <span class="filter-condition-copy">
              <b>Точный счёт</b>
              <small>Несколько вариантов укажите через запятую</small>
            </span>
            <input type="text" class="filter-score-input" id="f-scores" value="${esc(f.scores)}" placeholder="0-0, 1-0, 0-1" />
          </label>
        </section>
      </div>

      <div class="sheet-actions notify-filter-actions">
        <button class="btn secondary" onclick="closeSheet()">Отмена</button>
        <button class="btn primary save-premium" onclick="applyFilters()">Применить</button>
      </div>
    </div>
  `;
}

function applyFilters() {
  state.filters = readFilterInputs();
  state.preset = "all";
  closeSheet();
}

function resetFilters() {
  for (const k of Object.keys(state.filters)) state.filters[k] = (k === "scores" ? "" : (k === "minute_min" ? 1 : k === "minute_max" ? 130 : 0));
  state.preset = "all";
  closeSheet();
}

function readFilterInputs() {
  const get = (id, def = 0) => safeInt(document.getElementById(id)?.value, def);
  return {
    minute_min: clamp(get("f-min-from", 1), 0, 130),
    minute_max: clamp(get("f-min-to", 130), 0, 130),
    shots_min: get("f-shots", 0),
    on_target_min: get("f-on-target", 0),
    off_target_min: get("f-off-target", 0),
    dangerous_min: get("f-dangerous", 0),
    attacks_min: get("f-attacks", 0),
    corners_min: get("f-corners", 0),
    yellow_cards_min: get("f-yellow-cards", 0),
    red_cards_min: get("f-red-cards", 0),
    possession_min: clamp(get("f-possession", 0), 0, 100),
    scores: (document.getElementById("f-scores")?.value || "").trim(),
  };
}

function renderNotifyEditSheet() {
  const cfg = getNotifyFilter();
  const field = (id, label, value, detail = "Суммарно от", suffix = "", min = 0, max = "") => {
    const maxAttr = max === "" ? "" : ` max="${max}"`;
    return `<label class="filter-condition-row" for="${id}">
      <span class="filter-condition-copy">
        <b>${label}</b>
        <small>${detail}</small>
      </span>
      <span class="filter-value-wrap ${suffix ? "has-suffix" : ""}">
        <input type="number" class="filter-value-input" id="${id}" min="${min}"${maxAttr} value="${value}" />
        ${suffix ? `<em>${suffix}</em>` : ""}
      </span>
    </label>`;
  };

  return `
    <div class="sheet-overlay" onclick="closeSheet()"></div>
    <div class="sheet notify-filter-sheet">
      <div class="sheet-handle"></div>

      <div class="sheet-header notify-filter-hero">
        <div class="notify-filter-heading">
          <div class="filter-eyebrow">Уведомления</div>
          <div class="filter-heading-row">
            <div class="sheet-title">Фильтр матча</div>
            <button class="sheet-reset premium-reset" onclick="resetNotifyFilter()">Сбросить</button>
          </div>
          <div class="filter-subtitle">Задайте условия, при которых бот отправит уведомление</div>
        </div>
      </div>

      <div class="sheet-body notify-filter-body">
        <section class="filter-section">
          <div class="filter-section-header">
            <span>Период матча</span>
            <small>минуты</small>
          </div>
          <div class="filter-minute-row">
            <label class="filter-range-field" for="n-min-from">
              <span>От</span>
              <input type="number" class="filter-minute-input" id="n-min-from" min="0" max="130" value="${cfg.minute_min}" />
            </label>
            <div class="filter-minute-sep"></div>
            <label class="filter-range-field" for="n-min-to">
              <span>До</span>
              <input type="number" class="filter-minute-input" id="n-min-to" min="0" max="130" value="${cfg.minute_max}" />
            </label>
          </div>
        </section>

        <section class="filter-section">
          <div class="filter-section-header">
            <span>Статистика матча</span>
            <small>минимум</small>
          </div>
          <div class="filter-condition-list">
            ${field("n-shots", "Удары", cfg.shots_min)}
            ${field("n-on-target", "Удары в створ", cfg.on_target_min)}
            ${field("n-off-target", "Удары мимо", cfg.off_target_min || 0)}
            ${field("n-dangerous", "Опасные атаки", cfg.dangerous_min)}
            ${field("n-attacks", "Все атаки", cfg.attacks_min)}
            ${field("n-corners", "Угловые", cfg.corners_min)}
            ${field("n-yellow-cards", "Жёлтые карточки", cfg.yellow_cards_min || 0)}
            ${field("n-red-cards", "Красные карточки", cfg.red_cards_min || 0)}
          </div>
        </section>



        <section class="filter-section">
          <div class="filter-section-header">
            <span>Дополнительные условия</span>
          </div>
          <div class="filter-condition-list">
            ${field("n-possession", "Владение мячом", cfg.possession_min || 0, "Максимум одной команды от", "%", 0, 100)}
          </div>
          <label class="filter-score-block" for="n-scores">
            <span class="filter-condition-copy">
              <b>Точный счёт</b>
              <small>Несколько вариантов укажите через запятую</small>
            </span>
            <input type="text" class="filter-score-input" id="n-scores" value="${esc((cfg.scores || []).join(','))}" placeholder="0-0, 1-0, 0-1" />
          </label>
        </section>
      </div>

      <div class="sheet-actions notify-filter-actions">
        <button class="btn secondary" onclick="closeSheet()">Отмена</button>
        <button class="btn primary save-premium" onclick="applyNotifyFilter()">Сохранить</button>
      </div>
    </div>
  `;
}

function applyNotifyFilter() {
  const cfg = getNotifyFilter();
  const get = (id, def = 0) => safeInt(document.getElementById(id)?.value, def);
  cfg.minute_min = clamp(get("n-min-from", 1), 0, 130);
  cfg.minute_max = clamp(get("n-min-to", 130), 0, 130);
  cfg.shots_min = get("n-shots", 0);
  cfg.on_target_min = get("n-on-target", 0);
  cfg.off_target_min = get("n-off-target", 0);
  cfg.dangerous_min = get("n-dangerous", 0);
  cfg.attacks_min = get("n-attacks", 0);
  cfg.corners_min = get("n-corners", 0);
  cfg.yellow_cards_min = get("n-yellow-cards", 0);
  cfg.red_cards_min = get("n-red-cards", 0);
  cfg.possession_min = clamp(get("n-possession", 0), 0, 100);
  cfg.odds_market = "";
  cfg.odds_direction = "any";
  cfg.odds_was_min = 0;
  cfg.odds_was_max = 0;
  cfg.odds_now_min = 0;
  cfg.odds_now_max = 0;
  cfg.odds_change_pct_min = 0;
  const scoresRaw = (document.getElementById("n-scores")?.value || "").trim();
  cfg.scores = scoresRaw ? scoresRaw.split(",").map(s => s.trim()).filter(Boolean) : [];

  // Saving a notification filter now means "save and activate". Before this
  // fix users could configure a valid filter while all profiles stayed OFF.
  cfg.enabled = true;
  const active = getActiveNotifyProfile();
  const activeCfg = setOnlyNotifyProfileEnabled(active, true);
  Object.assign(activeCfg, cfg, { enabled: true });
  saveNotifyFilter(activeCfg);
  const sync = syncNotifyFilterToServer(activeCfg, { keepalive: true, warn: true });
  closeSheet();
  sync.then(data => {
    if (data?.ok) {
      try { tg?.HapticFeedback?.notificationOccurred?.("success"); } catch (_) {}
    }
  }).catch(() => {});
}

function resetNotifyFilter() {
  const def = defaultNotifyFilter();
  def.enabled = getNotifyFilter().enabled;
  saveNotifyFilter(def);
  syncNotifyFilterToServer(def, { keepalive: true, warn: true });
  closeSheet();
}

function applyGoalWaitPreset() {
  state.mainTab = "goal_wait";
  refreshMatchesScreenOnly({ preserveHeight: true });
}

// ----------------------------------------
//  v7: Search
// ----------------------------------------
let _searchDebounce = 0;
function onSearchInput(value) {
  state.search = String(value || "");
  if (_searchDebounce) clearTimeout(_searchDebounce);
  _searchDebounce = setTimeout(() => {
    refreshMatchFeedOnly();
  }, 120);
}
function clearSearch() {
  state.search = "";
  const input = document.getElementById("match-search-input");
  if (input) input.value = "";
  refreshMatchFeedOnly();
  if (input) input.focus();
}
// Kept for backwards-compat (other code may still call it).
function setPreset(_p) { /* no-op in v7 — search replaces presets */ }


// ============================================================
//  V10.8 · PREMATCH + internal team statistics
// ============================================================
const PREMATCH_POLL_INTERVAL_MS = Math.max(120000, Number(window.MINIAPP_PREMATCH_POLL_INTERVAL_MS || 300000));
let _loadPrematchInFlight = false;

function flattenPrematch(payload) {
  const cutoff = Math.floor(Date.now() / 1000) - 60;
  return flattenLive(payload)
    .filter(m => {
      const status = String(m?.status || "").trim().toLowerCase();
      const period = String(m?.period || "").trim().toUpperCase();
      const kickoff = safeInt(m?.kickoff_at, 0);
      if (m?.is_live || m?.finished) return false;
      if (["live", "inplay", "in_play", "started", "finished", "ended", "completed", "cancelled", "postponed", "abandoned"].includes(status)) return false;
      if (["LIVE", "HT", "1H", "2H", "FT", "AET", "PEN"].includes(period)) return false;
      return kickoff > 0 && kickoff >= cutoff;
    })
    .map(m => ({ ...m, period: "PRE", status: "scheduled", scheduled: true, is_live: false, finished: false, source: m.source || "sportscore_prematch" }));
}

function prematchTotal() {
  return state.prematch ? flattenPrematch(state.prematch).length : 0;
}

function kickoffDateKey(match) {
  const ts = safeInt(match?.kickoff_at, 0);
  if (!ts) return "";
  const d = new Date(ts * 1000);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function localDateKey(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function formatPrematchKickoff(match, withDate = false) {
  const ts = safeInt(match?.kickoff_at, 0);
  if (!ts) return esc(match?.time_text || match?.minute_text || "СКОРО");
  const d = new Date(ts * 1000);
  const time = d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
  if (!withDate) return time;
  const date = d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit" });
  return `${date} · ${time}`;
}

function prematchDateLabel(key) {
  if (key === localDateKey(0)) return "Сегодня";
  if (key === localDateKey(1)) return "Завтра";
  if (!key) return "Без даты";
  try { return new Date(`${key}T12:00:00`).toLocaleDateString("ru-RU", { weekday: "short", day: "2-digit", month: "2-digit" }); }
  catch (_) { return key; }
}

async function loadPrematch(force = false) {
  if (_loadPrematchInFlight) return;
  _loadPrematchInFlight = true;
  const preserve = state.view === "matches" && state.feedMode === "prematch" && !state.sheet;
  if (preserve) saveMatchListPosition();
  state.prematchLoading = !state.prematch;
  if (preserve) render();
  let shouldPoll = false;
  try {
    const res = await fetch(`/api/prematch${force ? "?force=1" : ""}`, { cache: "no-store" });
    const payload = await res.json();
    if (!res.ok) throw new Error(payload?.error || `HTTP ${res.status}`);
    state.prematch = payload;
    shouldPoll = Boolean(payload?.loading || payload?.refreshing) && flattenPrematch(payload).length === 0;
  } catch (err) {
    // Keep a previously loaded calendar on a temporary network error instead of
    // replacing it with an empty screen.
    if (!state.prematch || !flattenPrematch(state.prematch).length) {
      state.prematch = { ok: false, total: 0, countries: [], error: String(err) };
    }
  } finally {
    state.prematchLoading = false;
    _loadPrematchInFlight = false;
    if (state.view === "matches" && state.feedMode === "prematch") {
      render();
      if (preserve) restoreMatchListPosition();
    }
    if (shouldPoll) setTimeout(() => loadPrematch(false), 2500);
  }
}

function filteredPrematches() {
  let arr = flattenPrematch(state.prematch);
  const dateMode = state.prematchDate || "all";
  if (dateMode === "today") arr = arr.filter(m => kickoffDateKey(m) === localDateKey(0));
  else if (dateMode === "tomorrow") arr = arr.filter(m => kickoffDateKey(m) === localDateKey(1));
  const q = String(state.search || "").trim().toLowerCase();
  if (q) {
    arr = arr.filter(m =>
      String(m.home || "").toLowerCase().includes(q) ||
      String(m.away || "").toLowerCase().includes(q) ||
      String(m.league || "").toLowerCase().includes(q) ||
      String(m.country || "").toLowerCase().includes(q)
    );
  }
  return arr.sort((a, b) => safeInt(a.kickoff_at, 0) - safeInt(b.kickoff_at, 0));
}

function setFeedMode(mode) {
  const next = mode === "prematch" ? "prematch" : "live";
  if (state.feedMode === next) return;
  saveMatchListPosition();
  state.feedMode = next;
  state.search = "";
  try { localStorage.setItem("miniapp-v10-feed-mode", next); } catch (_) {}
  if (next === "prematch" && !state.prematch) loadPrematch(false);
  render();
  window.scrollTo({ top: 0, left: 0, behavior: "auto" });
}

function setPrematchDate(mode) {
  state.prematchDate = ["today", "tomorrow"].includes(mode) ? mode : "all";
  render();
}

function renderFeedModeTabs() {
  const liveIcon = `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M5.6 5.6a9 9 0 0 0 0 12.8M18.4 5.6a9 9 0 0 1 0 12.8"/></svg>`;
  const calendarIcon = `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M8 3v4M16 3v4M3.5 10h17"/></svg>`;
  return `<div class="feed-mode-tabs" role="tablist" aria-label="Режим матчей">
    <button class="feed-mode-tab ${state.feedMode === "live" ? "active live" : ""}" onclick="setFeedMode('live')"><span class="feed-mode-icon live-signal">${liveIcon}</span><span>LIVE</span></button>
    <button class="feed-mode-tab ${state.feedMode === "prematch" ? "active prematch" : ""}" onclick="setFeedMode('prematch')"><span class="feed-mode-icon">${calendarIcon}</span><span>ПРЕМАТЧ</span></button>
  </div>`;
}

function renderPrematchDateTabs() {
  const rows = flattenPrematch(state.prematch);
  const today = rows.filter(m => kickoffDateKey(m) === localDateKey(0)).length;
  const tomorrow = rows.filter(m => kickoffDateKey(m) === localDateKey(1)).length;
  return `<div class="prematch-date-tabs">
    <button class="prematch-date-tab ${state.prematchDate === "all" ? "active" : ""}" onclick="setPrematchDate('all')">Все <span>${rows.length}</span></button>
    <button class="prematch-date-tab ${state.prematchDate === "today" ? "active" : ""}" onclick="setPrematchDate('today')">Сегодня <span>${today}</span></button>
    <button class="prematch-date-tab ${state.prematchDate === "tomorrow" ? "active" : ""}" onclick="setPrematchDate('tomorrow')">Завтра <span>${tomorrow}</span></button>
  </div>`;
}

function renderUnifiedTopbar(total) {
  const isPre = state.feedMode === "prematch";
  const q = esc(state.search || "");
  const hasQ = !!String(state.search || "").trim();
  return `<div class="topbar unified-topbar">
    ${renderFeedModeTabs()}
    <div class="topbar-row">
      <div class="live-status ${isPre ? "prematch-status" : ""}">
        ${isPre ? `<span class="prematch-clock">◷</span><span class="live-label">ПРЕМАТЧ</span>` : `<div class="live-dot"></div><span class="live-label">LIVE</span>`}
      </div>
      <span class="live-count">· ${total} матчей</span>
      <div class="topbar-actions">
        <button class="icon-btn" onclick="${isPre ? "loadPrematch(true)" : "loadLive(true)"}" title="Обновить">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>
        </button>
        ${isPre ? "" : `<button class="icon-btn accent" onclick="openSheet('filters')" title="Фильтры"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="7" y1="12" x2="17" y2="12"/><line x1="10" y1="18" x2="14" y2="18"/></svg></button>`}
      </div>
    </div>
    ${isPre ? renderPrematchDateTabs() : renderMainFeedTabs()}
    <div class="search-row">
      <span class="search-icon" aria-hidden="true"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span>
      <input type="text" inputmode="search" autocomplete="off" autocorrect="off" spellcheck="false" class="search-input" id="match-search-input" placeholder="Поиск команды, лиги, страны…" value="${q}" oninput="onSearchInput(this.value)" />
      ${hasQ ? `<button class="search-clear" onclick="clearSearch()" aria-label="Очистить">×</button>` : ""}
    </div>
  </div>`;
}

function renderPrematchOddsMini(m) {
  const eu = m?.odds?.eu || {};
  if (eu["1"] != null || eu.X != null || eu["2"] != null) {
    return `<div class="prematch-odds-mini"><span>П1 <b>${esc(eu["1"] ?? "—")}</b></span><span>X <b>${esc(eu.X ?? "—")}</b></span><span>П2 <b>${esc(eu["2"] ?? "—")}</b></span></div>`;
  }
  return `<div class="prematch-odds-mini muted">КФ и статистика в карточке</div>`;
}

function renderPrematchRow(m) {
  const fav = isFav(m.id);
  return `<div class="match-row prematch-row" data-id="${esc(m.id)}">
    <div class="prematch-kickoff"><strong>${formatPrematchKickoff(m)}</strong><span>${esc(prematchDateLabel(kickoffDateKey(m)))}</span></div>
    <div class="match-teams prematch-teams">
      <div class="match-team-line">${teamLogoSmall(m, "home")}<div class="match-team">${esc(m.home)}</div></div>
      <div class="match-team-line">${teamLogoSmall(m, "away")}<div class="match-team">${esc(m.away)}</div></div>
      ${renderPrematchOddsMini(m)}
    </div>
    <div class="prematch-vs">VS</div>
    <button class="star-btn ${fav ? "active" : ""}" data-fav="${esc(m.id)}" title="${fav ? "Убрать" : "В избранное"}">${fav ? "★" : "☆"}</button>
  </div>`;
}

function renderPrematchLeagueGroup(g) {
  const path = String(g.competition_path || g.matches?.[0]?.competition_path || "");
  const headerContent = `<div class="league-flag">${leagueHeaderIcon(g)}</div><div class="league-text"><div class="league-country">${esc(g.country)}</div><div class="league-name">${esc(g.league)}</div></div><div class="league-count">${g.matches.length}</div>`;
  const header = path ? `<button type="button" class="league-header prematch-league-link" onclick="return openCompetition(decodeURIComponent('${encodeURIComponent(path)}'),decodeURIComponent('${encodeURIComponent(g.league||"")}'),event,'matches')">${headerContent}<span class="league-open-arrow">›</span></button>` : `<div class="league-header">${headerContent}</div>`;
  return `<div class="league-group prematch-group" data-league-key="${esc(leagueGroupKey(g))}">${header}${g.matches.sort((a,b) => safeInt(a.kickoff_at,0)-safeInt(b.kickoff_at,0)).map(renderPrematchRow).join("")}</div>`;
}

function renderSportScoreAttribution() {
  return `<div class="sportscore-attribution">Данные: <a href="https://sportscore.com/" rel="dofollow" target="_blank" title="Sports data by SportScore">SportScore</a></div>`;
}

function renderPrematchFeedInner() {
  if ((state.prematchLoading && !state.prematch) || (state.prematch?.loading && !flattenPrematch(state.prematch).length)) {
    return `<div class="loading"><div class="spinner"></div>Обновляем прематчи…<div class="empty-sub">Можно переключаться между разделами — загрузка идёт в фоне.</div></div>${renderSportScoreAttribution()}`;
  }
  if (state.prematch && state.prematch.ok === false && !flattenPrematch(state.prematch).length) {
    return `<div class="empty prematch-error"><div class="empty-icon">!</div><div>Не удалось загрузить прематчи</div><div class="empty-sub">${esc(state.prematch.error || "Источник временно недоступен")}</div><button class="retry-btn" onclick="loadPrematch(true)">Повторить</button></div>${renderSportScoreAttribution()}`;
  }
  const visible = filteredPrematches();
  const groups = groupByLeague(visible);
  if (!groups.length) return `${renderEmpty()}${renderSportScoreAttribution()}`;
  return `${groups.map(renderPrematchLeagueGroup).join("")}${renderSportScoreAttribution()}`;
}

const _v9RenderMatches = renderMatches;
renderMatches = function renderMatchesV10() {
  const isPre = state.feedMode === "prematch";
  const total = isPre ? prematchTotal() : (state.live ? safeInt(state.live.total, flattenLive(state.live).length) : 0);
  app.innerHTML = `${renderUnifiedTopbar(total)}
    <div id="goal-wait-notify-strip">${isPre ? "" : renderGoalWaitNotifyStrip()}</div>
    <div id="match-feed">${isPre ? renderPrematchFeedInner() : renderMatchFeedInner()}</div>
    ${renderBottomNav("matches")}${isPre ? "" : renderSheet()}`;
  bindMatchHandlers();
};

const _v9RefreshFeed = refreshMatchFeedOnly;
refreshMatchFeedOnly = function refreshMatchFeedOnlyV10(opts = {}) {
  if (state.feedMode !== "prematch") return _v9RefreshFeed(opts);
  const node = document.getElementById("match-feed");
  if (!node) return;
  node.innerHTML = renderPrematchFeedInner();
  bindMatchHandlers();
};

const _v9RefreshMatchesScreenOnly = refreshMatchesScreenOnly;
refreshMatchesScreenOnly = function refreshMatchesScreenOnlyV10(opts = {}) {
  if (state.feedMode !== "prematch") return _v9RefreshMatchesScreenOnly(opts);
  render();
};

const _v9FindCurrentMatchById = findCurrentMatchById;
findCurrentMatchById = function findCurrentMatchByIdV10(id) {
  const found = _v9FindCurrentMatchById(id);
  if (found) return found;
  const key = String(id || "");
  return flattenPrematch(state.prematch).find(m => String(m.id) === key) || null;
};

const _v9CurrentFeedIdsForNav = currentFeedIdsForNav;
currentFeedIdsForNav = function currentFeedIdsForNavV10() {
  if (state.view === "matches" && state.feedMode === "prematch") {
    const rows = visibleMatchRowIds();
    return rows.length ? rows : uniqueIds(filteredPrematches().map(m => m.id));
  }
  return _v9CurrentFeedIdsForNav();
};

function prematchOddsCard(odds) {
  const eu = odds?.eu || {};
  const bs = odds?.bs || {};
  const corners = odds?.corners || {};
  if (!odds || !Object.keys(odds).length) return `<div class="prematch-info-card"><div class="prematch-card-title">Коэффициенты</div><div class="prematch-empty-text">Пока не опубликованы.</div></div>`;
  const cell = (label, value) => `<div class="odds-box"><span>${esc(label)}</span><b>${value == null ? "—" : esc(value)}</b></div>`;
  return `<div class="prematch-info-card"><div class="prematch-card-title">Коэффициенты до матча</div>
    <div class="prematch-odds-grid">${cell("П1", eu["1"])}${cell("X", eu.X)}${cell("П2", eu["2"])}</div>
    <div class="prematch-market-row"><span>Тотал голов <b>${esc(bs.line ?? "—")}</b></span><span>Б ${esc(bs.over ?? "—")}</span><span>М ${esc(bs.under ?? "—")}</span></div>
    <div class="prematch-market-row"><span>Угловые <b>${esc(corners.line ?? "—")}</b></span><span>Б ${esc(corners.over ?? "—")}</span><span>М ${esc(corners.under ?? "—")}</span></div>
  </div>`;
}

function formPills(form) {
  const arr = Array.isArray(form) ? form : [];
  return arr.map(x => `<span class="prematch-form-pill ${String(x).toLowerCase()}">${esc(x)}</span>`).join("") || `<span class="muted-text">—</span>`;
}

function recentSummaryCard(avg, side, teamName) {
  const data = avg?.[side] || {};
  const rows = Array.isArray(data.matches) ? data.matches.slice(0, 5) : [];
  return `<div class="prematch-info-card"><div class="prematch-card-title">Форма · ${esc(teamName)}</div>
    <div class="prematch-summary-line"><span>${safeInt(data.wins,0)}В</span><span>${safeInt(data.draws,0)}Н</span><span>${safeInt(data.losses,0)}П</span><span>ср. тотал <b>${data.total_avg ?? "—"}</b></span></div>
    <div class="prematch-recent-list">${rows.length ? rows.map(r => `<div><span>${esc(r.date || "")}</span><b>${esc(r.home || "")} ${safeInt(r.score_home)}:${safeInt(r.score_away)} ${esc(r.away || "")}</b><em class="${String(r.result||"").toLowerCase()}">${esc(r.result || "")}</em></div>`).join("") : `<span class="prematch-empty-text">Последние матчи недоступны.</span>`}</div>
  </div>`;
}

function renderPrematchOverview(d, m) {
  const v = d.venue || {};
  const table = Array.isArray(d.standings) ? d.standings : [];
  const homeRow = table.find(x => x.is_home) || table.find(x => String(x.team || "").toLowerCase() === String(m.home || "").toLowerCase());
  const awayRow = table.find(x => x.is_away) || table.find(x => String(x.team || "").toLowerCase() === String(m.away || "").toLowerCase());
  return `${prematchOddsCard(d.odds || {})}
    <div class="prematch-info-card"><div class="prematch-card-title">Информация о матче</div>
      <div class="prematch-info-lines"><div><span>Начало</span><b>${formatPrematchKickoff(m, true)}</b></div><div><span>Турнир</span>${m.competition_path ? `<button type="button" class="prematch-inline-link" onclick="return openCompetition(decodeURIComponent('${encodeURIComponent(m.competition_path)}'),decodeURIComponent('${encodeURIComponent(m.league||"")}'),event,'detail')">${esc(m.league || "—")} ›</button>` : `<b>${esc(m.league || "—")}</b>`}</div><div><span>Стадион</span><b>${esc([v.name,v.city].filter(Boolean).join(", ") || "—")}</b></div>${v.capacity ? `<div><span>Вместимость</span><b>${safeInt(v.capacity).toLocaleString("ru-RU")}</b></div>` : ""}</div>
    </div>
    <div class="prematch-position-grid">
      <div class="prematch-info-card team-position"><div class="prematch-card-title">${esc(m.home)}</div><strong>${homeRow ? `${homeRow.position} место` : "—"}</strong><span>${homeRow ? `${homeRow.points} очк. · ${homeRow.played} игр` : "Таблица недоступна"}</span><div class="prematch-form">${formPills(homeRow?.form)}</div></div>
      <div class="prematch-info-card team-position"><div class="prematch-card-title">${esc(m.away)}</div><strong>${awayRow ? `${awayRow.position} место` : "—"}</strong><span>${awayRow ? `${awayRow.points} очк. · ${awayRow.played} игр` : "Таблица недоступна"}</span><div class="prematch-form">${formPills(awayRow?.form)}</div></div>
    </div>
    ${recentSummaryCard(d.avg || {}, "home", m.home)}${recentSummaryCard(d.avg || {}, "away", m.away)}
    ${renderSportScoreAttribution()}`;
}

function renderPrematchH2H(d) {
  const h = d.h2h || {};
  const rows = Array.isArray(h.meetings) ? h.meetings : [];
  return `<div class="prematch-info-card"><div class="prematch-card-title">Личные встречи</div>
    <div class="h2h-summary"><div><b>${safeInt(h.home_wins)}</b><span>Победы хозяев</span></div><div><b>${safeInt(h.draws)}</b><span>Ничьи</span></div><div><b>${safeInt(h.away_wins)}</b><span>Победы гостей</span></div></div>
    <div class="h2h-total">Всего встреч: <b>${safeInt(h.total, rows.length)}</b></div>
    <div class="h2h-list">${rows.length ? rows.map(r => `<div><span>${esc(r.date || "")}</span><b>${esc(r.home || "")}</b><strong>${safeInt(r.score_home)} : ${safeInt(r.score_away)}</strong><b>${esc(r.away || "")}</b></div>`).join("") : `<div class="prematch-empty-text">История встреч не найдена.</div>`}</div>
  </div>${renderSportScoreAttribution()}`;
}

function renderPrematchStandings(d) {
  const rows = Array.isArray(d.standings) ? d.standings : [];
  return `<div class="prematch-info-card standings-card"><div class="prematch-card-title">Турнирная таблица</div>
    <div class="prematch-table-wrap"><table class="prematch-table"><thead><tr><th>#</th><th>Команда</th><th>И</th><th>В</th><th>Н</th><th>П</th><th>РМ</th><th>О</th><th>Форма</th></tr></thead><tbody>
      ${rows.map(r => `<tr class="${r.is_home ? "current-home" : r.is_away ? "current-away" : ""}"><td>${safeInt(r.position)}</td><td class="team-cell">${r.logo ? `<img src="${esc(r.logo)}" alt=""/>` : ""}<span>${esc(r.team || "")}</span></td><td>${safeInt(r.played)}</td><td>${safeInt(r.wins)}</td><td>${safeInt(r.draws)}</td><td>${safeInt(r.losses)}</td><td>${esc(r.goal_difference ?? "")}</td><td><b>${safeInt(r.points)}</b></td><td><div class="prematch-form nowrap">${formPills(r.form)}</div></td></tr>`).join("")}
    </tbody></table></div>${rows.length ? "" : `<div class="prematch-empty-text">Таблица пока недоступна.</div>`}</div>${renderSportScoreAttribution()}`;
}

function renderLineupSide(title, formation, players, coach) {
  const list = Array.isArray(players) ? players : [];
  return `<div class="lineup-side"><div class="lineup-side-head"><b>${esc(title)}</b><span>${esc(formation || "Схема —")}</span></div>
    <div class="lineup-player-list-v10">${list.map(p => `<div><span class="shirt">${safeInt(p.number) || "—"}</span><b>${esc(lineupShortName(p.name || p.player_name || p.full_name || ""))}</b></div>`).join("") || `<span class="prematch-empty-text">Нет данных</span>`}</div>
    ${coach ? `<div class="lineup-coach-v10">Тренер: <b>${esc(coach)}</b></div>` : ""}</div>`;
}

function renderPrematchLineups(d, m) {
  const l = d.lineups || {};
  if (!l.announced) return `<div class="prematch-info-card lineups-wait"><div class="lineups-ball">⚽</div><div class="prematch-card-title">${esc(l.message || "Составы ещё не объявлены")}</div><p>${esc(l.submessage || "Обычно составы появляются примерно за час до начала матча.")}</p></div>${renderSportScoreAttribution()}`;
  return `<div class="prematch-info-card"><div class="prematch-card-title">${l.confirmed ? "Подтверждённые составы" : "Предварительные составы"}</div><div class="lineups-grid-v10">${renderLineupSide(m.home,l.home_formation,l.home,l.home_coach)}${renderLineupSide(m.away,l.away_formation,l.away,l.away_coach)}</div></div>${renderSportScoreAttribution()}`;
}

function setPrematchDetailTab(tab) {
  state.prematchDetailTab = ["overview","h2h","standings","lineups"].includes(tab) ? tab : "overview";
  render();
}

function renderPrematchDetail() {
  const d = state.detail || {};
  const m = d.match || {};
  const fav = isFav(m.id);
  const tab = ["overview","h2h","standings","lineups"].includes(state.prematchDetailTab) ? state.prematchDetailTab : "overview";
  const content = tab === "h2h" ? renderPrematchH2H(d) : tab === "standings" ? renderPrematchStandings(d) : tab === "lineups" ? renderPrematchLineups(d,m) : renderPrematchOverview(d,m);
  app.innerHTML = `<div class="detail-screen prematch-detail-screen">
    <div class="detail-topbar"><button class="back-btn" onclick="goBack()">‹</button>${m.competition_path ? `<button type="button" class="detail-breadcrumb detail-competition-link" onclick="return openCompetition(decodeURIComponent('${encodeURIComponent(m.competition_path)}'),decodeURIComponent('${encodeURIComponent(m.league||"")}'),event,'detail')">${leagueHeaderIcon({country_code:m.country_code,country:m.country,league:m.league})} ${esc(m.country || "")} · ${esc(m.league || "")} ›</button>` : `<div class="detail-breadcrumb">${leagueHeaderIcon({country_code:m.country_code,country:m.country,league:m.league})} ${esc(m.country || "")} · ${esc(m.league || "")}</div>`}<button class="star-btn ${fav ? "active" : ""}" onclick="toggleFavWithGoalPrompt('${esc(m.id)}')">${fav ? "★" : "☆"}</button></div>
    ${renderDetailSwipeHud()}
    <div class="prematch-scoreboard">${renderPrematchTeamCard(m,"home")}<div class="prematch-center"><span>${formatPrematchKickoff(m,true)}</span><b>VS</b><em>До начала</em></div>${renderPrematchTeamCard(m,"away")}</div>
    <div class="detail-tabs prematch-tabs"><button class="tab-btn ${tab === "overview" ? "active" : ""}" onclick="setPrematchDetailTab('overview')">Обзор</button><button class="tab-btn ${tab === "h2h" ? "active" : ""}" onclick="setPrematchDetailTab('h2h')">H2H</button><button class="tab-btn ${tab === "standings" ? "active" : ""}" onclick="setPrematchDetailTab('standings')">Таблица</button><button class="tab-btn ${tab === "lineups" ? "active" : ""}" onclick="setPrematchDetailTab('lineups')">Составы</button></div>
    <div class="detail-tab-content prematch-detail-content">${content}</div>${renderDetailToast()}</div>`;
  bindDetailSwipeHandlers();
}

const _v9RenderDetail = renderDetail;
renderDetail = function renderDetailV10() {
  if (state.detail && state.detail.ok && state.detail.provider === "sportscore" && state.detail.prematch) return renderPrematchDetail();
  _v9RenderDetail();
  const screen = app.querySelector(".detail-screen");
  if (screen && !screen.querySelector(".sportscore-attribution")) screen.insertAdjacentHTML("beforeend", renderSportScoreAttribution());
};


function renderSoftPreserveScroll() {
  const y = currentScrollY();
  const minHeight = app.offsetHeight;
  if (minHeight > 0) app.style.minHeight = `${minHeight}px`;
  app.classList.add("soft-refreshing");
  render();
  requestAnimationFrame(() => {
    window.scrollTo({ top: y, left: 0, behavior: "auto" });
    requestAnimationFrame(() => {
      app.classList.remove("soft-refreshing");
      app.style.minHeight = "";
    });
  });
}

async function refreshDetailSilently() {
  if (state.view !== "detail" || !state.selectedMatch || state.sheet) return;
  const selectedId = String(state.selectedMatch || "");
  try {
    // V10.33: Live clock and full detail are requested concurrently instead of
    // waiting for /api/live before starting /api/match.
    const [liveResult, detailResult] = await Promise.allSettled([
      fetch(`/api/live?sport=football`, { cache: "no-store" }).then(r => r.json()),
      fetch(`/api/match?id=${encodeURIComponent(selectedId)}`, { cache: "no-store" }).then(r => r.json()),
    ]);
    if (state.view !== "detail" || String(state.selectedMatch || "") !== selectedId) return;
    if (liveResult.status === "fulfilled" && liveResult.value?.ok) {
      state.live = liveResult.value;
      if (state.liveBySport) state.liveBySport.football = liveResult.value;
      saveFastLiveCache(liveResult.value);
    }
    if (detailResult.status === "fulfilled" && detailResult.value?.ok) {
      let payload = syncDetailPayloadWithLive(detailResult.value);
      payload = attachClientPressure(payload);
      state.detail = payload;
      saveFastDetailCache(selectedId, payload);
      renderSoftPreserveScroll();
    }
  } catch (_) {}
}

// ============================================================
//  Auto-refresh + boot
// ============================================================
async function bootApp() {
  const allowed = await checkOnlineGate(true);
  if (!allowed) return;
  startOnlineHeartbeat();
  syncCurrentNotifyStateToServer();
  try {
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) {
        checkOnlineGate(false);
        syncCurrentNotifyStateToServer();
      }
    });
    window.addEventListener("pagehide", () => syncCurrentNotifyStateToServer({ beacon: true, keepalive: true }));
    window.addEventListener("beforeunload", () => syncCurrentNotifyStateToServer({ beacon: true, keepalive: true }));
  } catch (_) {}
  loadLive(false);
  loadPrematch(false);
  setTimeout(() => openStartupMatchIfAny(), 250);
  setInterval(() => {
    if (state.onlineGate.allowed && !["detail","team"].includes(state.view) && !state.sheet) loadLive(false);
  }, LIVE_POLL_INTERVAL_MS);
  setInterval(() => {
    if (state.onlineGate.allowed) refreshDetailSilently();
  }, DETAIL_POLL_INTERVAL_MS);
  setInterval(() => {
    if (state.onlineGate.allowed && !document.hidden && !state.sheet) loadPrematch(false);
  }, PREMATCH_POLL_INTERVAL_MS);
}

// ============================================================================
// v10.15 · Multi-sport UI (football / basketball / tennis)
// ============================================================================
const SPORT_META = {
  football: { label: "Футбол", short: "Футбол", icon: "⚽", participant: "Команда" },
  basketball: { label: "Баскетбол", short: "Баскетбол", icon: "🏀", participant: "Команда" },
  tennis: { label: "Теннис", short: "Теннис", icon: "🎾", participant: "Игрок" },
};
try {
  const savedSport = localStorage.getItem("miniapp-v10-active-sport") || "football";
  state.sport = SPORT_META[savedSport] ? savedSport : "football";
} catch (_) { state.sport = "football"; }
state.liveBySport = { football: state.live, basketball: null, tennis: null };
state.prematchBySport = { football: state.prematch, basketball: null, tennis: null };
state.mainTab = "all";
const _liveSportInFlight = new Set();
const _prematchSportInFlight = new Set();
try {
  localStorage.setItem(GOAL_WAIT_NOTIFY_ENABLED_KEY, "0");
  localStorage.setItem(GOAL_WAIT_AUTO_GOAL_ENABLED_KEY, "0");
} catch (_) {}

function activeSportMeta() { return SPORT_META[state.sport] || SPORT_META.football; }
function sportQuery(force = false) {
  const p = new URLSearchParams({ sport: state.sport });
  if (force) p.set("force", "1");
  return p.toString();
}
function renderSportTabs() {
  return `<div class="sport-switcher" role="tablist" aria-label="Вид спорта">${Object.entries(SPORT_META).map(([key, meta]) => `<button type="button" class="sport-switch ${state.sport === key ? "active" : ""}" onclick="setSport('${key}')"><span>${meta.icon}</span><b>${meta.short}</b></button>`).join("")}</div>`;
}
function setSport(sport) {
  const next = SPORT_META[sport] ? sport : "football";
  if (next === state.sport) return;
  saveMatchListPosition();
  state.liveBySport[state.sport] = state.live;
  state.prematchBySport[state.sport] = state.prematch;
  state.sport = next;
  state.live = state.liveBySport[next] || null;
  state.prematch = state.prematchBySport[next] || null;
  state.loading = !state.live;
  state.prematchLoading = false;
  state.search = "";
  state.mainTab = "all";
  state.sheet = null;
  try { localStorage.setItem("miniapp-v10-active-sport", next); } catch (_) {}
  render();
  loadLive(false);
  loadPrematch(false);
  window.scrollTo({ top: 0, left: 0, behavior: "auto" });
}

loadLive = async function loadLiveMultiSport(force = false) {
  const requestSport = state.sport;
  if (_liveSportInFlight.has(requestSport)) return;
  _liveSportInFlight.add(requestSport);
  _loadLiveInFlight = true;
  const preserveMatchScroll = state.view === "matches" && !state.sheet;
  if (preserveMatchScroll) saveMatchListPosition();
  try {
    const res = await fetch(`/api/live?${sportQuery(force)}`, { cache: "no-store" });
    const payload = await res.json();
    state.liveBySport[requestSport] = payload;
    if (state.sport === requestSport) state.live = payload;
    if (requestSport === "football") {
      try { refreshFavCacheFromLive(flattenLive(payload)); } catch (_) {}
    }
  } catch (err) {
    const payload = { ok: false, total: 0, countries: [], sport: requestSport, error: String(err) };
    state.liveBySport[requestSport] = payload;
    if (state.sport === requestSport) state.live = payload;
  } finally {
    if (state.sport === requestSport) {
      state.loading = false;
      if (maybeRestoreLastOpenedDetail()) { _loadLiveInFlight = false; return; }
      if (preserveMatchScroll && document.getElementById("match-feed")) {
        refreshMatchesScreenOnly({ preserveHeight: true });
        restoreMatchListPosition();
      } else {
        render();
        if (preserveMatchScroll) restoreMatchListPosition();
      }
    }
    _liveSportInFlight.delete(requestSport);
    _loadLiveInFlight = _liveSportInFlight.size > 0;
    // If the user changed sport while this request was running, make sure the
    // newly selected sport is not left with an empty screen.
    if (state.sport !== requestSport && !state.liveBySport[state.sport] && !_liveSportInFlight.has(state.sport)) {
      setTimeout(() => loadLive(false), 0);
    }
  }
};

loadPrematch = async function loadPrematchMultiSport(force = false) {
  const requestSport = state.sport;
  if (_prematchSportInFlight.has(requestSport)) return;
  _prematchSportInFlight.add(requestSport);
  _loadPrematchInFlight = true;
  const preserve = state.view === "matches" && state.feedMode === "prematch" && !state.sheet;
  if (preserve) saveMatchListPosition();
  state.prematchLoading = !state.prematchBySport[requestSport];
  if (preserve) render();
  try {
    const p = new URLSearchParams({ sport: requestSport });
    if (force) p.set("force", "1");
    const res = await fetch(`/api/prematch?${p.toString()}`, { cache: "no-store" });
    const payload = await res.json();
    if (!res.ok) throw new Error(payload?.error || `HTTP ${res.status}`);
    state.prematchBySport[requestSport] = payload;
    if (state.sport === requestSport) state.prematch = payload;
  } catch (err) {
    const previous = state.prematchBySport[requestSport];
    if (!previous || !flattenPrematch(previous).length) {
      const payload = { ok: false, total: 0, countries: [], sport: requestSport, error: String(err) };
      state.prematchBySport[requestSport] = payload;
      if (state.sport === requestSport) state.prematch = payload;
    }
  } finally {
    if (state.sport === requestSport) {
      state.prematchLoading = false;
      if (state.view === "matches" && state.feedMode === "prematch") {
        render();
        if (preserve) restoreMatchListPosition();
      }
    }
    _prematchSportInFlight.delete(requestSport);
    _loadPrematchInFlight = _prematchSportInFlight.size > 0;
    if (state.sport !== requestSport && !state.prematchBySport[state.sport] && !_prematchSportInFlight.has(state.sport)) {
      setTimeout(() => loadPrematch(false), 0);
    }
  }
};

renderMainFeedTabs = function renderMainFeedTabsRemoved() { return ""; };
renderGoalWaitNotifyStrip = function renderGoalWaitNotifyStripRemoved() { return ""; };
setMainTab = function setMainTabRemoved() { state.mainTab = "all"; };

filteredMatches = function filteredMatchesMultiSport() {
  let arr = flattenLive(state.live);
  if (state.sport === "football") arr = arr.filter(m => matchPassesFilter(m, state.filters));
  const q = String(state.search || "").trim().toLowerCase();
  if (q) arr = arr.filter(m => [m.home, m.away, m.league, m.country].some(v => String(v || "").toLowerCase().includes(q)));
  return arr;
};

function sportStatusText(m) {
  const raw = String(m?.minute_text || m?.period || "").trim();
  if (m?.finished) return "ЗАВЕРШЁН";
  if (raw) return raw;
  return m?.is_live ? "LIVE" : "СКОРО";
}
function scorePartsInline(m) {
  const parts = Array.isArray(m?.score_parts) ? m.score_parts.slice(-5) : [];
  if (!parts.length) return "";
  return `<div class="sport-score-parts">${parts.map(p => `<span>${esc(p.label || "")}: <b>${safeInt(p.home)}-${safeInt(p.away)}</b></span>`).join("")}</div>`;
}

renderMatchRow = function renderMatchRowMultiSport(m) {
  const fav = isFav(m.id);
  const isFinished = m.finished === true;
  const sh = safeInt(m.score_home);
  const sa = safeInt(m.score_away);
  const football = state.sport === "football";
  const heat = football ? matchHeatTone(m) : { cls: "", score: 0 };
  const status = sportStatusText(m);
  const alertBlock = football ? renderNotifyReasonBlock(m) : "";
  return `<div class="match-row sport-${esc(state.sport)}${isFinished ? " finished" : ""}${heat.cls ? ` ${heat.cls}` : ""}" data-id="${esc(m.id)}" data-sport="${esc(state.sport)}" data-heat-score="${heat.score}">
    <span class="match-heat-edge" aria-hidden="true"></span>
    <div class="match-minute ${isFinished ? "finished" : ""}">${esc(status)}</div>
    <div class="match-teams">
      <div class="match-team-line">${teamLogoSmall(m, "home")}<div class="match-team">${esc(m.home)}</div></div>
      <div class="match-team-line">${teamLogoSmall(m, "away")}<div class="match-team">${esc(m.away)}</div></div>
      ${scorePartsInline(m)}${alertBlock}
    </div>
    <div class="match-score"><div class="match-score-row ${sh > 0 ? "scored" : ""}">${sh}</div><div class="match-score-row ${sa > 0 ? "scored" : ""}">${sa}</div></div>
    <button class="star-btn ${fav ? "active" : ""}" data-fav="${esc(m.id)}" title="${fav ? "Убрать" : "В избранное"}">${fav ? "★" : "☆"}</button>
  </div>`;
};

renderPrematchOddsMini = function renderPrematchOddsMiniMultiSport(m) {
  const eu = m?.odds?.eu || {};
  if (state.sport === "football" && (eu["1"] != null || eu.X != null || eu["2"] != null)) {
    return `<div class="prematch-odds-mini"><span>П1 <b>${esc(eu["1"] ?? "—")}</b></span><span>X <b>${esc(eu.X ?? "—")}</b></span><span>П2 <b>${esc(eu["2"] ?? "—")}</b></span></div>`;
  }
  if (eu["1"] != null || eu["2"] != null) return `<div class="prematch-odds-mini"><span>1 <b>${esc(eu["1"] ?? "—")}</b></span><span>2 <b>${esc(eu["2"] ?? "—")}</b></span></div>`;
  return `<div class="prematch-odds-mini muted">Статистика в карточке</div>`;
};

renderUnifiedTopbar = function renderUnifiedTopbarMultiSport(total) {
  const isPre = state.feedMode === "prematch";
  const q = esc(state.search || "");
  const hasQ = !!String(state.search || "").trim();
  const meta = activeSportMeta();
  return `<div class="topbar unified-topbar">
    ${renderSportTabs()}
    ${renderFeedModeTabs()}
    <div class="topbar-row">
      <div class="live-status ${isPre ? "prematch-status" : ""}">${isPre ? `<span class="prematch-clock">◷</span><span class="live-label">ПРЕМАТЧ</span>` : `<div class="live-dot"></div><span class="live-label">LIVE</span>`}</div>
      <span class="live-count">· ${total} матчей</span>
      <div class="topbar-actions">
        <button class="icon-btn" onclick="${isPre ? "loadPrematch(true)" : "loadLive(true)"}" title="Обновить"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg></button>
        ${!isPre && state.sport === "football" ? `<button class="icon-btn accent" onclick="openSheet('filters')" title="Фильтры"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="7" y1="12" x2="17" y2="12"/><line x1="10" y1="18" x2="14" y2="18"/></svg></button>` : ""}
      </div>
    </div>
    ${isPre ? renderPrematchDateTabs() : ""}
    <div class="search-row"><span class="search-icon" aria-hidden="true"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span><input type="text" inputmode="search" autocomplete="off" autocorrect="off" spellcheck="false" class="search-input" id="match-search-input" placeholder="Поиск: ${esc(meta.participant.toLowerCase())}, турнир, страна…" value="${q}" oninput="onSearchInput(this.value)" />${hasQ ? `<button class="search-clear" onclick="clearSearch()" aria-label="Очистить">×</button>` : ""}</div>
  </div>`;
};

renderMatches = function renderMatchesMultiSport() {
  const isPre = state.feedMode === "prematch";
  const total = isPre ? prematchTotal() : (state.live ? safeInt(state.live.total, flattenLive(state.live).length) : 0);
  app.innerHTML = `${renderUnifiedTopbar(total)}<div id="match-feed">${isPre ? renderPrematchFeedInner() : renderMatchFeedInner()}</div>${renderBottomNav("matches")}${!isPre && state.sport === "football" ? renderSheet() : ""}`;
  bindMatchHandlers();
};
refreshMatchesScreenOnly = function refreshMatchesScreenOnlyMultiSport() {
  const y = currentScrollY();
  render();
  requestAnimationFrame(() => window.scrollTo({ top: y, left: 0, behavior: "auto" }));
};

const _footballRenderDetailMulti = renderDetail;
function renderParticipantPortrait(m, side) {
  const logo = String(m?.[`${side}_logo`] || "").trim();
  const name = String(m?.[side] || "");
  const content = `<div class="other-sport-logo ${logo ? "" : "logo-error"}">${logo ? `<img src="${esc(logo)}" alt="${esc(name)}" onerror="this.parentElement.classList.add('logo-error')"/>` : ""}<span>${esc(initials(name))}</span></div><b>${esc(name)}</b>${m?.sport === "basketball" ? `<em>Статистика ›</em>` : ""}`;
  if (m?.sport === "basketball" && String(m?.[`${side}_id`] || "").trim()) return `<button type="button" class="other-sport-participant clickable" onclick="return openPrematchTeamStats('${side}',event)" title="Статистика команды ${esc(name)}">${content}</button>`;
  return `<div class="other-sport-participant">${content}</div>`;
}
function renderOtherSportParts(d, m) {
  const matchSport = String(m?.sport || state.sport || "football");
  const meta = SPORT_META[matchSport] || activeSportMeta();
  const parts = Array.isArray(d?.score_parts) && d.score_parts.length ? d.score_parts : (Array.isArray(m?.score_parts) ? m.score_parts : []);
  if (!parts.length) return `<div class="other-sport-empty">Разбивка по ${matchSport === "basketball" ? "четвертям" : "сетам"} пока недоступна.</div>`;
  return `<div class="other-sport-parts"><div class="other-sport-parts-head"><span>${esc(meta.participant)}</span>${parts.map(p => `<b>${esc(p.label || "")}</b>`).join("")}<strong>Итог</strong></div><div><span>${esc(m.home)}</span>${parts.map(p => `<b>${safeInt(p.home)}</b>`).join("")}<strong>${safeInt(m.score_home)}</strong></div><div><span>${esc(m.away)}</span>${parts.map(p => `<b>${safeInt(p.away)}</b>`).join("")}<strong>${safeInt(m.score_away)}</strong></div></div>`;
}
function sportStatLabel(label, sport = "basketball") {
  const raw = String(label || "Показатель").trim();
  const key = raw.toLowerCase().replace(/[_-]+/g," ").replace(/\s+/g," ");
  const map = {
    "total points":"Всего очков", "points":"Очки", "q1 points":"1-я четверть", "q2 points":"2-я четверть", "q3 points":"3-я четверть", "q4 points":"4-я четверть", "ot1 points":"Овертайм",
    "field goals":"Броски с игры", "field goals made":"Попадания с игры", "field goal percentage":"Точность бросков",
    "2 pointers":"2-очковые", "two pointers":"2-очковые", "3 pointers":"3-очковые", "three pointers":"3-очковые",
    "free throws":"Штрафные", "rebounds":"Подборы", "total rebounds":"Подборы", "offensive rebounds":"Подборы в атаке", "defensive rebounds":"Подборы в защите",
    "assists":"Передачи", "turnovers":"Потери", "steals":"Перехваты", "blocks":"Блок-шоты", "fouls":"Фолы", "personal fouls":"Фолы",
    "sets won":"Выиграно сетов", "s1 games":"1-й сет", "s2 games":"2-й сет", "s3 games":"3-й сет", "s4 games":"4-й сет", "s5 games":"5-й сет",
    "aces":"Эйсы", "double faults":"Двойные ошибки", "first serve":"Первая подача", "break points won":"Реализованные брейк-пойнты"
  };
  return map[key] || raw.replace(/\bq([1-4])\b/i, (_,n)=>`${n}-я четверть`).replace(/\bs([1-5])\b/i, (_,n)=>`${n}-й сет`);
}
function sportStatNumber(value) {
  const n = Number(String(value ?? "").replace("%","").replace(",","."));
  return Number.isFinite(n) ? n : null;
}
function renderOtherSportStats(d, m) {
  let rows = Array.isArray(d?.sport_stats) ? [...d.sport_stats] : [];
  const parts = Array.isArray(d?.score_parts) && d.score_parts.length ? d.score_parts : (Array.isArray(m?.score_parts) ? m.score_parts : []);
  const derived = [{ label: m?.sport === "tennis" ? "Sets Won" : "Total Points", home: safeInt(m?.score_home), away: safeInt(m?.score_away) }, ...parts.map(p => ({label:`${p.label || ""} ${m?.sport === "tennis" ? "Games" : "Points"}`,home:p.home,away:p.away}))];
  const seen = new Set(rows.map(r => String(r?.label || "").toLowerCase()));
  for (const row of derived) if (!seen.has(String(row.label || "").toLowerCase())) rows.push(row);
  rows = rows.filter(r => r && (r.home !== undefined || r.away !== undefined)).slice(0,40);
  if (!rows.length) return `<div class="other-sport-empty">Статистика этого матча пока недоступна.</div>`;
  return `<div class="other-sport-stat-list enhanced">${rows.map(r => {
    const home = r.home ?? "—", away = r.away ?? r.value ?? "—";
    const hn = sportStatNumber(home), an = sportStatNumber(away), total = Math.max(1,(hn||0)+(an||0));
    const hp = hn == null ? 50 : Math.max(4,Math.min(96,Math.round((hn/total)*100)));
    const ap = an == null ? 50 : Math.max(4,Math.min(96,Math.round((an/total)*100)));
    return `<div class="other-sport-stat-row"><div class="other-sport-stat-values"><b>${esc(home)}</b><span>${esc(sportStatLabel(r.label,m?.sport))}</span><b>${esc(away)}</b></div><div class="other-sport-stat-bars"><i style="width:${hp}%"></i><i style="width:${ap}%"></i></div></div>`;
  }).join("")}</div>`;
}
function renderOtherSportDetail() {
  const d = state.detail || {};
  const m = d.match || {};
  const meta = SPORT_META[String(m.sport || state.sport)] || activeSportMeta();
  const fav = isFav(m.id);
  const tab = state.detailTab === "stats" ? "stats" : "details";
  const scheduled = d.prematch || (!m.is_live && !m.finished);
  const centerLabel = scheduled ? formatPrematchKickoff(m, true) : sportStatusText(m);
  const content = tab === "stats" ? renderOtherSportStats(d, m) : `${renderOtherSportParts(d, m)}${d.odds && Object.keys(d.odds).length ? renderOddsSection(d.odds, d.prematch_odds || {}, d.odds_movement || {}, !!m.is_live) : ""}<div class="other-sport-info"><div><span>Турнир</span><b>${esc(m.league || "—")}</b></div><div><span>Страна</span><b>${esc(m.country || "—")}</b></div><div><span>Статус</span><b>${esc(centerLabel)}</b></div></div>`;
  app.innerHTML = `<div class="detail-screen other-sport-detail sport-${esc(m.sport || state.sport)}"><div class="detail-topbar"><button class="back-btn" onclick="goBack()">‹</button><div class="detail-breadcrumb">${meta.icon} ${esc(m.country || "")} · ${esc(m.league || meta.label)}</div><button class="star-btn ${fav ? "active" : ""}" onclick="toggleFavWithGoalPrompt('${esc(m.id)}')">${fav ? "★" : "☆"}</button></div>${renderDetailSwipeHud()}<div class="other-sport-scoreboard">${renderParticipantPortrait(m,"home")}<div class="other-sport-center"><div class="big-score">${scheduled ? "VS" : `${safeInt(m.score_home)} : ${safeInt(m.score_away)}`}</div><div class="live-pill${m.finished ? " finished" : ""}">${esc(centerLabel)}</div></div>${renderParticipantPortrait(m,"away")}</div><div class="detail-tabs"><button class="tab-btn ${tab === "details" ? "active" : ""}" onclick="setDetailTab('details')">Обзор</button><button class="tab-btn ${tab === "stats" ? "active" : ""}" onclick="setDetailTab('stats')">Статистика</button></div><div class="detail-tab-content other-sport-content">${content}${renderSportScoreAttribution()}</div>${renderDetailToast()}</div>`;
  bindDetailSwipeHandlers();
}
renderDetail = function renderDetailMultiSport() {
  const sport = String(state.detail?.match?.sport || state.detail?.sport || "football");
  if (state.detail && state.detail.ok && sport !== "football") return renderOtherSportDetail();
  return _footballRenderDetailMulti();
};
renderDetailDetailsContent = function renderDetailDetailsContentNoGoalWait(d, m, s) {
  const oddsHtml = renderOddsSection(d.odds || {}, d.prematch_odds || {}, d.odds_movement || {}, !!m.is_live) || `<div class="detail-tab-empty">КФ пока нет.</div>`;
  return `${oddsHtml}${renderPressureChartFull(d)}${renderMatchEvents(d.events || [], m)}${renderLiveLineups(d, m)}${renderMatchAbsences(d, m)}`;
};

toggleFavWithGoalPrompt = async function toggleFavWithoutGoalPrompt(id) {
  const key = String(id || "");
  if (!key) return;
  toggleFav(key);
  render();
};
renderNotifyReasonBlock = function renderNotifyReasonBlockNoGoalWait(m) {
  const kind = String(m?.alert_kind || "").toLowerCase();
  if (kind === "goal_wait") return "";
  const score = safeInt(m?.alert_score || m?.filter_score, 0);
  const reasons = normalizeAlertReasons(m?.alert_reasons || m?.alert_reason || m?.filter_reasons || m?.filter_reason || []);
  if (!score && !reasons.length) return "";
  const label = kind === "goal" ? "Гол" : "Фильтр";
  const tone = score >= 85 ? "hot" : score >= 70 ? "good" : "ok";
  return `<div class="match-alert-analysis ${tone}">${score ? `<span class="match-alert-score"><b>${score}</b>/100</span>` : ""}<span class="match-alert-label">${esc(label)}</span>${reasons.length ? `<span class="match-alert-reason">Причина: ${esc(reasons.slice(0,5).join(" · "))}</span>` : ""}</div>`;
};
toggleNotifyEnabled = function toggleNotifyEnabledNoGoalWait() {
  const current = getNotifyFilter();
  const cfg = setOnlyNotifyProfileEnabled(getActiveNotifyProfile(), !current.enabled);
  syncNotifyFilterToServer(cfg, { keepalive: true, warn: true });
  if (cfg.enabled) checkNotifyMatches();
  render();
};
showMainFeedInfo = function showMainFeedInfoNoGoalWait() {
  const msg = ["Навигация и подсветка", "", "Выберите футбол, баскетбол или теннис в верхней панели.", "Live и прематчи загружаются отдельно для каждого спорта.", "В футбольных матчах подсветка показывает активность. Свайп в карточке переключает матчи текущей ленты."].join("\n");
  try { if (tg?.showAlert) return tg.showAlert(msg); } catch (_) {}
  alert(msg);
};

const _footballLoadDetailMulti = loadDetail;
loadDetail = async function loadDetailMultiSport(id, opts = {}) {
  if (state.sport === "football") return _footballLoadDetailMulti(id, opts);
  id = normalizeMatchId(id);
  if (!id) return;
  const row = findCurrentMatchById(id) || flattenLive(state.live).find(m => String(m.id) === String(id));
  if (!row) return;
  if (opts.returnView) state.detailReturnView = String(opts.returnView);
  else state.detailReturnView = "matches";
  state.selectedMatch = id;
  state.view = "detail";
  state.detailTab = "details";
  state.detail = { ok: true, sport: state.sport, match: { ...row, sport: state.sport }, prematch: !row.is_live && !row.finished, score_parts: row.score_parts || [], sport_stats: row.sport_stats || [], odds: row.odds || {} };
  render();
};

// v10.15: legacy fixed goal-wait mode is fully disabled.
isGoalWaitPushEnabled = function goalWaitRemoved() { return false; };
checkGoalWaitNotifyMatches = function goalWaitScanRemoved() {};
toggleGoalWaitNotifyEnabled = function goalWaitToggleRemoved() {};
toggleGoalWaitAutoGoalEnabled = function goalWaitAutoRemoved() {};
applyGoalWaitPreset = function goalWaitPresetRemoved() {};
showGoalWaitInfo = function goalWaitInfoRemoved() {};

window.setSport = setSport;


// ============================================================================
// v10.20 · LIVE ONLY MODE
// Prematch feed and tournament/league centre are removed from runtime/UI.
// ============================================================================
state.feedMode = "live";
state.prematch = null;
state.prematchLoading = false;
state.prematchBySport = { football: null, basketball: null, tennis: null };
state.competitionData = null;
state.competitionLoading = false;
state.competitionError = "";
try {
  localStorage.removeItem("miniapp-v10-feed-mode");
} catch (_) {}

loadPrematch = async function loadPrematchRemoved() { return null; };
setFeedMode = function setFeedModeLiveOnly() {
  state.feedMode = "live";
  try { localStorage.removeItem("miniapp-v10-feed-mode"); } catch (_) {}
};
setPrematchDate = function setPrematchDateRemoved() {};
setPrematchDetailTab = function setPrematchDetailTabRemoved() {};
openCompetition = function openCompetitionRemoved(_path, _name, event) {
  if (event) { event.preventDefault(); event.stopPropagation(); }
  return false;
};
loadCompetition = async function loadCompetitionRemoved() { return null; };
renderCompetitionView = function renderCompetitionRemoved() {
  state.view = "matches";
  render();
};

setSport = function setSportLiveOnly(sport) {
  const next = SPORT_META[sport] ? sport : "football";
  if (next === state.sport) return;
  saveMatchListPosition();
  state.liveBySport[state.sport] = state.live;
  state.sport = next;
  state.live = state.liveBySport[next] || null;
  state.loading = !state.live;
  state.search = "";
  state.mainTab = "all";
  state.sheet = null;
  state.feedMode = "live";
  try { localStorage.setItem("miniapp-v10-active-sport", next); } catch (_) {}
  render();
  loadLive(false);
  window.scrollTo({ top: 0, left: 0, behavior: "auto" });
};

filteredMatches = function filteredMatchesLiveOnly() {
  let arr = flattenLive(state.live).filter(m => m && m.is_live === true && m.finished !== true);
  if (state.sport === "football") arr = arr.filter(m => matchPassesFilter(m, state.filters));
  const q = String(state.search || "").trim().toLowerCase();
  if (q) arr = arr.filter(m => [m.home, m.away, m.league, m.country].some(v => String(v || "").toLowerCase().includes(q)));
  return arr;
};

renderUnifiedTopbar = function renderUnifiedTopbarLiveOnly(total) {
  const q = esc(state.search || "");
  const hasQ = !!String(state.search || "").trim();
  const meta = activeSportMeta();
  return `<div class="topbar unified-topbar live-only-topbar">
    ${renderSportTabs()}
    <div class="topbar-row">
      <div class="live-status"><div class="live-dot"></div><span class="live-label">LIVE</span></div>
      <span class="live-count">· ${total} матчей</span>
      <div class="topbar-actions">
        <button class="icon-btn" onclick="loadLive(true)" title="Обновить"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg></button>
        ${state.sport === "football" ? `<button class="icon-btn accent" onclick="openSheet('filters')" title="Фильтры"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="7" y1="12" x2="17" y2="12"/><line x1="10" y1="18" x2="14" y2="18"/></svg></button>` : ""}
      </div>
    </div>
    <div class="search-row"><span class="search-icon" aria-hidden="true"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span><input type="text" inputmode="search" autocomplete="off" autocorrect="off" spellcheck="false" class="search-input" id="match-search-input" placeholder="Поиск: ${esc(meta.participant.toLowerCase())}, лига, страна…" value="${q}" oninput="onSearchInput(this.value)" />${hasQ ? `<button class="search-clear" onclick="clearSearch()" aria-label="Очистить">×</button>` : ""}</div>
  </div>`;
};

renderMatches = function renderMatchesLiveOnly() {
  state.feedMode = "live";
  const total = filteredMatches().length;
  app.innerHTML = `${renderUnifiedTopbar(total)}<div id="match-feed">${renderMatchFeedInner()}</div>${renderSportScoreAttribution()}${renderBottomNav("matches")}${state.sport === "football" ? renderSheet() : ""}`;
  bindMatchHandlers();
};

const _renderOddsLiveOnlyBase = renderOddsSection;
renderOddsSection = function renderOddsLiveOnly(odds) {
  return _renderOddsLiveOnlyBase(odds || {}, {}, {}, true);
};

renderFavorites = function renderFavoritesLiveOnly() {
  const fav = getFavs();
  const liveById = currentLiveById();
  const merged = [];
  for (const k of fav) {
    const card = liveById.get ? liveById.get(String(k)) : liveById[String(k)];
    if (card && card.is_live === true && card.finished !== true) merged.push(card);
  }
  const groups = groupByLeague(merged);
  app.innerHTML = `<div class="topbar"><div class="topbar-row"><div class="live-status"><div class="live-dot"></div><span class="live-label">ИЗБРАННОЕ LIVE</span></div><span class="live-count">· ${merged.length}</span></div></div>${merged.length === 0 ? `<div class="fav-empty"><div class="fav-empty-icon">☆</div><div class="fav-empty-title">Нет избранных Live-матчей</div><div class="fav-empty-text">Добавьте текущий матч кнопкой ★. После завершения он исчезнет из этого раздела.</div></div>` : groups.map(renderLeagueGroup).join("")}${renderSportScoreAttribution()}${renderBottomNav("favorites")}`;
  bindMatchHandlers();
};

showMainFeedInfo = function showMainFeedInfoLiveOnly() {
  const msg = ["Live ZOT", "", "В приложении оставлены только текущие Live-матчи.", "Выберите футбол, баскетбол или теннис в верхней панели.", "Из матча можно открыть карточку команды, статистику и последние результаты."].join("\n");
  try { if (tg?.showAlert) return tg.showAlert(msg); } catch (_) {}
  alert(msg);
};

bootApp = async function bootAppLiveOnly() {
  const allowed = await checkOnlineGate(true);
  if (!allowed) return;
  startOnlineHeartbeat();
  syncCurrentNotifyStateToServer();
  try {
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) {
        checkOnlineGate(false);
        syncCurrentNotifyStateToServer();
        if (state.view === "matches") loadLive(false);
      }
    });
    window.addEventListener("pagehide", () => syncCurrentNotifyStateToServer({ beacon: true, keepalive: true }));
    window.addEventListener("beforeunload", () => syncCurrentNotifyStateToServer({ beacon: true, keepalive: true }));
  } catch (_) {}
  state.feedMode = "live";
  loadLive(false);
  setTimeout(() => openStartupMatchIfAny(), 250);
  setInterval(() => {
    if (state.onlineGate.allowed && !["detail","team"].includes(state.view) && !state.sheet) loadLive(false);
  }, LIVE_POLL_INTERVAL_MS);
  setInterval(() => {
    if (state.onlineGate.allowed) refreshDetailSilently();
  }, DETAIL_POLL_INTERVAL_MS);
};

const _renderLiveOnly = render;
render = function renderLiveOnlyRouter() {
  if (state.view === "competition") state.view = "matches";
  state.feedMode = "live";
  return _renderLiveOnly();
};


// ============================================================================
// v10.21 · FOOTBALL LIVE ONLY + CLASSIC GREEN UI
// Sport selector removed, team cards open from live rows, minute has no seconds.
// ============================================================================
state.sport = "football";
state.liveBySport = { football: state.live };
try { localStorage.setItem("miniapp-v10-active-sport", "football"); } catch (_) {}

renderSportTabs = function renderSportTabsRemovedFootballOnly() { return ""; };
setSport = function setSportFootballOnly() {
  state.sport = "football";
  return false;
};
activeSportMeta = function activeSportMetaFootballOnly() { return SPORT_META.football; };
sportQuery = function sportQueryFootballOnly(force = false) {
  const p = new URLSearchParams({ sport: "football" });
  if (force) p.set("force", "1");
  return p.toString();
};

function footballMinuteOnly(match) {
  const m = match || {};
  if (m.finished) return "ЗАВЕРШЁН";
  const raw = String(m.minute_text || m.period || "").trim();
  if (/^(HT|HALF\s*TIME|ПЕРЕРЫВ)$/i.test(raw)) return "ПЕРЕРЫВ";
  const added = raw.match(/(\d{1,3})\s*\+\s*(\d{1,2})/);
  if (added) return `${safeInt(added[1])}+${safeInt(added[2])}′`;
  const clock = raw.match(/(?:^|\s)(\d{1,3}):\d{2}(?:\s|$)/);
  if (clock) return `${safeInt(clock[1])}′`;
  const minuteMark = raw.match(/(\d{1,3})\s*[′']/);
  if (minuteMark) return `${safeInt(minuteMark[1])}′`;
  const minute = safeInt(m.minute, 0);
  if (minute > 0) return `${minute}′`;
  return m.is_live ? "LIVE" : (raw || "LIVE");
}

function liveTeamProfileButton(match, side) {
  const m = match || {};
  const s = side === "away" ? "away" : "home";
  const name = String(m[s] || "Команда");
  // On the main Live feed, the team is display-only. The whole match row opens
  // the match card; team profiles remain available only from inside that card.
  return `<div class="match-team-line live-team-display-only">${teamLogoSmall(m, s)}<div class="match-team">${esc(name)}</div></div>`;
}

function openLiveDetailTeam(side, event) {
  if (event) { event.preventDefault(); event.stopPropagation(); }
  const matchId = String(state.detail?.match?.id || state.selectedMatch || "");
  if (!matchId) return false;
  loadTeamStats(matchId, side === "away" ? "away" : "home", "detail", "football");
  return false;
}

filteredMatches = function filteredMatchesFootballOnly() {
  state.sport = "football";
  let arr = flattenLive(state.live).filter(m => m && m.is_live === true && m.finished !== true);
  arr = arr.filter(m => matchPassesFilter(m, state.filters));
  const q = String(state.search || "").trim().toLowerCase();
  if (q) arr = arr.filter(m => [m.home, m.away, m.league, m.country].some(v => String(v || "").toLowerCase().includes(q)));
  return arr;
};

renderMatchRow = function renderMatchRowFootballOnly(m) {
  const fav = isFav(m.id);
  const isFinished = m.finished === true;
  const sh = safeInt(m.score_home);
  const sa = safeInt(m.score_away);
  const heat = matchHeatTone(m);
  const status = footballMinuteOnly(m);
  const alertBlock = renderNotifyReasonBlock(m);
  return `<div class="match-row sport-football${isFinished ? " finished" : ""}${heat.cls ? ` ${heat.cls}` : ""}" data-id="${esc(m.id)}" data-sport="football" data-heat-score="${heat.score}">
    <span class="match-heat-edge" aria-hidden="true"></span>
    <div class="match-minute ${isFinished ? "finished" : ""}">${esc(status)}</div>
    <div class="match-teams">
      ${liveTeamProfileButton(m, "home")}
      ${liveTeamProfileButton(m, "away")}
      ${alertBlock}
    </div>
    <div class="match-score"><div class="match-score-row ${sh > 0 ? "scored" : ""}">${sh}</div><div class="match-score-row ${sa > 0 ? "scored" : ""}">${sa}</div></div>
    <button class="star-btn ${fav ? "active" : ""}" data-fav="${esc(m.id)}" title="${fav ? "Убрать" : "В избранное"}">${fav ? "★" : "☆"}</button>
  </div>`;
};

renderUnifiedTopbar = function renderUnifiedTopbarFootballOnly(total) {
  const q = esc(state.search || "");
  const hasQ = !!String(state.search || "").trim();
  return `<div class="topbar unified-topbar live-only-topbar football-only-topbar">
    <div class="topbar-row">
      <div class="live-status"><div class="live-dot"></div><span class="live-label">LIVE</span></div>
      <span class="live-count">· ${total} матчей</span>
      <div class="topbar-actions">
        <button class="icon-btn" onclick="loadLive(true)" title="Обновить"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg></button>
        <button class="icon-btn accent" onclick="openSheet('filters')" title="Фильтры"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="7" y1="12" x2="17" y2="12"/><line x1="10" y1="18" x2="14" y2="18"/></svg></button>
      </div>
    </div>
    <div class="search-row"><span class="search-icon" aria-hidden="true"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span><input type="text" inputmode="search" autocomplete="off" autocorrect="off" spellcheck="false" class="search-input" id="match-search-input" placeholder="Поиск команды, лиги, страны…" value="${q}" oninput="onSearchInput(this.value)" />${hasQ ? `<button class="search-clear" onclick="clearSearch()" aria-label="Очистить">×</button>` : ""}</div>
  </div>`;
};

renderMatches = function renderMatchesFootballOnly() {
  state.sport = "football";
  state.feedMode = "live";
  const total = filteredMatches().length;
  app.innerHTML = `${renderUnifiedTopbar(total)}<div id="match-feed">${renderMatchFeedInner()}</div>${renderSportScoreAttribution()}${renderBottomNav("matches")}${renderSheet()}`;
  bindMatchHandlers();
};

const _renderDetailFootballOnlyBase = renderDetail;
renderDetail = function renderDetailFootballOnly() {
  _renderDetailFootballOnlyBase();
  const d = state.detail || {};
  const m = d.match || {};
  if (!m || String(m.sport || "football") !== "football") return;
  const teams = app.querySelectorAll(".scoreboard .scoreboard-team");
  teams.forEach((node, index) => {
    const side = index === 1 ? "away" : "home";
    node.classList.add("live-detail-team-link");
    node.setAttribute("role", "button");
    node.setAttribute("tabindex", "0");
    node.setAttribute("title", `Открыть карточку ${String(m[side] || "команды")}`);
    node.onclick = (event) => openLiveDetailTeam(side, event);
    node.onkeydown = (event) => {
      if (event.key === "Enter" || event.key === " ") openLiveDetailTeam(side, event);
    };
    if (!node.querySelector(".live-detail-team-hint")) {
      const hint = document.createElement("span");
      hint.className = "live-detail-team-hint";
      hint.textContent = "Статистика ›";
      node.appendChild(hint);
    }
  });
  const livePill = app.querySelector(".scoreboard-center .live-pill");
  if (livePill && !d.finished) livePill.innerHTML = `<div class="live-dot"></div>${esc(footballMinuteOnly(m))}`;
};

showMainFeedInfo = function showMainFeedInfoFootballOnly() {
  const msg = ["Live ZOT", "", "Оставлены только футбольные Live-матчи.", "На главном экране нажмите на строку матча, чтобы открыть карточку матча. Карточки команд открываются только изнутри матча.", "Время матча показывается в минутах без секунд."].join("\n");
  try { if (tg?.showAlert) return tg.showAlert(msg); } catch (_) {}
  alert(msg);
};

const _bootAppFootballOnlyBase = bootApp;
bootApp = async function bootAppFootballOnly() {
  state.sport = "football";
  state.liveBySport = { football: state.live };
  try { localStorage.setItem("miniapp-v10-active-sport", "football"); } catch (_) {}
  return _bootAppFootballOnlyBase();
};

window.openLiveDetailTeam = openLiveDetailTeam;

// v10.29: SportScore filter/notification repair.
const LIVE_FILTER_STAT_KEYS = [
  "shots_min", "on_target_min", "off_target_min", "dangerous_min",
  "attacks_min", "corners_min", "yellow_cards_min", "red_cards_min",
  "possession_min", "pressure_min",
];

function liveFilterNeedsStats(cfg) {
  const f = cfg || {};
  return LIVE_FILTER_STAT_KEYS.some(key => safeInt(f[key], 0) > 0);
}

function refreshLiveForFilters(attempt = 0) {
  state.sport = "football";
  if (_liveSportInFlight?.has?.("football")) {
    if (attempt < 12) setTimeout(() => refreshLiveForFilters(attempt + 1), 350);
    return Promise.resolve(false);
  }
  return Promise.resolve(loadLive(true)).then(() => true).catch(() => false);
}

sportQuery = function sportQueryFootballFilters(force = false) {
  const p = new URLSearchParams({ sport: "football" });
  if (force) p.set("force", "1");
  const needStats = liveFilterNeedsStats(state.filters) || (getNotifyEnabled() && liveFilterNeedsStats(getNotifyFilter()));
  if (needStats) p.set("include_stats", "1");
  return p.toString();
};

const _applyFiltersV1029Base = applyFilters;
applyFilters = function applyFiltersWithSportScoreStats() {
  _applyFiltersV1029Base();
  if (liveFilterNeedsStats(state.filters)) {
    setTimeout(() => refreshLiveForFilters(), 280);
  }
};

const _resetFiltersV1029Base = resetFilters;
resetFilters = function resetFiltersAndReload() {
  _resetFiltersV1029Base();
  setTimeout(() => refreshLiveForFilters(), 280);
};

const _applyNotifyFilterV1029Base = applyNotifyFilter;
applyNotifyFilter = function applyNotifyFilterWithSportScoreStats() {
  _applyNotifyFilterV1029Base();
  if (getNotifyEnabled()) {
    setTimeout(() => refreshLiveForFilters().then(() => checkNotifyMatches()), 280);
  }
};

const _resetNotifyFilterV1029Base = resetNotifyFilter;
resetNotifyFilter = function resetNotifyFilterAndReload() {
  _resetNotifyFilterV1029Base();
  if (getNotifyEnabled()) setTimeout(() => refreshLiveForFilters().then(() => checkNotifyMatches()), 280);
};

const _toggleNotifyEnabledV1029Base = toggleNotifyEnabled;
toggleNotifyEnabled = function toggleNotifyEnabledWithStatsReload() {
  _toggleNotifyEnabledV1029Base();
  if (getNotifyEnabled()) setTimeout(() => refreshLiveForFilters().then(() => checkNotifyMatches()), 120);
};

async function testTelegramNotification() {
  if (!tg?.initData) {
    const msg = "Открой Mini App из Telegram-бота, а не по обычной ссылке.";
    try { return tg?.showAlert?.(msg); } catch (_) { alert(msg); return; }
  }
  try {
    const res = await fetch("/api/notify/test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      cache: "no-store",
      body: JSON.stringify({ init_data: tg.initData }),
    });
    const data = await res.json().catch(() => ({}));
    const msg = data.ok
      ? "Тест отправлен. Проверь сообщения от бота."
      : `Тест не прошёл: ${data.message || data.error || `HTTP ${res.status}`}`;
    try { if (tg?.showAlert) return tg.showAlert(msg); } catch (_) {}
    alert(msg);
  } catch (err) {
    const msg = `Не удалось проверить уведомления: ${String(err?.message || err || "ошибка сети")}`;
    try { if (tg?.showAlert) return tg.showAlert(msg); } catch (_) {}
    alert(msg);
  }
}

// ============================================================================
// V10.42 · INSTANT MAIN PAGE
// Local instant snapshot + Redis stale-while-revalidate server cache.
// ============================================================================
const FAST_LIVE_CACHE_KEY = "live-zot-v1042-live-snapshot";
const FAST_LIVE_CACHE_MAX_AGE_MS = 5 * 60 * 1000;
const FAST_DETAIL_CACHE_PREFIX = "live-zot-v1042-detail:";
const FAST_DETAIL_INDEX_KEY = "live-zot-v1042-detail-index";
const FAST_DETAIL_CACHE_MAX_AGE_MS = 5 * 60 * 1000;
const FAST_DETAIL_CACHE_MAX_ITEMS = 4;
let _fastLiveRefreshRetryTimer = null;
let _fastBootStarted = false;
let _fastBootListenersBound = false;

function fastPayloadHasMatches(payload) {
  try { return Boolean(payload && payload.ok && flattenLive(payload).length > 0); }
  catch (_) { return false; }
}

function saveFastLiveCache(payload) {
  if (!fastPayloadHasMatches(payload)) return;
  try {
    localStorage.setItem(FAST_LIVE_CACHE_KEY, JSON.stringify({ saved_at: Date.now(), payload }));
  } catch (_) {}
}

function readFastLiveCache() {
  try {
    const stored = JSON.parse(localStorage.getItem(FAST_LIVE_CACHE_KEY) || "null");
    const age = Date.now() - Number(stored?.saved_at || 0);
    if (!stored || age < 0 || age > FAST_LIVE_CACHE_MAX_AGE_MS || !fastPayloadHasMatches(stored.payload)) return null;
    return { ...stored.payload, client_cache: true, client_cache_age_ms: age };
  } catch (_) { return null; }
}

function restoreFastLiveCache() {
  const payload = readFastLiveCache();
  if (!payload) return false;
  state.sport = "football";
  state.live = payload;
  state.liveBySport = { football: payload };
  state.loading = false;
  try { refreshFavCacheFromLive(flattenLive(payload)); } catch (_) {}
  render();
  return true;
}

function fastDetailStorageKey(id) {
  return FAST_DETAIL_CACHE_PREFIX + encodeURIComponent(normalizeMatchId(id));
}

function saveFastDetailCache(id, payload) {
  if (!payload?.ok || !payload?.match) return;
  try {
    const key = fastDetailStorageKey(id);
    localStorage.setItem(key, JSON.stringify({ saved_at: Date.now(), payload }));
    const previous = JSON.parse(localStorage.getItem(FAST_DETAIL_INDEX_KEY) || "[]");
    const keys = [key, ...(Array.isArray(previous) ? previous : []).filter(item => item !== key)];
    for (const oldKey of keys.slice(FAST_DETAIL_CACHE_MAX_ITEMS)) localStorage.removeItem(String(oldKey));
    localStorage.setItem(FAST_DETAIL_INDEX_KEY, JSON.stringify(keys.slice(0, FAST_DETAIL_CACHE_MAX_ITEMS)));
  } catch (_) {}
}

function readFastDetailCache(id) {
  try {
    const stored = JSON.parse(localStorage.getItem(fastDetailStorageKey(id)) || "null");
    const age = Date.now() - Number(stored?.saved_at || 0);
    if (!stored?.payload?.ok || age < 0 || age > FAST_DETAIL_CACHE_MAX_AGE_MS) {
      try { localStorage.removeItem(fastDetailStorageKey(id)); } catch (_) {}
      return null;
    }
    return { ...stored.payload, client_cache: true, client_cache_age_ms: age };
  } catch (_) { return null; }
}

function fastDetailPreviewFromLive(id) {
  const mid = normalizeMatchId(id);
  let match = null;
  try { match = flattenLive(state.live).find(row => normalizeMatchId(row?.id) === mid) || null; } catch (_) {}
  if (!match) return null;
  return {
    ok: true,
    provider: "sportscore",
    match: { ...match },
    stats: {},
    events: [],
    standings: [],
    trends: [],
    odds: {},
    pressure: { available: false, reason: "loading" },
    pressure_chart: { available: false, reason: "loading" },
    avg: { home: { avg: null, count: 0 }, away: { avg: null, count: 0 } },
    fast_preview: true,
    loading_full_detail: true,
  };
}

loadLive = async function loadLiveFastStart(force = false) {
  const requestSport = "football";
  state.sport = "football";
  if (_liveSportInFlight.has(requestSport)) return false;
  _liveSportInFlight.add(requestSport);
  _loadLiveInFlight = true;
  const preserveMatchScroll = state.view === "matches" && !state.sheet;
  if (preserveMatchScroll) saveMatchListPosition();
  let payload = null;
  try {
    const query = sportQuery(force);
    const res = await fetch(`/api/live?${query}`, { cache: "no-store" });
    payload = await res.json().catch(() => ({}));
    if (!res.ok || !payload || payload.ok === false) throw new Error(payload?.error || `HTTP ${res.status}`);
    state.liveBySport[requestSport] = payload;
    state.live = payload;
    saveFastLiveCache(payload);
    try { refreshFavCacheFromLive(flattenLive(payload)); } catch (_) {}
    // v10.41: fast-start replaced the old loader but accidentally skipped the
    // notification scanners. Run them on every fresh snapshot.
    try { checkNotifyMatches(); } catch (_) {}
    try { checkGoalAlerts(); } catch (_) {}
    if (payload.refreshing) {
      clearTimeout(_fastLiveRefreshRetryTimer);
      const retryMs = Math.max(2000, Number(payload.retry_after_seconds || 4) * 1000);
      _fastLiveRefreshRetryTimer = setTimeout(() => {
        if (!document.hidden && state.view === "matches" && !_loadLiveInFlight) loadLive(false);
      }, retryMs);
    }
  } catch (err) {
    // Keep the already-rendered local snapshot instead of replacing the screen
    // with an empty error while the network/source is temporarily slow.
    if (!fastPayloadHasMatches(state.live)) {
      const cached = readFastLiveCache();
      state.live = cached || { ok: false, total: 0, countries: [], sport: requestSport, error: String(err) };
      state.liveBySport[requestSport] = state.live;
    }
  } finally {
    state.loading = false;
    _liveSportInFlight.delete(requestSport);
    _loadLiveInFlight = _liveSportInFlight.size > 0;
    if (state.onlineGate.checked && !state.onlineGate.allowed) return false;
    if (maybeRestoreLastOpenedDetail()) return true;
    if (preserveMatchScroll && document.getElementById("match-feed")) {
      refreshMatchesScreenOnly({ preserveHeight: true });
      restoreMatchListPosition();
    } else {
      render();
      if (preserveMatchScroll) restoreMatchListPosition();
    }
  }
  return Boolean(payload?.ok);
};

bootApp = async function bootAppFastStart() {
  if (_fastBootStarted) return;
  _fastBootStarted = true;
  state.sport = "football";
  state.feedMode = "live";
  state.liveBySport = { football: state.live };
  try { localStorage.setItem("miniapp-v10-active-sport", "football"); } catch (_) {}

  const restored = restoreFastLiveCache();
  if (!restored) render();

  if (!_fastBootListenersBound) {
    _fastBootListenersBound = true;
    try {
      document.addEventListener("visibilitychange", () => {
        if (!document.hidden) {
          checkOnlineGate(false);
          syncCurrentNotifyStateToServer();
          if (state.view === "matches") loadLive(false);
        }
      });
      window.addEventListener("pagehide", () => syncCurrentNotifyStateToServer({ beacon: true, keepalive: true }));
      window.addEventListener("beforeunload", () => syncCurrentNotifyStateToServer({ beacon: true, keepalive: true }));
    } catch (_) {}
  }

  // Access check and LIVE request begin together. A returning user already sees
  // the local snapshot; a first-time user normally receives the Redis snapshot.
  const gatePromise = checkOnlineGate(true);
  const livePromise = loadLive(false);
  const allowed = await gatePromise;
  if (!allowed) return;

  startOnlineHeartbeat();
  syncCurrentNotifyStateToServer();
  setTimeout(() => openStartupMatchIfAny(), 120);
  livePromise.catch(() => {});

  setInterval(() => {
    if (state.onlineGate.allowed && !["detail", "team"].includes(state.view) && !state.sheet) loadLive(false);
  }, LIVE_POLL_INTERVAL_MS);
  setInterval(() => {
    if (state.onlineGate.allowed) refreshDetailSilently();
  }, DETAIL_POLL_INTERVAL_MS);
};

bootApp();

// Expose handlers used inline
window.loadLive = loadLive;
window.setSport = setSport;
window.loadPrematch = loadPrematch;
window.setFeedMode = setFeedMode;
window.setPrematchDate = setPrematchDate;
window.setPrematchDetailTab = setPrematchDetailTab;
window.retryOnlineGate = retryOnlineGate;
window.setMainTab = setMainTab;
window.openSheet = openSheet;
window.closeSheet = closeSheet;
window.applyFilters = applyFilters;
window.resetFilters = resetFilters;
window.applyNotifyFilter = applyNotifyFilter;
window.resetNotifyFilter = resetNotifyFilter;
window.applyGoalWaitPreset = function(){};
window.setPreset = setPreset;
window.onSearchInput = onSearchInput;
window.clearSearch = clearSearch;
window.setDetailTab = setDetailTab;
window.setDetailMatchesSide = setDetailMatchesSide;
window.toggleAvgTotal = toggleAvgTotal;
window.toggleFavRender = toggleFavRender;
window.goBack = goBack;
window.switchView = switchView;
window.setMainTab = setMainTab;
window.toggleNotifyEnabled = toggleNotifyEnabled;
window.testTelegramNotification = testTelegramNotification;
window.toggleAlertSound = toggleAlertSound;
window.toggleGoalWaitNotifyEnabled = function(){};
window.toggleGoalWaitAutoGoalEnabled = function(){};
window.setNotifyTab = setNotifyTab;
window.loadNotifyMatches = loadNotifyMatches;
window.clearNotifyMatches = clearNotifyMatches;
window.removeNotifyMatch = removeNotifyMatch;
window.loadDetail = loadDetail;
window.navigateDetail = navigateDetail;
window.refreshDetailSilently = refreshDetailSilently;
